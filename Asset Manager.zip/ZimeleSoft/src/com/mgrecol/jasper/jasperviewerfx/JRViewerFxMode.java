/**
 * 
 */
package com.mgrecol.jasper.jasperviewerfx;

/**
 * @author  Michael Grecol
 *	@project JasperViewerFx
 * @filename JRViewerFxMode.java
 * @date May 19, 2015
 */
public enum JRViewerFxMode {
	REPORT_PRINT, REPORT_VIEW 
}

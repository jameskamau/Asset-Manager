
package EmailReports;

import DataBaseConnector.javaconnect;
import EmailNotify.SendMail;
import Zimele_main.Zimele_Information_Management_System;
import java.io.File;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;

/**
 *
 * @author james kamau
 */
public class SendStatementMail {
    
    PreparedStatement statement;
    ResultSet result;
    Connection connect;
    String MemberAccountBalancesMMpath="./Reports/MoneyMarketAccountBalanceStatement.jrxml";
    String MemberAccountBalancesBFpath="./Reports/BalanceFundStatement.jrxml";
    String MemberAccountBalancesHOpath="./Reports/HomeOwnershipAccoutBalanceStaatement.jrxml";
    String MemberAccountBalancesPPpath="./Reports/Personal_Pension_Statement.jrxml";
    String MemberAccountBalancesGPpath="./Reports/GaranteedPensionAccountBalanceStatement.jrxml";
   
    
     public void sendPdfGETDBData() {
 
        try {
            Integer MM;
            Integer BF;
            Integer HO;
            Integer PP;
            Integer GP;
            SendMail sendMail = new SendMail();
            
            connect=javaconnect.connectDb1();
             String sqlGP="SELECT DISTINCT MemberNumber FROM `garanteedpensionaccounts WHERE MarketValue >250";
            String sqlMM="SELECT DISTINCT MemberNumber FROM `moneymarketaccounts` WHERE MarketValue >250";
            String sqlBF="SELECT DISTINCT MemberNumber FROM `balacefundaccounts` WHERE CurrentValue >250";
            String sqlPP="SELECT DISTINCT MemberNumber FROM `personalpensionpurchase` WHERE CurrentValue >250";
            String sqlHO="SELECT DISTINCT MemberNumber FROM `homeownershipaccounts`";
            
            statement = connect.prepareStatement(sqlGP);
            ResultSet rs = statement.executeQuery();
            
            while(rs.next()){
                try{
                GP=rs.getInt("MemberNumber");
                String name=rs.getString("FullName");
                String exportPath1=exportPDF(MemberAccountBalancesGPpath, GP.toString(),"GuaranteedPensionStatement");
                System.out.println(exportPath1);
                
                String getEmail="SELECT * FROM `personalinformation` WHERE `memberNumber`=";
                getEmail=getEmail.concat("'"); getEmail=getEmail.concat(GP.toString());
                getEmail=getEmail.concat("' AND FullName='");getEmail=getEmail.concat(name);getEmail=getEmail.concat("'");
                statement=connect.prepareStatement(getEmail);
                ResultSet rs5 = statement.executeQuery();
                String email= rs5.getString("EmailAddress");
                
                sendMail.sendMail("customerservice@zimele.net","kujeni@830",email, exportPath1, "GuaranteedPensionStatement");
                deleteFile(exportPath1);
                }catch(Exception e){}
            }
            statement = connect.prepareStatement(sqlMM);
            ResultSet rs1 = statement.executeQuery();
            
            while(rs1.next()){
                try{
                MM=rs1.getInt("MemberNumber");
                String name=rs.getString("FullName");
                String exportPath2=exportPDF(MemberAccountBalancesMMpath, MM.toString(),"MoneyMarketFundStatement");
                String getEmail="SELECT * FROM `personalinformation` WHERE `memberNumber`=";
                getEmail=getEmail.concat("'"); getEmail=getEmail.concat(MM.toString());
                getEmail=getEmail.concat("' AND FullName='");getEmail=getEmail.concat(name);getEmail=getEmail.concat("' ;");
                statement=connect.prepareStatement(getEmail);
                ResultSet rs5 = statement.executeQuery();
                String email= rs5.getString("EmailAddress");
                sendMail.sendMail("customerservice@zimele.net","kujeni@830",email, exportPath2, "MoneyMarketFundStatement");
                deleteFile(exportPath2);
                }catch(Exception e){}
            }
            
            statement = connect.prepareStatement(sqlBF);
            ResultSet rs2 = statement.executeQuery();
            
            while(rs2.next()){
                try{
                BF=rs2.getInt("MemberNumber");
                String name=rs.getString("FullName");
                String exportPath3=exportPDF(MemberAccountBalancesBFpath, BF.toString(),"BalancedFundStatement");
                String getEmail="SELECT * FROM `personalinformation` WHERE `memberNumber`=";
                getEmail=getEmail.concat("'"); getEmail=getEmail.concat(BF.toString());
                getEmail=getEmail.concat("' AND FullName='");getEmail=getEmail.concat(name);getEmail=getEmail.concat("' ;");
                statement=connect.prepareStatement(getEmail);
                ResultSet rs5 = statement.executeQuery();
                String email= rs5.getString("EmailAddress");
                sendMail.sendMail("customerservice@zimele.net","kujeni@830",email, exportPath3, "BalancedFundStatement");
                deleteFile(exportPath3);
                }catch(Exception e){}
            }
            
            statement = connect.prepareStatement(sqlPP);
            ResultSet rs3 = statement.executeQuery();
            
            while(rs3.next()){
                try{
                PP=rs3.getInt("MemberNumber");
                String name=rs.getString("FullName");
                String exportPath4=exportPDF(MemberAccountBalancesPPpath, PP.toString(),"PersonalPensionStatement");
                String getEmail="SELECT * FROM `personalinformation` WHERE `memberNumber`=";
                getEmail=getEmail.concat("'"); getEmail=getEmail.concat(PP.toString());
                getEmail=getEmail.concat("' AND FullName='");getEmail=getEmail.concat(name);getEmail=getEmail.concat("' ;");
                statement=connect.prepareStatement(getEmail);
                ResultSet rs5 = statement.executeQuery();
                String email= rs5.getString("EmailAddress");
                sendMail.sendMail("customerservice@zimele.net","kujeni@830",email, exportPath4, "PersonalPensionStatement");
                deleteFile(exportPath4);
                }catch (Exception e){}
            }
            
            
//             statement = connect.prepareStatement(sqlHO);
//        ResultSet rs4 = statement.executeQuery();
//            
//          while(rs4.next()){
//               HO=rs4.getInt("MemberNumber");
//           String HOsql ="SELECT * from `homeownershipaccounts` WHERE `MemberNumber`=";
//            HOsql=HOsql.concat("'"); HOsql=HOsql.concat(HO.toString());
//            HOsql=HOsql.concat("'");HOsql=HOsql.concat(";");
//           String exportPath5=exportPDF(MemberAccountBalancesHOpath, HOsql,"HomeOwnershipStatement");
//         
//            String getEmail="SELECT * FROM `personalinformation` WHERE `memberNumber`=";
//                getEmail=getEmail.concat("'"); getEmail=getEmail.concat(HO.toString());
//                getEmail=getEmail.concat("'");getEmail=getEmail.concat(";");
//                statement=connect.prepareStatement(getEmail);
//                ResultSet rs5 = statement.executeQuery();
//                String email= rs5.getString("EmailAddress");
//           sendMail.sendMail("customerservice@zimele.net","kujeni@830",email, exportPath5, "HomeOwnershipStatement");
//           deleteFile(exportPath5);
//           
//          }
        } catch (SQLException ex) {
            Logger.getLogger(SendStatementMail.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    
    }
    
    public String exportPDF(String path ,String MemberNumber,String fileName) throws JRException{
           Map parameter= new HashMap();
             parameter.put("memberNumber", MemberNumber);
           
            JasperDesign jd = JRXmlLoader.load(path);
            JasperReport jr = JasperCompileManager.compileReport(jd);
            JasperPrint jp = JasperFillManager.fillReport(jr, parameter, connect);
            String exportPath="./EmailReports/";
            
            exportPath=exportPath.concat(fileName.concat(".pdf"));
            
            JasperExportManager.exportReportToPdfFile(jp,exportPath);
            return exportPath;
    }
    
    
     public void deleteFile(String path){
        try{
            File f = null;
            f = new File(path);
            f.delete();
        } catch (Exception e){
         e.printStackTrace();
        }
     
    
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package zimele_information_management_system;

import BalanceFund.BalanceFundAccount;
import BalanceFund.BalanceFundPurchase;
import BalanceFund.BalanceFundPurchaseLogic;
import BalanceFund.BalanceFundWithdrawal;
import BalanceFund.BalanceFundWithdrawalLogic;

import ChequeWindow.callChequeWindow;

import DataBaseConnector.HibernateConnector;
import DataBaseConnector.JavaFirebirdconnect;
import DataBaseConnector.javaconnect;
import DateConverter.LocalDatePersistenceConverter;
import FundTransfer.PensionFundTransfer;
import FundTransfer.UnitTrustTransfer;
import GaranteedPension.GaranteedPensionAccount;
import GaranteedPension.GaranteedPensionDeposit;
import GaranteedPension.GaranteedPensionDepositLogic;
import GaranteedPension.GaranteedPensionWithdrawalLogic;
import GaranteedPension.GaranteedPensionWithdrawals;
import HomeOwnership.HomeOwnershipAccounts;
import HomeOwnership.HomeOwnershipDeposit;
import HomeOwnership.HomeOwnershipDepositLogic;
import HomeOwnership.HomeOwnershipWithdrawal;
import HomeOwnership.HomeOwnershipWithdrawalLogic;
import InterestCalculator.UpdateDataGaranteedPension;
import InterestCalculator.UpdateDataMoneyMarket;
import MemberSearch.MemberSearch;
import MoneyMarket.MoneyMarketAccounts;
import MoneyMarket.MoneyMarketDeposit;
import MoneyMarket.MoneyMarketDepositLogic;
import MoneyMarket.MoneyMarketWithdrawal;
import MoneyMarket.MoneyMarketWithdrawalLogic;
import PersonalPension.PersonalPensionAccounts;
import PersonalPension.PersonalPensionDeposit;
import PersonalPension.PersonalPensionDepositLogic;
import PersonalPension.PersonalPensionWithdrawal;
import PersonalPension.PersonalPensionWithdrawalLogic;
import Registration.FundTransfer;
import Registration.InvestmentApplication;
import Registration.NextOfKinInformation;
import Registration.PersonalInformation;
import Registration.PersonalInformationLogic;
import SMSNotify.SendSms;
import TableDisplays.EditableCell;
import TableDisplays.ResultsetTableDisplay;
import Zimele_Admin.JaspytPasswordEncryptor;
import Zimele_Admin.Zimele_AdminController;
import Zimele_Back_Office.Back_Office_ModuleController;
import Zimele_main.Zimele_LogInController;
import changePassword.MainPassword;
import comppanyinfo.callAboutWindow;

import com.mgrecol.jasper.jasperviewerfx.JRViewerFx;
import com.mgrecol.jasper.jasperviewerfx.JRViewerFxMode;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.time.LocalDate;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.imageio.ImageIO;

import static javafx.application.Application.STYLESHEET_CASPIAN;
import javafx.application.Platform;
import javafx.beans.binding.Bindings;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.ObservableMap;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Pagination;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.ContextMenuEvent;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;
import org.controlsfx.control.textfield.AutoCompletionBinding;
import org.controlsfx.control.textfield.TextFields;


/**
 * FXML Controller class
 *
 * @author james kamau
 */

public class FXMLDocumentController implements Initializable {

    /**
     * @return the userName
     */
    public static String getUserName() {
        return userName;
    }

    /**
     * @param aUserName the userName to set
     */
    public static void setUserName(String aUserName) {
        userName = aUserName;
    }
   
   PreparedStatement statement;
    ResultSet result;
    Connection conn;
    Connection conn1;
    Connection conn2;
    
    private static String userName;
    private static String userType;
    private static String password;
    
    
    
    public static String getPassword() {
		return password;
	}

	public static void setPassword(String password) {
		FXMLDocumentController.password = password;
	}

	//search member section
    @FXML
    private TextField fullNameSearchField =new TextField();
    @FXML
    private Button searchClientBtn = new Button();
    //money Market deposit section
    @FXML
    private TextField memberNumberField=new TextField();
    @FXML
    private TextField fullNameField= new TextField();
    @FXML
    private TextField depositAmountField = new TextField();
    @FXML
    private DatePicker dateOfDepositField = new DatePicker();
    @FXML
    private Button saveTransactionBtn = new Button();
    @FXML
    private Button viewTransactionHistoryBtn = new Button();
    private TextField documentNumberField  = new TextField();
    private TextField generalRateField = new TextField();
    private TextField customRateField = new TextField();
    @FXML
    private Button viewHistoryBtn= new Button();
    @FXML
    private TextField depositHistoryAccountNumberField = new TextField();
     @FXML
    private ComboBox<String> MoneyMarketMOPDeposit = new ComboBox<>();
    // Table Navigation Section
    @FXML
    private Button refreshTable = new Button();
    
    @FXML
    private Button AddMember =new Button();
    @FXML
    private ComboBox<String> chooseTableCombobox;
    @FXML
    private Button generateReportBtn =new Button();
     @FXML
    private ChoiceBox<String> chooseReport= new ChoiceBox<>();
    //MoneyMarket Withdrawal Section
    @FXML
    private ComboBox<String> moneyMarketMOPW = new ComboBox<>();
    @FXML
    private TextField memberNumberWithdrawalField  = new TextField();
    @FXML
    private TextField fullNamewithdrawalField = new TextField();
    @FXML
    private TextField withdrawalAmountField  = new TextField();
    @FXML
    private DatePicker withdrawalDateWithdrawalField = new DatePicker();
    @FXML
    private Button saveTransactionWithdrawalField = new Button();
    @FXML
    private TextField withdrawalHistoryAccountNumberField  = new TextField();
    
    private TextField withdrawFromInterestMoneyMarket  = new TextField();
    @FXML
    private Button viewHistoryWithdrawalBtn = new Button();
    //BalanceFund purchases section
     @FXML
    private ComboBox<String> balabceFundMOPP=new ComboBox<>();
    @FXML
    private TextField memberNumberPurchasesfield  = new TextField();
    @FXML
    private TextField fulNamePurchasesField  = new TextField();
    @FXML
    private TextField purchaseAmountPurchasesField  = new TextField();
    @FXML
    private DatePicker dateOfPurchasePurchasesField = new DatePicker();
    @FXML
    private Button saveTransactionpurchasesBtn = new Button();
    @FXML
    private Button viewTransactionHistoryPurchasesBtn = new Button();
    @FXML
    private TextField unitsPurchasedPurchasesField  = new TextField();
    @FXML
    private TextField purchasePricePurchasefield  = new TextField() ;
    @FXML
    private TextField PurchaseNumberBalanceFundPurchase= new TextField();
            
    //BalanceFund Withdrawal Section
    private TextField PurchaseNumberBalanceFundWithdrawal= new TextField();;
     @FXML
    private TextField fullNamewithdrawalFieldBalanceFund  = new TextField();
    @FXML
    private ComboBox<String> balabceFundMOPW=new ComboBox<>();
    @FXML
    private TextField sellPriceWithdrawalsField  = new TextField();
    @FXML
    private TextField unitsSoldWithdrwalField  = new TextField();
    @FXML
    private DatePicker dateOfWithdrawalWithdrawalsField = new DatePicker();
    @FXML
    private TextField purchaseAmountWithdrawalField  = new TextField();
    @FXML
    private TextField memberNumberwithdrawalField  = new TextField();
    @FXML
    private Button viewTransactionHistoryWithdrwalsField = new Button();
    @FXML
    private Button saveTransactionsWithdrawalBtn = new Button();
    @FXML
    private TextField transactionHistoryAccountSearchField  = new TextField();
    @FXML
    private Button viewHistoryBalancefundBtn = new Button();
    @FXML
    private Button closePositionBalanceFundBtn = new Button();
    // Registration personal Information section
    @FXML
    private TextField memberNumberPersonalInfo  = new TextField();
    @FXML
    private TextField IDNumberPersonalInfo = new TextField();
    @FXML
    private TextField firstNamePersonalInfo = new TextField();
    @FXML
    private TextField lastNamePersonalInfo = new TextField();
    @FXML
    private TextField surNamePersonalInfo = new TextField();
    @FXML
    private DatePicker dateOfBirthPersonalInfo = new DatePicker();
    @FXML
    private TextField FullNamePersonalInfo = new TextField();
    @FXML
    private DatePicker dateOfRegistrationPersonalInfo = new DatePicker();
    @FXML
    private TextField EmailAddressPersonalInfo = new TextField();
    @FXML
    private TextField physicalAddressPersonalInfo = new TextField();
    @FXML
    private TextField phoneNumberPersonalInfo = new TextField();
    @FXML
    private TextField postalAddressPersonalInfo = new TextField();
    @FXML
    private TextField ResidentTownPersonalInfo = new TextField();
    @FXML
    private TextField residentCountyPersonalInfo = new TextField();
    @FXML
    private ChoiceBox<String> genderPersonalInfo= new ChoiceBox<>();
    @FXML
    private ChoiceBox<String> maritalStutus=new ChoiceBox<>();
     @FXML
    private ChoiceBox<String> memberType=new ChoiceBox<>();
    
    
    //Registration NextOfKin Section
   
    @FXML
    private TextField firstNameNextOfKin = new TextField();
    @FXML
    private TextField surNameNextOfKin = new TextField();
    @FXML
    private TextField MemberNumberNextOfKin = new TextField();
    @FXML
    private TextField lastNameNextOfKin = new TextField();
    @FXML
    private TextField IDNumberNextOfKin = new TextField();
    @FXML
    private TextField EmailAddressNextOfKin = new TextField();
    @FXML
    private TextField physicalAddressNextOfKin = new TextField();
    @FXML
    private TextField phoneNumberNextOfKin = new TextField();
    @FXML
    private TextField postalAddressNextOfKin = new TextField();
    @FXML
    private TextField relationshipTooNextOfKin = new TextField();
    @FXML
    private TextField persentageNextOfKin = new TextField();
    @FXML
    private DatePicker dateOfRegistrationNextOfKin = new DatePicker();
    @FXML
    private Button saveDetailsBtnNextOfKin = new Button();
    // Investment Application Section
    @FXML
    private ComboBox<String> investmentTypeInvestmentApplication= new ComboBox<>();
    @FXML
    private ComboBox<String> chooseFundType= new ComboBox<>();
    
    @FXML
    private TextField memberNumberInvestmentApplication = new TextField();
    @FXML
    private TextField fullNameInvestmentApplication = new TextField();
    @FXML
    private ChoiceBox<String> AccountTypeInvestmentApplication= new ChoiceBox<>();
   
    @FXML
    private DatePicker DateOfApplicationInvestmentApplication= new DatePicker();
    // Bank Account Details +KRA PIN
    @FXML
    private Label brachLocationBankDetails = new Label();
    @FXML
    private TextField BankAccountNameBankDetails = new TextField();
    @FXML
    private TextField BankNameBankDetails = new TextField();
    @FXML
    private TextField accountNumberBankDetails = new TextField();
    @FXML
    private TextField KRAPinBankDetails = new TextField();
    @FXML
    private TextField branchLocationBankDetails = new TextField();
    @FXML
    private Button saveDetailsBankDetailsBtn = new Button();
    //Fund Transfer Section
    @FXML
    private TextField memberNumberFundTransfer = new TextField();
    @FXML
    private TextField fullNameFundTransfer = new TextField();
    @FXML
    private ChoiceBox<String> accountTypeFundTransfer = new ChoiceBox<>();
    @FXML
    private ChoiceBox<String> toInvestmentType_fundTransfer = new ChoiceBox<>();
    @FXML
    private TextField transferAmount_fundTransfer = new TextField();
    @FXML
    private Button transferBtn_fundTransfer = new Button();
    @FXML
    private ChoiceBox<String> fromInvestmentType_FundTransfer = new ChoiceBox<>();
    @FXML
    private DatePicker dateOfTransfer_fundTreansfer = new DatePicker();
    //HomeOwnership Section
     @FXML
    private ComboBox<String> homeOwnershipMOPD=new ComboBox<>();
     @FXML
     private ChoiceBox<String> EditTransactionChoice = new ChoiceBox<>();
     
     @FXML
     private ChoiceBox<String> selectFundPostInterest = new ChoiceBox<>();
    
    @FXML
    private TextField memberNumber_HomeOwnership = new TextField();
    @FXML
    private TextField fullName_HomeOwnership = new TextField();
    @FXML
    private DatePicker dateOfDeposit_HomeOwnership = new DatePicker();
    @FXML
    private Button saveTransaction_HomeOwnership = new Button();
    @FXML
    private Button transactionHistory_HomeOwnership = new Button();
    @FXML
    private TextField depositHistoryAccountSearch_HomeOwnership = new TextField();
    @FXML
    private Button viewHistory_HomeOwnershipBtn =new Button();
    //Garanteed Pension Plan Section
    @FXML
    private ComboBox<String> garanteedPPMOPD=new ComboBox<>();
    @FXML
    private TextField memberNumber_GaranteedPension = new TextField();
    @FXML
    private TextField fullName_GarnteedPension = new TextField();
    @FXML
    private TextField depositAmount_GaranteedPension = new TextField();
    @FXML
    private DatePicker dateOfDeposit_GaranteedPension = new DatePicker();
    @FXML
    private Button saveTransAction_GaranteedPension= new Button();
    @FXML
    private Button transactionHistory_GaranteedPension = new Button();
    @FXML
    private TextField depositHistoryAccountSearch_GaranteedPension  = new TextField();
    @FXML
    private Button viewHistory_GaranteedPensionBtn = new Button();
    
    // Personal Pension Plan Section
    @FXML
    private ComboBox<String> PersonalPPMOPD = new ComboBox<>();
    @FXML
    private TextField memberNumber_PersonalPension = new TextField();
    @FXML
    private TextField fullName_PersonalPension = new TextField();
    private TextField depositAmount_PersonalPension = new TextField();
    @FXML
    private DatePicker dateOfDeposit_PersonalPension = new DatePicker();
    @FXML
    private Button saveTrnsaction_PersonalPensionBtn=new Button();
    @FXML
    private Button viewTransactionHistory_PersonalPensionBtn= new Button();
    @FXML
    private TextField depositHistoryAccountSearch_PersonalPension = new TextField();
    @FXML
    private Button viewHistory_PersonalPensionBtn= new Button();
    // Garantees pension plan Withdrawal
    @FXML
    private DatePicker dateOfwithdrawal_GaranteedPensionwithdrawal= new DatePicker();
    @FXML
    private TextField withdrawalAmount_GaranteedPensionwithdrawal = new TextField();
    @FXML
    private TextField fullName_GaranteedPensionwithdrawal = new TextField();
    @FXML
    private TextField memberNumber_GaranteedPensionWithdrawal = new TextField();
    @FXML
    private Button saveTransAction_GaranteedPensionwithdrawal= new Button();
     @FXML
    private Button transactionHistory_GaranteedPensionwithdrawal= new Button();
     
    private TextField withdrawFromInterestGaranteedpension = new TextField();
    //PersonalPension plan Withdrawal
    @FXML
    private Button saveTransAction_personalPensionwithdrawal = new Button();
    @FXML
    private TextField memberNumber_personalPensionwithdrawal = new TextField();
    @FXML
    private TextField fullName_personalPensionwithdrawal = new TextField();
    private TextField withdrawalAmount_personalPensionwithdrawal = new TextField();
    @FXML
    private DatePicker dateOfwithdrawal_personalPensionwithdrawal = new DatePicker();
     @FXML
    private Button transactionHistory_personalPensionwithdrawal= new Button();
    private TextField withdrawFromInterestpersonalPension = new TextField();
    //HomeOwnership Withdrawal
    @FXML
    private Button saveTransAction_HomeOwnershipwithdrawal= new Button();
    @FXML
    private Button transactionHistory_HomeOwnershipwithdrawal = new Button();
    @FXML
    private TextField memberNumber_HomeOwnershipwithdrawal = new TextField();
    @FXML
    private TextField fullName_HomeOwnershipwithdrawal = new TextField();
    @FXML
    private TextField depositAmount_HomeOwnershipwithdrawal = new TextField();
    @FXML
    private DatePicker dateOfWithdrawal_HomeOwnershipwithdrawal= new DatePicker();
     @FXML
    private TextField withdrawFromInterestHomeOwnership = new TextField();
    @FXML
    private CheckBox EditTableRadioBtn;
    @FXML
    private TableView<ObservableList> MoneyMarketDepositTableView;
    private TableView<ObservableList> MainTableView;
    @FXML
    private TableView<ObservableList> MainTableViewnew;
    EditableCell edit = new EditableCell();
    private TableView<ObservableList> searchDetailsTable;
    @FXML
    private ComboBox<String> chooseAccount;
    
    @FXML
    private ComboBox<String> garanteedPPMOPW;
    @FXML
    private Button viewWithdrawalsHomeOwnership;
    @FXML
    private Button viewWithdrawalGaranteedPension;
    @FXML
    private Button viewWithdrawalPersonalPension;
    @FXML
    private TableView<ObservableList> BalanceFundTransactionTable;
    @FXML
    private TableView<ObservableList> HomeOwnershipMainTable;
    @FXML
    private TableView<ObservableList> garanteedPensionMainTable;
    @FXML
    private TableView<ObservableList> personalPensionMainTable;
    @FXML
    private TableView<ObservableList> MainTableMMW;
    @FXML
    private Button viewTransactionHistoryWithdrawalField;
    @FXML
    private Button saveDetailsPersonalInfo;
    @FXML
    private TextField fullNameNextOfKin= new TextField();
    @FXML
    private TextField PurchaseAmount_PersonalPension= new TextField();
    @FXML
    private TextField withdrawAmountpersonalPension= new TextField();
    private TextField PurchaseNumber_personalPensionwithdrawal= new TextField();
    @FXML
    private TextField PurchaseNumberPersonalPensionDeposit= new TextField();
    @FXML
    private TextField UnitsPurchasedPersonalPensionDeposits= new TextField();
    @FXML
    private TextField PurchasePricePersonalPension= new TextField();
    @FXML
    private TextField UnitsSoldPersonalPensionWithdrawal= new TextField();
    @FXML
    private TextField SellPricePersonalPension= new TextField();
    @FXML
    private TextField PreviousMemberNumber= new TextField();
    @FXML
    private TextField memberNumberReport = new TextField();
    
    private CheckBox updateInterest = new CheckBox();
    
    @FXML
    private ImageView imageViewer=new ImageView();
    @FXML
    private ImageView imageViewer1=new ImageView();
   
    
    @FXML
    CheckBox smsNotify= new CheckBox();
    
    @FXML
    private Button uploadPhoto;
    
    @FXML
    private Button uploadSignature;
    
    private FileChooser fileChooser;
    private File file;
    private FileChooser fileChooser1;
    private File file1;
    private Image image;
    private Image image4;
    private FileInputStream image2;
    private FileInputStream image3;
    private Image image1;
    @FXML
    private DatePicker fromDate= new DatePicker();
    @FXML
    private DatePicker toDate= new DatePicker();
    @FXML
    private DatePicker specificDate= new DatePicker();
    @FXML
    private TextField transactionNumberMM= new TextField();
    @FXML
    private TextField transactionNumberHO= new TextField();
    @FXML
    private TextField transactionNumberGP= new TextField();
    @FXML
    private TextField TransNumberMMW= new TextField();
    @FXML
    private TextField TransNumberBFW = new TextField();
    @FXML
    private TextField TransNumberHOW = new TextField();
    @FXML
    private TextField TransNumberGPW = new TextField();
    @FXML
    private TextField TransNumberPPW= new TextField();
   
    @FXML
    private ListView<String> listview;
  
   
    ObservableList<String> oblist = FXCollections.observableArrayList();
    ObservableList<String> possibleALLNames = FXCollections.observableArrayList();
    ObservableList<String> possibleMemberNumbers = FXCollections.observableArrayList();
    ObservableList<String> possibleMemberNumbersPENSION = FXCollections.observableArrayList();
    ObservableMap<String, String> obsMap = FXCollections.observableHashMap();
    @FXML
    private Button newTransactionMMD;
    @FXML
    private Button newTransactionMMW;
    @FXML
    private Button newTransactionBFP;
    @FXML
    private Button newTransactionBFW;
    @FXML
    private Button newTransactionHOD;
    @FXML
    private Button newTransactionHOW;
    @FXML
    private Button newTransactionGPD;
    @FXML
    private Button newTransactionGPW;
    @FXML
    private Button newTransactionPPP;
    @FXML
    private Button newTransactionPPW;
    @FXML
    private ImageView imageViewProfile=new ImageView();
    @FXML
    private CheckBox IDSearch;
    @FXML
    private Button updateMemberDetails;
    @FXML
    private Button EditMemberDetails;
    @FXML
    private TextField fullNameSearch  = new TextField();
    @FXML
    private MenuItem ExitMenue;
    @FXML
    private MenuItem changePassword;
    
    @FXML
    private MenuBar myMenuBar= new MenuBar();
    
   
    
    /**
     * Initializes the controller class.
     */
    
    
    public void FetchMembersearchData(MemberSearch search){
        search.setFullNameSearchField(fullNameSearchField.getText());
    
    }
    
    
    public void FetchMoneyMarketDepositData(MoneyMarketDeposit deposit,MoneyMarketDepositLogic logic){
    	LocalDatePersistenceConverter date12= new LocalDatePersistenceConverter();
   /*  deposit.setTransactionNumber(transactionNumberMM.getText());
     deposit.setMemberNumber(memberNumberField.getText());
     deposit.setFullName(fullNameField.getText());
     deposit.setDepositAmount(depositAmountField.getText().replaceAll("[^0-9]", ""));
     deposit.setDateOfDeposit( dateOfDepositField.getValue()); 
     deposit.setModeOfPayment(MoneyMarketMOPDeposit.getValue());
     deposit.setSetByUser(userName);
     deposit.setTransactionNumber(transactionNumberMM.getText());
     logic.setMemberNumber(memberNumberField.getText());
     logic.setFullName(fullNameField.getText());
     logic.setDeposit(Double.parseDouble(depositAmountField.getText().replaceAll("[^0-9]", "")));
        try {
            logic.updateDatabaseValue();
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        */
        conn=JavaFirebirdconnect.connectDb();
     String sql1="INSERT INTO TRANS (TRANS_NO, TRANS_ID, TRANS_TYPE, TRANS_DATE, MEMBER_NO, FULL_NAME, ACCOUNT_NO, PORTFOLIO, MOP, AMOUNT, NETAMOUNT,NOOFSHARES,NAV,ADMIN_FEE,PRICE,SYSDATE, U_NAME) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?);";
     
     PreparedStatement preparedStatement;
	try {
		     preparedStatement = conn.prepareStatement(sql1);
		     preparedStatement.setString(1, transactionNumberMM.getText());
		     preparedStatement.setInt(2, Integer.parseInt(transactionNumberMM.getText()));
		     preparedStatement.setString(3, "PURCHASE");
		     preparedStatement.setTimestamp(4, date12.convertToTimestamp(date12.convertToDatabaseColumn(dateOfDepositField.getValue())));
		     preparedStatement.setString(5, memberNumberField.getText());
		     preparedStatement.setString(6, fullNameField.getText());
		     preparedStatement.setString(7,  memberNumberField.getText());
		     preparedStatement.setString(8, "Money Market");
		     preparedStatement.setString(9, MoneyMarketMOPDeposit.getValue());
		     preparedStatement.setDouble(10,Double.parseDouble(depositAmountField.getText().replaceAll("[^0-9]", "")));
		     preparedStatement.setDouble(11, Double.parseDouble(depositAmountField.getText().replaceAll("[^0-9]", "")));
		     preparedStatement.setString(12, "0.00");
		     preparedStatement.setDouble(13, 0.00);
		     preparedStatement.setDouble(14, 0.00);
		     preparedStatement.setDouble(15, 0.00);
		     preparedStatement.setTimestamp(16, date12.convertToTimestamp(date12.convertToDatabaseColumn(dateOfDepositField.getValue())));
		    /* preparedStatement.setTime(17, null);*/
		     preparedStatement.setString(17, userName);
		     preparedStatement .executeUpdate();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
     
  
   }
    public void sendSMSMM(){
     SendSms sms=new SendSms();
     
     String memb=memberNumberField.getText();
     sms.setMemberNumber(memberNumberField.getText());
     sms.setAmount(depositAmountField.getText());
     sms.setFullName(fullNameField.getText());
        try {
            sms.getPhoneNumber("UNIT_TRUST");
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            sms.sendSMS();
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ProtocolException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    
    }
    
    public String getAccountNumber(String MemberNumber) throws SQLException{
    	String ACCOUNT_NO="";
    	conn = JavaFirebirdconnect.connectDb();
		String sql1 = "SELECT * FROM ACCOUNTS WHERE MEMBER_NO ='";
		sql1 = sql1.concat(MemberNumber);
		sql1 = sql1.concat("' AND TRANS_TYPE  LIKE 'INTEREST' AND  AMOUNT > '0' ORDER BY TRANS_DATE DESC");
		System.out.println(sql1);
		Statement statement1234 = conn.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE,
                ResultSet.CONCUR_READ_ONLY);
		
		
		ResultSet rs1 = statement1234.executeQuery(sql1);
		if (rs1.isBeforeFirst()) {
		
			ACCOUNT_NO=rs1.getString("ACCOUNT_NO");
			
			

		}
    	return ACCOUNT_NO;
    	
    }
    
    
    public void FetchMoneyMarketWithdrawalData(String MOPTYPE){
    	LocalDatePersistenceConverter date12= new LocalDatePersistenceConverter();
        conn=JavaFirebirdconnect.connectDb();
    	if(MOPTYPE.equals("PRINCIPAL_WITHDRAWAL")){
    	
        String sql1="INSERT INTO TRANS (TRANS_NO, TRANS_ID, TRANS_TYPE, TRANS_DATE, MEMBER_NO, FULL_NAME, ACCOUNT_NO, PORTFOLIO, MOP, AMOUNT, NETAMOUNT,NOOFSHARES,NAV,ADMIN_FEE,PRICE,SYSDATE, U_NAME) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?);";
        
        PreparedStatement preparedStatement;
   	try {
   		     preparedStatement = conn.prepareStatement(sql1);
   		     preparedStatement.setString(1, TransNumberMMW.getText());
   		     preparedStatement.setInt(2, Integer.parseInt(TransNumberMMW.getText()));
   		     preparedStatement.setString(3, "WITHDRAWAL");
   		     preparedStatement.setTimestamp(4, date12.convertToTimestamp(date12.convertToDatabaseColumn(withdrawalDateWithdrawalField.getValue())));
   		     preparedStatement.setString(5, memberNumberWithdrawalField.getText());
   		     preparedStatement.setString(6, fullNamewithdrawalField.getText());
   		     preparedStatement.setString(7,  memberNumberWithdrawalField.getText());
   		     preparedStatement.setString(8, "Money Market");
   		     preparedStatement.setString(9, "EFT");
   		     preparedStatement.setDouble(10,Double.parseDouble(withdrawalAmountField.getText().replaceAll("[^0-9]", "")));
   		     preparedStatement.setDouble(11, Double.parseDouble(withdrawalAmountField.getText().replaceAll("[^0-9]", "")));
   		     preparedStatement.setString(12, "0.00");
   		     preparedStatement.setDouble(13, 0.00);
   		     preparedStatement.setDouble(14, 0.00);
   		     preparedStatement.setDouble(15, 0.00);
   		     preparedStatement.setTimestamp(16, date12.convertToTimestamp(date12.convertToDatabaseColumn(withdrawalDateWithdrawalField.getValue())));
   		    /* preparedStatement.setTime(17, null);*/
   		     preparedStatement.setString(17, userName);
   		     preparedStatement .executeUpdate();
   	} catch (SQLException e) {
   		// TODO Auto-generated catch block
   		e.printStackTrace();
   	}
    	}else if(MOPTYPE.equals("INTEREST_WITHDRAWAL")){

            String sql1="INSERT INTO TRANS (TRANS_NO, TRANS_ID, TRANS_TYPE, TRANS_DATE, MEMBER_NO, FULL_NAME, ACCOUNT_NO, PORTFOLIO, MOP, AMOUNT, NETAMOUNT,NOOFSHARES,NAV,ADMIN_FEE,PRICE,SYSDATE, U_NAME) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?);";
            
            PreparedStatement preparedStatement;
       	try {
       		     preparedStatement = conn.prepareStatement(sql1);
       		     preparedStatement.setString(1, TransNumberMMW.getText());
       		     preparedStatement.setInt(2, Integer.parseInt(TransNumberMMW.getText()));
       		     preparedStatement.setString(3, "INTEREST");
       		     preparedStatement.setTimestamp(4, date12.convertToTimestamp(date12.convertToDatabaseColumn(withdrawalDateWithdrawalField.getValue())));
       		     preparedStatement.setString(5, memberNumberWithdrawalField.getText());
       		     preparedStatement.setString(6, fullNamewithdrawalField.getText());
       		     preparedStatement.setString(7,  memberNumberWithdrawalField.getText());
       		     preparedStatement.setString(8, "Money Market");
       		     preparedStatement.setString(9, "EFT");
       		     preparedStatement.setDouble(10,(Double.parseDouble(withdrawalAmountField.getText().replaceAll("[^0-9]", ""))-(Double.parseDouble(withdrawalAmountField.getText().replaceAll("[^0-9]", ""))*2)));
       		     preparedStatement.setDouble(11, (Double.parseDouble(withdrawalAmountField.getText().replaceAll("[^0-9]", ""))-(Double.parseDouble(withdrawalAmountField.getText().replaceAll("[^0-9]", ""))*2)));
       		     preparedStatement.setString(12, "0.00");
       		     preparedStatement.setDouble(13, 0.00);
       		     preparedStatement.setDouble(14, 0.00);
       		     preparedStatement.setDouble(15, 0.00);
       		     preparedStatement.setTimestamp(16, date12.convertToTimestamp(date12.convertToDatabaseColumn(withdrawalDateWithdrawalField.getValue())));
       		    /* preparedStatement.setTime(17, null);*/
       		     preparedStatement.setString(17, userName);
       		     preparedStatement .executeUpdate();
       	} catch (SQLException e) {
       		// TODO Auto-generated catch block
       		e.printStackTrace();
       	}
    		
    	}
      
        
   	 
    }
    
    public void sendSMSMMwithdrawal(){
        SendSms sms=new SendSms();
        sms.setMemberNumber(memberNumberWithdrawalField.getText());
        sms.setAmount(withdrawalAmountField.getText());
        sms.setFullName(fullNamewithdrawalField.getText());
           try {
               sms.getPhoneNumber("UNIT_TRUST");
           } catch (SQLException ex) {
               Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
           }
           try {
               sms.sendSMSWithdrawal();
           } catch (UnsupportedEncodingException ex) {
               Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
           } catch (ProtocolException ex) {
               Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
           } catch (IOException ex) {
               Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
           }
       
       
       }
    
    public BalanceFundPurchase fundTransferBalanceFundPurchase() throws SQLException{
        BalanceFundPurchase purchase = new BalanceFundPurchase();
        BalanceFundPurchaseLogic logic= new BalanceFundPurchaseLogic();
        Random randomGenerator = new Random();
        Integer randonInt= randomGenerator.nextInt(1000000000);
        purchase.setPurchaseNumberBalanceFundPurchase(randonInt.toString());
        purchase.setMemberNumber(memberNumberFundTransfer.getText());
        purchase.setFullName(fullNameFundTransfer.getText());
        purchase.setPurchaseAmount(transferAmount_fundTransfer.getText());
        double amount = Double.parseDouble(transferAmount_fundTransfer.getText());
        Double buyPrice = logic.getsellPriceFromDB();
        Double units=amount/buyPrice;
        DecimalFormat f = new DecimalFormat("##.0000");
        String Funits=f.format(units);
        purchase.setPurchasePrice(buyPrice.toString());
        purchase.setUnitsPurchased(Funits);
        purchase.setDateOfPurchase(dateOfTransfer_fundTreansfer.getValue());
        purchase.setModeOfPaymment("Internal Transfer From MoneyMarket");
        logic.setFullName(fullNameFundTransfer.getText());
        logic.setMemberNumber(memberNumberFundTransfer.getText());
        logic.setPurchaseNumber(randonInt.toString());
        logic.setUnitsPurchased(Double.parseDouble(Funits));
        logic.setPurchaseAmount(Double.parseDouble(transferAmount_fundTransfer.getText()));
        try {
            logic.updateDatabaseValue();
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        purchase.setUserName(userName);
        return purchase;
        
        
        
        
    }
    
    public void FetchBalanceFundPurchaseData(BalanceFundPurchase purchase,BalanceFundPurchaseLogic logic){
        
       
         
       /* purchase.setPurchaseNumberBalanceFundPurchase(PurchaseNumberBalanceFundPurchase.getText());
        purchase.setMemberNumber(memberNumberPurchasesfield.getText());
        purchase.setFullName(fulNamePurchasesField.getText());
        purchase.setPurchaseAmount(purchaseAmountPurchasesField.getText().replaceAll("[^0-9]", ""));
        double amount = Double.parseDouble(purchaseAmountPurchasesField.getText().replaceAll("[^0-9]", ""));
        double buyPrice = Double.parseDouble(purchasePricePurchasefield.getText());
        Double units=amount/buyPrice;
        DecimalFormat f = new DecimalFormat("##.00");
        String Funits=f.format(units);
        unitsPurchasedPurchasesField.setText(Funits);
        purchase.setPurchasePrice(purchasePricePurchasefield.getText());
        purchase.setUnitsPurchased(unitsPurchasedPurchasesField.getText());
        purchase.setDateOfPurchase(dateOfPurchasePurchasesField.getValue());
        purchase.setModeOfPaymment(balabceFundMOPP.getValue());
        purchase.setUserName(userName);
        logic.setFullName(fulNamePurchasesField.getText());
        logic.setMemberNumber(memberNumberPurchasesfield.getText());
        logic.setPurchaseNumber(PurchaseNumberBalanceFundPurchase.getText());
        logic.setUnitsPurchased(Double.parseDouble(unitsPurchasedPurchasesField.getText()));
        logic.setPurchaseAmount(Double.parseDouble(purchaseAmountPurchasesField.getText().replaceAll("[^0-9]", "")));
        try {
            logic.updateDatabaseValue();
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }*/
    	 double amount = Double.parseDouble(purchaseAmountPurchasesField.getText().replaceAll("[^0-9]", ""));
         double buyPrice = Double.parseDouble(purchasePricePurchasefield.getText());
         Double units=amount/buyPrice;
         DecimalFormat f = new DecimalFormat("##.00");
         String Funits=f.format(units);
         unitsPurchasedPurchasesField.setText(Funits);
        LocalDatePersistenceConverter date12= new LocalDatePersistenceConverter();
        
        conn=JavaFirebirdconnect.connectDb();
        String sql1="INSERT INTO TRANS (TRANS_NO, TRANS_ID, TRANS_TYPE, TRANS_DATE, MEMBER_NO, FULL_NAME, ACCOUNT_NO, PORTFOLIO, MOP, AMOUNT, NETAMOUNT,NOOFSHARES,NAV,ADMIN_FEE,PRICE,SYSDATE, U_NAME) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?);";
        
        PreparedStatement preparedStatement;
   	try {
   		     preparedStatement = conn.prepareStatement(sql1);
   		     preparedStatement.setString(1, PurchaseNumberBalanceFundPurchase.getText());
   		     preparedStatement.setInt(2, Integer.parseInt(PurchaseNumberBalanceFundPurchase.getText()));
   		     preparedStatement.setString(3, "PURCHASE");
   		     preparedStatement.setTimestamp(4, date12.convertToTimestamp(date12.convertToDatabaseColumn(dateOfPurchasePurchasesField.getValue())));
   		     preparedStatement.setString(5, memberNumberPurchasesfield.getText());
   		     preparedStatement.setString(6, fulNamePurchasesField.getText());
   		     preparedStatement.setString(7,  memberNumberPurchasesfield.getText());
   		     preparedStatement.setString(8, "Balanced Fund");
   		     preparedStatement.setString(9, balabceFundMOPP.getValue());
   		     preparedStatement.setDouble(10,Double.parseDouble(purchaseAmountPurchasesField.getText().replaceAll("[^0-9]", "")));
   		     preparedStatement.setDouble(11, Double.parseDouble(purchaseAmountPurchasesField.getText().replaceAll("[^0-9]", "")));
   		     preparedStatement.setString(12, unitsPurchasedPurchasesField.getText());
   		     preparedStatement.setDouble(13, Double.valueOf(purchasePricePurchasefield.getText())-(Double.valueOf(purchasePricePurchasefield.getText())*0.03));
   		     preparedStatement.setDouble(14, (Double.valueOf(purchasePricePurchasefield.getText())*0.03));
   		     preparedStatement.setDouble(15,Double.valueOf(purchasePricePurchasefield.getText()));
   		    /* preparedStatement.setTime(16, null);*/
   		     preparedStatement.setTimestamp(16, date12.convertToTimestamp(date12.convertToDatabaseColumn(dateOfPurchasePurchasesField.getValue())));
   		     preparedStatement.setString(17, userName);
   		     preparedStatement .executeUpdate();
   	} catch (SQLException e) {
   		// TODO Auto-generated catch block
   		e.printStackTrace();
   	}
     
        
    }
    public void sendSMSBF(){
    
    SendSms sms=new SendSms();
     sms.setMemberNumber(memberNumberPurchasesfield.getText());
     sms.setAmount(purchaseAmountPurchasesField.getText());
     sms.setFullName(fulNamePurchasesField.getText());
        try {
            sms.getPhoneNumber("UNIT_TRUST");
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            sms.sendSMS();
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ProtocolException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    
    }
    
    public BalanceFundWithdrawal fundTransferBalanceFundWithdrawal() throws SQLException {
        BalanceFundWithdrawal withdrawal= new BalanceFundWithdrawal();
        BalanceFundWithdrawalLogic logic= new BalanceFundWithdrawalLogic();
        withdrawal.setMemberNumber(memberNumberFundTransfer.getText());
        withdrawal.setFullName(fullNameFundTransfer.getText());
        withdrawal.setWithdrawalAmount(transferAmount_fundTransfer.getText());
        double amount = Double.parseDouble(transferAmount_fundTransfer.getText());
        Double sellPrice = logic.getsellPriceFromDB();
        Double units=amount/sellPrice;
        DecimalFormat f = new DecimalFormat("##.00");
        String Funits=f.format(units);
       
        withdrawal.setUnitsSold(Funits);
        withdrawal.setDateOfWithdrawal(dateOfTransfer_fundTreansfer.getValue());
        withdrawal.setModeOfPaymment("Internal Transfer BalanceFund To MoneyMarket");
        withdrawal.setSellPrice(sellPrice.toString());
        logic.setFullName(fullNameFundTransfer.getText());
        logic.setMemberNumber(memberNumberFundTransfer.getText());
        logic.setUnitsSold(Double.parseDouble(Funits));
        logic.setWithdrawalAmount(Double.parseDouble(transferAmount_fundTransfer.getText()));
        try {
            logic. updateDatabaseValue();
           
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            logic. updateDatabaseValue1();
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        withdrawal.setSetByUser(userName);
        return withdrawal;
        
    }
    
    public void FetchBalanceFundWithdrawalData(BalanceFundWithdrawal withdrawal,BalanceFundWithdrawalLogic logic){
  /*  withdrawal.setTRANS_NO(TransNumberBFW.getText());
    withdrawal.setMemberNumber(memberNumberwithdrawalField.getText());
    withdrawal.setFullName(fullNamewithdrawalFieldBalanceFund.getText());
    withdrawal.setWithdrawalAmount(purchaseAmountWithdrawalField.getText().replaceAll("[^0-9]", ""));
   
    
    double amount = Double.parseDouble(purchaseAmountWithdrawalField.getText().replaceAll("[^0-9]", ""));
    double sellPrice = Double.parseDouble(sellPriceWithdrawalsField.getText());
    Double units=amount/sellPrice;
    DecimalFormat f = new DecimalFormat("##.00");
    String Funits=f.format(units);
    unitsSoldWithdrwalField.setText(Funits);
    
    withdrawal.setUnitsSold(unitsSoldWithdrwalField.getText());
    withdrawal.setDateOfWithdrawal(dateOfWithdrawalWithdrawalsField.getValue());
    withdrawal.setModeOfPaymment(balabceFundMOPW.getValue());
    withdrawal.setSetByUser(userName);
        
        
      
    withdrawal.setSellPrice(sellPriceWithdrawalsField.getText());
   // withdrawal.setPurchaseNumberBalanceFundWithdrawal(PurchaseNumberBalanceFundWithdrawal.getText());
    logic.setMemberNumber(memberNumberwithdrawalField.getText());
    logic.setFullName(fullNamewithdrawalFieldBalanceFund.getText());
    logic.setPurchaseNumber(PurchaseNumberBalanceFundWithdrawal.getText());
    System.out.println(PurchaseNumberBalanceFundWithdrawal.getText());
    logic.setUnitsSold(Double.parseDouble(unitsSoldWithdrwalField.getText()));
    logic.setWithdrawalAmount(Double.parseDouble(purchaseAmountWithdrawalField.getText().replaceAll("[^0-9]", "")));
    logic.setSellprice(Double.parseDouble(sellPriceWithdrawalsField.getText()));
        try {
            logic. updateDatabaseValue();
           
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            logic. updateDatabaseValue1();
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }*/
    
        double amount = Double.parseDouble(purchaseAmountWithdrawalField.getText().replaceAll("[^0-9]", ""));
        double sellPrice = Double.parseDouble(sellPriceWithdrawalsField.getText());
        Double units=amount/sellPrice;
        DecimalFormat f = new DecimalFormat("##.00");
        String Funits=f.format(units);
        unitsSoldWithdrwalField.setText(Funits);
      LocalDatePersistenceConverter date12= new LocalDatePersistenceConverter();
        
        conn=JavaFirebirdconnect.connectDb();
        String sql1="INSERT INTO TRANS (TRANS_NO, TRANS_ID, TRANS_TYPE, TRANS_DATE, MEMBER_NO, FULL_NAME, ACCOUNT_NO, PORTFOLIO, MOP, AMOUNT, NETAMOUNT,NOOFSHARES,NAV,ADMIN_FEE,PRICE,SYSDATE, U_NAME) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?);";
        
        PreparedStatement preparedStatement;
   	try {
   		     preparedStatement = conn.prepareStatement(sql1);
   		     preparedStatement.setString(1, TransNumberBFW.getText());
   		     preparedStatement.setInt(2, Integer.parseInt(TransNumberBFW.getText()));
   		     preparedStatement.setString(3, "WITHDRAWAL");
   		     preparedStatement.setTimestamp(4, date12.convertToTimestamp(date12.convertToDatabaseColumn(dateOfWithdrawalWithdrawalsField.getValue())));
   		     preparedStatement.setString(5, memberNumberwithdrawalField.getText());
   		     preparedStatement.setString(6, fullNamewithdrawalFieldBalanceFund.getText());
   		     preparedStatement.setString(7,  memberNumberwithdrawalField.getText());
   		     preparedStatement.setString(8, "Balanced Fund");
   		     preparedStatement.setString(9, "EFT");
   		     preparedStatement.setDouble(10,Double.parseDouble(purchaseAmountWithdrawalField.getText().replaceAll("[^0-9]", "")));
   		     preparedStatement.setDouble(11, Double.parseDouble(purchaseAmountWithdrawalField.getText().replaceAll("[^0-9]", "")));
   		     preparedStatement.setString(12, unitsSoldWithdrwalField.getText());
   		     preparedStatement.setDouble(13, Double.valueOf(sellPriceWithdrawalsField.getText()));
   		     preparedStatement.setDouble(14, (Double.valueOf(sellPriceWithdrawalsField.getText())*0.03));
   		     preparedStatement.setDouble(15,Double.valueOf(sellPriceWithdrawalsField.getText()));
   		    /* preparedStatement.setTime(16, null);*/
   		     preparedStatement.setTimestamp(16, date12.convertToTimestamp(date12.convertToDatabaseColumn(dateOfWithdrawalWithdrawalsField.getValue())));
   		     preparedStatement.setString(17, userName);
   		     preparedStatement .executeUpdate();
   	} catch (SQLException e) {
   		// TODO Auto-generated catch block
   		e.printStackTrace();
   	}
        
    }
    
    
    public void sendSMSBFWithdrawal(){
        
        SendSms sms=new SendSms();
         sms.setMemberNumber(memberNumberwithdrawalField.getText());
         sms.setAmount(purchaseAmountWithdrawalField.getText());
         sms.setFullName(fullNamewithdrawalFieldBalanceFund.getText());
            try {
                sms.getPhoneNumber("UNIT_TRUST");
            } catch (SQLException ex) {
                Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
            }
            try {
                sms.sendSMSWithdrawal();
            } catch (UnsupportedEncodingException ex) {
                Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ProtocolException ex) {
                Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        
        }
    
     PersonalInformationLogic logic = new PersonalInformationLogic();
     
     
       public void editNumber(String fundType){
            try {
                  logic.getMemberNumberFromDB(fundType);
              } catch (SQLException ex) {
                  Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
              }
              Integer number=logic.getMemberNumber();
              String number1=String.format("%09d", number);
              
              System.out.println(number);
              String sequence;
              number++;
              sequence = String.format("%09d", number);
              memberNumberPersonalInfo.setText(sequence);
               System.out.println("new MemberNumber :"+sequence);

    }
       public Integer getLastTransactionNumber(String fund){
           String unittrust="";
            String pensionfunds="";
            String HomeOwnership="";
            int transnumber=0;
            conn=javaconnect.connectDb1();
                try{
                String sql="SELECT * FROM `last transaction number` ";
                statement=conn.prepareStatement(sql,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
                result=statement.executeQuery();
                if(result.next()){
                     unittrust=result.getString("unittrust");
                     pensionfunds=result.getString("pensionfunds");
                    HomeOwnership=result.getString("HomeOwnership");
                    if("unittrust".equals(fund)){
                        transnumber=Integer.parseInt(unittrust);
                        Integer returnString=Integer.parseInt(unittrust);
                        returnString++;
                          result.updateString("unittrust", returnString.toString());
                          result.updateRow();
                    }else if("pensionfunds".equals(fund)){
                        transnumber=Integer.parseInt(pensionfunds); 
                        Integer returnString=Integer.parseInt(pensionfunds);
                        returnString++;
                          result.updateString("pensionfunds", returnString.toString());
                          result.updateRow();
                    }else if("HomeOwnership".equals(fund)){
                     transnumber=Integer.parseInt(HomeOwnership);
                     Integer returnString=Integer.parseInt(HomeOwnership);
                        returnString++;
                          result.updateString("HomeOwnership", returnString.toString());
                          result.updateRow();
                    }
                }

                }catch(Exception e){
                    Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, e);
                Alert alert2= new Alert(Alert.AlertType.ERROR);
                alert2.setContentText(e.toString());
                alert2.showAndWait();

                }
    
    return transnumber++;
    
    }
       
    public void FetchPersonalInformation(PersonalInformation personalInfo) throws FileNotFoundException{
       
        
        logic.setMemberNumber_Photo(memberNumberPersonalInfo.getText());
        logic.setFullName(FullNamePersonalInfo.getText());
        personalInfo.setMemberNumber(memberNumberPersonalInfo.getText());
        personalInfo.setIdentificationNumber(IDNumberPersonalInfo.getText());
        personalInfo.setFirstName(firstNamePersonalInfo.getText());
        personalInfo.setLastname(lastNamePersonalInfo.getText());
        personalInfo.setSurName(surNamePersonalInfo.getText());
        personalInfo.setFullName(FullNamePersonalInfo.getText());
        personalInfo.setDateOfBirth(dateOfBirthPersonalInfo.getValue());
        personalInfo.setDateOfRegistration(dateOfRegistrationPersonalInfo.getValue());
        personalInfo.setEmailAddress(EmailAddressPersonalInfo.getText());
        personalInfo.setPyhsicalAddress(physicalAddressPersonalInfo.getText());
        personalInfo.setPhoneNumber(phoneNumberPersonalInfo.getText());
        personalInfo.setPostalCode(postalAddressPersonalInfo.getText());
        personalInfo.setResidentTown(ResidentTownPersonalInfo.getText());
        personalInfo.setCounty(residentCountyPersonalInfo.getText());
        personalInfo.setGender(genderPersonalInfo.getValue());
        personalInfo.setMaritalStutus(maritalStutus.getValue());
        personalInfo.setMemberType(memberType.getValue());
        personalInfo.setSavedByUser(userName);
        try {
            logic.savePassportPhoto();
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        String notify="N";
        if(smsNotify.isSelected()){
        	
        	notify="Y";
        	}
        String sql="";
       
        LocalDatePersistenceConverter date12= new LocalDatePersistenceConverter();
        if(chooseFundType.getValue().equals("UNIT_TRUST")){
        	 conn=JavaFirebirdconnect.connectDb();
             
       	  sql="INSERT INTO MEMBERS (MEMBER_NO,CUSTOMER_NAME,SURNAME,LASTNAME,OTHERNAMES,ALLNAMES,POST_ADDRESS,REG_DATE,TEL_NO,TOWN,STREET,COUNTRY,SMS_NTFY,GSM_NO,E_MAIL,ID_NO,PICTURE,SIGNATURE,DOB,GENDER,MARITALSTATUS,UNAME)"
           		+ " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        }else if(chooseFundType.getValue().equals("PENSION")){
        	
        	conn=JavaFirebirdconnect.connectDb1();
        	  sql="INSERT INTO MEMBERS (MEMBER_NO,FIRSTNAME,SURNAME,LASTNAME,OTHERNAMES,ALLNAMES,POST_ADDRESS,REG_DATE,TEL_NO,TOWN,STREET,COUNTRY,SMS_NTFY,GSM_NO,E_MAIL,ID_NO,PICTURE,SIGNATURE,DOB,GENDER,MARITALSTATUS,UNAME)"
             		+ " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        }
        
        PreparedStatement preparedStatement;
   	try {
   		System.out.println(sql);
   		     preparedStatement = conn.prepareStatement(sql);
   		     preparedStatement.setString(1, memberNumberPersonalInfo.getText());
	   		 preparedStatement.setString(2, firstNamePersonalInfo.getText());
	   		 preparedStatement.setString(3, surNamePersonalInfo.getText());
	   		 preparedStatement.setString(4, lastNamePersonalInfo.getText());
	   		 preparedStatement.setString(5, lastNamePersonalInfo.getText());
	   		 preparedStatement.setString(6, FullNamePersonalInfo.getText());
	   		 preparedStatement.setString(7, postalAddressPersonalInfo.getText());
	   		 preparedStatement.setTimestamp(8, date12.convertToTimestamp(date12.convertToDatabaseColumn(dateOfRegistrationPersonalInfo.getValue())));
   		     preparedStatement.setString(9, phoneNumberPersonalInfo.getText());
	   		 preparedStatement.setString(10, ResidentTownPersonalInfo.getText());
	   		 preparedStatement.setString(11, physicalAddressPersonalInfo.getText());
		   	 preparedStatement.setString(12, residentCountyPersonalInfo.getText());
		     preparedStatement.setString(13, notify);
		   	 preparedStatement.setString(14, phoneNumberPersonalInfo.getText());
		   	 preparedStatement.setString(15, EmailAddressPersonalInfo.getText());
		   	 preparedStatement.setString(16, IDNumberPersonalInfo.getText());
		   	 preparedStatement.setBinaryStream(17, new FileInputStream(file));
		   	 preparedStatement.setBinaryStream(18, new FileInputStream(file1));
		   	 preparedStatement.setTimestamp(19,date12.convertToTimestamp(date12.convertToDatabaseColumn(dateOfBirthPersonalInfo.getValue())));
		   	 preparedStatement.setString(20, genderPersonalInfo.getValue());
			 preparedStatement.setString(21, maritalStutus.getValue());
			 preparedStatement.setString(22, userName);
			 preparedStatement .executeUpdate();
			 
			 Alert alert = new Alert(Alert.AlertType.INFORMATION);
             alert.setContentText("Data saved Successfull !");
           alert.showAndWait();
   	} catch (SQLException e) {
   		// TODO Auto-generated catch block
   		e.printStackTrace();
   	}
        
        
        
     
    }
    
    public  byte [] ImageToBlob(File file) throws IOException{
    	  BufferedImage bImage = ImageIO.read(file);
          ByteArrayOutputStream bos = new ByteArrayOutputStream();
          ImageIO.write(bImage, "jpg", bos );
          byte [] data = bos.toByteArray();
    	
          return data;
    }
    public void FetchNextOfKinInformation(NextOfKinInformation NOKInfo) throws FileNotFoundException{
        
        NOKInfo.setMemberNumber(MemberNumberNextOfKin.getText());
        NOKInfo.setFirstName(firstNameNextOfKin.getText());
        NOKInfo.setLastname(lastNameNextOfKin.getText());
        NOKInfo.setSurName(surNameNextOfKin.getText());
        NOKInfo.setFullName(fullNameNextOfKin.getText());
        NOKInfo.setDateOfRegistration(dateOfRegistrationNextOfKin.getValue());
        NOKInfo.setIdentificationNumber(IDNumberNextOfKin.getText());
        NOKInfo.setEmailAddress(EmailAddressNextOfKin.getText());
        NOKInfo.setPyhsicalAddress(physicalAddressNextOfKin.getText());
        NOKInfo.setPhoneNumber(phoneNumberNextOfKin.getText());
        NOKInfo.setPostalCode(postalAddressNextOfKin.getText());
        NOKInfo.setRelationship(relationshipTooNextOfKin.getText());
        NOKInfo.setPercentage(persentageNextOfKin.getText());
        NOKInfo.setSavedByUser(userName);
        
        String sql="";
        LocalDatePersistenceConverter date12= new LocalDatePersistenceConverter();
        if(chooseFundType.getValue().equals("UNIT_TRUST")){
        	 conn=JavaFirebirdconnect.connectDb();
             
       	  sql="INSERT INTO BENEFICIARIES (MEMBER_NO,F_NAME,SURNAME,LASTNAME,OTHERNAMES,ALLNAMES,POST_ADDRESS,REG_DATE,TEL_NO,TOWN,PHYS_ADDRESS,COUNTRY,RELATIONSHIP,GSM_NO,E_MAIL,ID_NO,PICTURE,SIGNATURE,DOB,GENDER,TRANS_NO,UNAME)"
           		+ " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        }else if(chooseFundType.getValue().equals("PENSION")){
        	
        	conn=JavaFirebirdconnect.connectDb1();
        	  sql="INSERT INTO BENEFICIARIES (MEMBER_NO,F_NAME,SURNAME,LASTNAME,OTHERNAMES,ALLNAMES,POST_ADDRESS,REG_DATE,TEL_NO,TOWN,STREET,COUNTRY,SMS_NTFY,GSM_NO,E_MAIL,ID_NO,PICTURE,SIGNATURE,DOB,GENDER,TRANS_NO,UNAME)"
             		+ " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        }
        
        PreparedStatement preparedStatement;
   	try {
   		System.out.println(sql);
   		     preparedStatement = conn.prepareStatement(sql);
   		     preparedStatement.setString(1, memberNumberPersonalInfo.getText());
	   		 preparedStatement.setString(2, firstNamePersonalInfo.getText());
	   		 preparedStatement.setString(3, surNamePersonalInfo.getText());
	   		 preparedStatement.setString(4, lastNamePersonalInfo.getText());
	   		 preparedStatement.setString(5, lastNamePersonalInfo.getText());
	   		 preparedStatement.setString(6, FullNamePersonalInfo.getText());
	   		 preparedStatement.setString(7, postalAddressPersonalInfo.getText());
	   		 preparedStatement.setTimestamp(8, date12.convertToTimestamp(date12.convertToDatabaseColumn(dateOfRegistrationPersonalInfo.getValue())));
   		     preparedStatement.setString(9, phoneNumberPersonalInfo.getText());
	   		 preparedStatement.setString(10, ResidentTownPersonalInfo.getText());
	   		 preparedStatement.setString(11, physicalAddressPersonalInfo.getText());
		   	 preparedStatement.setString(12, residentCountyPersonalInfo.getText());
		     preparedStatement.setString(13, "");
		   	 preparedStatement.setString(14, phoneNumberPersonalInfo.getText());
		   	 preparedStatement.setString(15, EmailAddressPersonalInfo.getText());
		   	 preparedStatement.setString(16, IDNumberPersonalInfo.getText());
		   	 preparedStatement.setBinaryStream(17, new FileInputStream(file));
		   	 preparedStatement.setBinaryStream(18, new FileInputStream(file1));
		   	 preparedStatement.setTimestamp(19,date12.convertToTimestamp(date12.convertToDatabaseColumn(dateOfBirthPersonalInfo.getValue())));
		   	 preparedStatement.setString(20, genderPersonalInfo.getValue());
			 preparedStatement.setString(21, maritalStutus.getValue());
			 preparedStatement.setString(22, userName);
			 preparedStatement .executeUpdate();
			 
			 Alert alert = new Alert(Alert.AlertType.INFORMATION);
             alert.setContentText("Data saved Successfull !");
           alert.showAndWait();
   	} catch (SQLException e) {
   		// TODO Auto-generated catch block
   		e.printStackTrace();
   	}
          
    }
    
    public void FetchInvestmentApplicationDate(InvestmentApplication invest,BalanceFundAccount bf,
            MoneyMarketAccounts MM,HomeOwnershipAccounts HOA,GaranteedPensionAccount gp,PersonalPensionAccounts pp){
  
    invest.setMemberNumber(memberNumberInvestmentApplication.getText());
    invest.setFullName(fullNameInvestmentApplication.getText());
    invest.setAccountType(AccountTypeInvestmentApplication.getValue());
    invest.setInvestmentType(investmentTypeInvestmentApplication.getValue());
    invest.setDateOfApplication(DateOfApplicationInvestmentApplication.getValue());
    invest.setBankAccountName(BankAccountNameBankDetails.getText());
    invest.setBankName(BankNameBankDetails.getText());
    invest.setAccountNumber(accountNumberBankDetails.getText());
    invest.setBranchLocation(branchLocationBankDetails.getText());
    invest.setKRAPin(KRAPinBankDetails.getText());
    invest.setSavedByUser(userName);
    String investMentType=investmentTypeInvestmentApplication.getValue();
   
        if("MoneyMarket".equals(investMentType)){
            MM.setMemberNumber(memberNumberInvestmentApplication.getText());
            MM.setFullName(fullNameInvestmentApplication.getText());
            MM.saveMoneyMarketAccount();
    
        }else if(investMentType=="HomeOwnerShip"){
            HOA.setMemberNumber(memberNumberInvestmentApplication.getText());
            HOA.setFullName(fullNameInvestmentApplication.getText());
            HOA.saveHomeOwnershipAccount();
        }else  if(investMentType=="GaranteedPension"){
            gp.setMemberNumber(memberNumberInvestmentApplication.getText());
            gp.setFullName(fullNameInvestmentApplication.getText());
            gp.saveGaranteedPensionAccount();
        
        }else if(investMentType=="BalanceFund"){
            
            bf.setMemberNumber(memberNumberInvestmentApplication.getText());
            bf.setFullName(fullNameInvestmentApplication.getText());
            bf.saveBalanceFundAccount();
            
        }else if(investMentType=="PersonalPension"){
            pp.setMemberNumber(memberNumberInvestmentApplication.getText());
            pp.setFullName(fullNameInvestmentApplication.getText());
            pp.savePersonalPensionAccount();
        
        }
   
    } 
    
    public void FetchFundTransferData(FundTransfer transfer){
      
    UnitTrustTransfer fundTransfer= new UnitTrustTransfer();
    PensionFundTransfer transfer1 =new PensionFundTransfer();
    System.out.println("this is the memberNumber from the fxmlcontroller"+memberNumberFundTransfer.getText());
    transfer.setMemberNumber(memberNumberFundTransfer.getText());
    transfer.setFullName(fullNameFundTransfer.getText());
    transfer.setAccountType(accountTypeFundTransfer.getValue());
    transfer.setFromInvestmentType(fromInvestmentType_FundTransfer.getValue());
    transfer.setToInvestmentType(toInvestmentType_fundTransfer.getValue());
    transfer.setTransferAmount(transferAmount_fundTransfer.getText());
    transfer.setDateOfTransfer(dateOfTransfer_fundTreansfer.getValue());
     String frominvestMentType=fromInvestmentType_FundTransfer.getValue();
     String toinvestMentType=toInvestmentType_fundTransfer.getValue();
     fundTransfer.setMemberNumber(memberNumberFundTransfer.getText());
     fundTransfer.setTransferAmount(transferAmount_fundTransfer.getText());
     transfer1.setMemberNumber(memberNumberFundTransfer.getText());
     transfer1.setTransferAmount(transferAmount_fundTransfer.getText());
     
    if("MoneyMarket".equals(frominvestMentType)&&"BalanceFund".equals(toinvestMentType)){
       
         HibernateConnector connector= new HibernateConnector() ;
        try {
           fundTransfer.MoneyMarketToBalanceFundTransfer();
            BalanceFundPurchase purchase =fundTransferBalanceFundPurchase();
            connector.MakeHibernateTransaction(purchase);
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }else if("BalanceFund".equals(frominvestMentType)&&"MoneyMarket".equals(toinvestMentType)){
        
         HibernateConnector connector= new HibernateConnector() ;
        try {
              BalanceFundWithdrawal withdrawal= fundTransferBalanceFundWithdrawal();
              connector.MakeHibernateTransaction(withdrawal);
            fundTransfer.BalanceFundToMoneyMarket();
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }else if("GuaranteedPension".equals(frominvestMentType)&&"PersonalPension".equals(toinvestMentType)){
    HibernateConnector connector= new HibernateConnector() ;
        try {
            PersonalPensionDeposit deposit=fundTransferPersonalPensionDeposit();
              connector.MakeHibernateTransaction(deposit);
           transfer1.GaranteedPensionToPersonalPensionTransfer();
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    
    }else if("PersonalPension".equals(frominvestMentType)&&"GuaranteedPension".equals(toinvestMentType)){
    
     HibernateConnector connector= new HibernateConnector() ;
        try {
            PersonalPensionWithdrawal withdrawal=fundTransferPersonalPensionWithdrawal();
              connector.MakeHibernateTransaction(withdrawal);
           transfer1.PersonalPensionToGaranteedPension();
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }
    
   
    transfer.setSavedByUser(userName);
    
    }
    
    public void FetchHomeOwnershipDepositData(HomeOwnershipDeposit deposit,HomeOwnershipDepositLogic logic){
    
    deposit.setTransactionNumber(transactionNumberHO.getText());
    deposit.setMemberNumber(memberNumber_HomeOwnership.getText());
    deposit.setFullName(fullName_HomeOwnership.getText());
   // deposit.setDepositAmount(DepositAmmount_HomeOwnership.getText());
    deposit.setDateOfDeposit(dateOfDeposit_HomeOwnership.getValue());
    deposit.setModeOfPayment(homeOwnershipMOPD.getValue());
    deposit.setSetByUser(userName);
    deposit.setTransactionNumber(transactionNumberHO.getText());
    logic.setMemberNumber(memberNumber_HomeOwnership.getText());
    logic.setFullName(fullName_HomeOwnership.getText());
   // logic.setDeposit(Double.parseDouble(DepositAmmount_HomeOwnership.getText()));
        try {
            logic.updateDatabaseValue();
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
       
    
    
    }
    /*public void sendSMSHO(){
     SendSms sms=new SendSms();
     sms.setMemberNumber(memberNumber_HomeOwnership.getText());
     sms.setAmount(DepositAmmount_HomeOwnership.getText());
     sms.setFullName(fullName_HomeOwnership.getText());
        try {
            sms.getPhoneNumber();
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            sms.sendSMS();
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ProtocolException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }
    
    */
    public void FetchHomeOwnershipWithdrawalData(HomeOwnershipWithdrawal withdrawal,HomeOwnershipWithdrawalLogic logic){
        
     withdrawal.setTransactionNumber(TransNumberHOW.getText());
     withdrawal.setMemberNumber(memberNumber_HomeOwnershipwithdrawal.getText());
     withdrawal.setFullName(fullName_HomeOwnershipwithdrawal.getText());
     withdrawal.setWithdrawFromPrincipal(depositAmount_HomeOwnershipwithdrawal.getText());
     withdrawal.setWithdrawFromInterest(withdrawFromInterestHomeOwnership.getText());
     withdrawal.setDateOfWithdrawal(dateOfWithdrawal_HomeOwnershipwithdrawal.getValue());
     withdrawal.setSetByUser(userName);
     logic.setMemberNumber(memberNumber_HomeOwnershipwithdrawal.getText());
     logic.setFullName(fullName_HomeOwnershipwithdrawal.getText());
     logic.setWithdrwalInterest(Double.parseDouble(withdrawFromInterestHomeOwnership.getText()));
     logic.setWithdrwalPrincipal(Double.parseDouble(depositAmount_HomeOwnershipwithdrawal.getText()));
        try {
            logic.updateDatabaseValue();
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
   
    }
    
    public void FetchGaranteedPensionDepositData(GaranteedPensionDeposit deposit,GaranteedPensionDepositLogic logic){
    	LocalDatePersistenceConverter date12= new LocalDatePersistenceConverter();
  /*  deposit.setTransactionNumber(transactionNumberGP.getText());
    deposit.setMemberNumber(memberNumber_GaranteedPension.getText());
    deposit.setFullName(fullName_GarnteedPension.getText());
    deposit.setDepositAmount(depositAmount_GaranteedPension.getText().replaceAll("[^0-9]", ""));
    deposit.setDateOfDeposit(dateOfDeposit_GaranteedPension.getValue());
    deposit.setModeOfPayment(garanteedPPMOPD.getValue());
    deposit.setSetByUser(userName);
    deposit.setTransactionNumber(transactionNumberGP.getText());
    logic.setMemberNumber(memberNumber_GaranteedPension.getText());
    logic.setFullName(fullName_GarnteedPension.getText());
    logic.setDeposit(Double.parseDouble(depositAmount_GaranteedPension.getText().replaceAll("[^0-9]", "")));
        try {
            logic.updateDatabaseValue();
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }*/
        
        conn=JavaFirebirdconnect.connectDb1();
        String sql1="INSERT INTO TRANS (TRANS_NO, TRANS_ID, TRANS_TYPE, TRANS_DATE, MEMBER_NO, FULL_NAME, ACCOUNT_NO, PORTFOLIO, MOP, AMOUNT, NETAMOUNT,NOOFSHARES,NAV,ADMIN_FEE,PRICE,SYSDATE, U_NAME) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?);";
        
        PreparedStatement preparedStatement;
   	try {
   		     preparedStatement = conn.prepareStatement(sql1);
   		     preparedStatement.setString(1, transactionNumberGP.getText());
   		     preparedStatement.setInt(2, Integer.parseInt(transactionNumberGP.getText()));
   		     preparedStatement.setString(3, "PURCHASE");
   		     preparedStatement.setTimestamp(4, date12.convertToTimestamp(date12.convertToDatabaseColumn(dateOfDeposit_GaranteedPension.getValue())));
   		     preparedStatement.setString(5, memberNumber_GaranteedPension.getText());
   		     preparedStatement.setString(6, fullName_GarnteedPension.getText());
   		     preparedStatement.setString(7,  memberNumber_GaranteedPension.getText());
   		     preparedStatement.setString(8, "Zimele Guaranteed Pension Plan");
   		     preparedStatement.setString(9, garanteedPPMOPD.getValue());
   		     preparedStatement.setDouble(10,Double.parseDouble(depositAmount_GaranteedPension.getText().replaceAll("[^0-9]", "")));
   		     preparedStatement.setDouble(11, Double.parseDouble(depositAmount_GaranteedPension.getText().replaceAll("[^0-9]", "")));
   		     preparedStatement.setString(12, depositAmount_GaranteedPension.getText());
   		     preparedStatement.setDouble(13, 1.00);
   		     preparedStatement.setDouble(14, 0.00);
   		     preparedStatement.setDouble(15, 1.00);
   		     preparedStatement.setTimestamp(16, date12.convertToTimestamp(date12.convertToDatabaseColumn(dateOfDeposit_GaranteedPension.getValue())));
   		    /* preparedStatement.setTime(17, null);*/
   		     preparedStatement.setString(17, userName);
   		     preparedStatement .executeUpdate();
   	} catch (SQLException e) {
   		// TODO Auto-generated catch block
   		e.printStackTrace();
   	}
      
        
   	sendSMSGP();
        
    }
    
    
    public void sendSMSGP(){
    
    SendSms sms=new SendSms();
     sms.setMemberNumber(memberNumber_GaranteedPension.getText());
     sms.setAmount(depositAmount_GaranteedPension.getText());
     sms.setFullName(fullName_GarnteedPension.getText());
        try {
            sms.getPhoneNumber("PENSION");
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            sms.sendSMS();
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ProtocolException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
   
    
    }
    
    public void FetchGaranteesPensionWithdrawalData(String MOPTYPE){
    	LocalDatePersistenceConverter date12= new LocalDatePersistenceConverter();
     /*withdrawal.setTransactionNumber(TransNumberGPW.getText());
     withdrawal.setMemberNumber(memberNumber_GaranteedPensionWithdrawal.getText());
     withdrawal.setFullName(fullName_GaranteedPensionwithdrawal.getText());
     withdrawal.setWithdrawFromPrincipal(withdrawalAmount_GaranteedPensionwithdrawal.getText().replaceAll("[^0-9]", ""));
     withdrawal.setWithdrawFromInterest(withdrawFromInterestGaranteedpension.getText().replaceAll("[^0-9]", ""));
     withdrawal.setDateOfWithdrawal(dateOfwithdrawal_GaranteedPensionwithdrawal.getValue());
     withdrawal.setSetByUser(userName);
     logic.setMemberNumber(memberNumber_GaranteedPensionWithdrawal.getText());
     logic.setFullName(fullName_GaranteedPensionwithdrawal.getText());
     logic.setWithdrwalPrincipal(Double.parseDouble(withdrawalAmount_GaranteedPensionwithdrawal.getText().replaceAll("[^0-9]", "")));
     logic.setWithdrwalInterest(Double.parseDouble(withdrawFromInterestGaranteedpension.getText().replaceAll("[^0-9]", "")));
        try {
            logic.updateDatabaseValue();
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        */
    	conn=JavaFirebirdconnect.connectDb1();
    	if(MOPTYPE.equals("PRINCIPAL_WITHDRAWAL")){
        
        String sql1="INSERT INTO TRANS (TRANS_NO, TRANS_ID, TRANS_TYPE, TRANS_DATE, MEMBER_NO, FULL_NAME, ACCOUNT_NO, PORTFOLIO, MOP, AMOUNT, NETAMOUNT,NOOFSHARES,NAV,ADMIN_FEE,PRICE,SYSDATE, U_NAME) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?);";
        
        PreparedStatement preparedStatement;
   	try {
   		     preparedStatement = conn.prepareStatement(sql1);
   		     preparedStatement.setString(1, TransNumberGPW.getText());
   		     preparedStatement.setInt(2, Integer.parseInt(TransNumberGPW.getText()));
   		     preparedStatement.setString(3, "WITHDRAWAL");
   		     preparedStatement.setTimestamp(4, date12.convertToTimestamp(date12.convertToDatabaseColumn(dateOfwithdrawal_GaranteedPensionwithdrawal.getValue())));
   		     preparedStatement.setString(5, memberNumber_GaranteedPensionWithdrawal.getText());
   		     preparedStatement.setString(6, fullName_GaranteedPensionwithdrawal.getText());
   		     preparedStatement.setString(7,  memberNumber_GaranteedPensionWithdrawal.getText());
   		     preparedStatement.setString(8, "Zimele Guaranteed Pension Plan");
   		     preparedStatement.setString(9, "WITHDRAWAL");
   		     preparedStatement.setDouble(10,Double.parseDouble(withdrawalAmount_GaranteedPensionwithdrawal.getText().replaceAll("[^0-9]", "")));
   		     preparedStatement.setDouble(11, Double.parseDouble(withdrawalAmount_GaranteedPensionwithdrawal.getText().replaceAll("[^0-9]", "")));
   		     preparedStatement.setString(12, withdrawalAmount_GaranteedPensionwithdrawal.getText());
   		     preparedStatement.setDouble(13, 1.00);
   		     preparedStatement.setDouble(14, 0.00);
   		     preparedStatement.setDouble(15, 1.00);
   		     preparedStatement.setTimestamp(16, date12.convertToTimestamp(date12.convertToDatabaseColumn(dateOfwithdrawal_GaranteedPensionwithdrawal.getValue())));
   		    /* preparedStatement.setTime(17, null);*/
   		     preparedStatement.setString(17, userName);
   		     preparedStatement .executeUpdate();
   	} catch (SQLException e) {
   		// TODO Auto-generated catch block
   		e.printStackTrace();
   	}
    	
    } else if(MOPTYPE.equals("INTEREST_WITHDRAWAL")){
        String sql1="INSERT INTO TRANS (TRANS_NO, TRANS_ID, TRANS_TYPE, TRANS_DATE, MEMBER_NO, FULL_NAME, ACCOUNT_NO, PORTFOLIO, MOP, AMOUNT, NETAMOUNT,NOOFSHARES,NAV,ADMIN_FEE,PRICE,SYSDATE, U_NAME) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?);";
        
        PreparedStatement preparedStatement;
   	try {
   		     preparedStatement = conn.prepareStatement(sql1);
   		     preparedStatement.setString(1, TransNumberGPW.getText());
   		     preparedStatement.setInt(2, Integer.parseInt(TransNumberGPW.getText()));
   		     preparedStatement.setString(3, "INTEREST");
   		     preparedStatement.setTimestamp(4, date12.convertToTimestamp(date12.convertToDatabaseColumn(dateOfwithdrawal_GaranteedPensionwithdrawal.getValue())));
   		     preparedStatement.setString(5, memberNumber_GaranteedPensionWithdrawal.getText());
   		     preparedStatement.setString(6, fullName_GaranteedPensionwithdrawal.getText());
   		     preparedStatement.setString(7,  memberNumber_GaranteedPensionWithdrawal.getText());
   		     preparedStatement.setString(8, "Zimele Guaranteed Pension Plan");
   		     preparedStatement.setString(9, "WITHDRAWAL");
   		     preparedStatement.setDouble(10,(Double.parseDouble(withdrawalAmount_GaranteedPensionwithdrawal.getText().replaceAll("[^0-9]", ""))-(Double.parseDouble(withdrawalAmount_GaranteedPensionwithdrawal.getText().replaceAll("[^0-9]", ""))*2)));
   		     preparedStatement.setDouble(11,(Double.parseDouble(withdrawalAmount_GaranteedPensionwithdrawal.getText().replaceAll("[^0-9]", ""))-(Double.parseDouble(withdrawalAmount_GaranteedPensionwithdrawal.getText().replaceAll("[^0-9]", ""))*2)));
   		     preparedStatement.setString(12, String.valueOf(Double.parseDouble(withdrawalAmount_GaranteedPensionwithdrawal.getText().replaceAll("[^0-9]", ""))-(Double.parseDouble(withdrawalAmount_GaranteedPensionwithdrawal.getText().replaceAll("[^0-9]", ""))*2)));
   		     preparedStatement.setDouble(13, 1.00);
   		     preparedStatement.setDouble(14, 0.00);
   		     preparedStatement.setDouble(15, 1.00);
   		     preparedStatement.setTimestamp(16, date12.convertToTimestamp(date12.convertToDatabaseColumn(dateOfwithdrawal_GaranteedPensionwithdrawal.getValue())));
   		    /* preparedStatement.setTime(17, null);*/
   		     preparedStatement.setString(17, userName);
   		     preparedStatement .executeUpdate();
   	} catch (SQLException e) {
   		// TODO Auto-generated catch block
   		e.printStackTrace();
   	}
    	
    }
   
    }
    
    public void sendSMSGPWithdrawal(){
        
    SendSms sms=new SendSms();
     sms.setMemberNumber(memberNumber_GaranteedPensionWithdrawal.getText());
     sms.setAmount(withdrawalAmount_GaranteedPensionwithdrawal.getText());
     sms.setFullName(fullName_GaranteedPensionwithdrawal.getText());
        try {
            sms.getPhoneNumber("PENSION");
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            sms.sendSMSWithdrawal();
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ProtocolException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
   
    
    }
    
    public PersonalPensionDeposit fundTransferPersonalPensionDeposit() throws SQLException {
      PersonalPensionDeposit deposit= new PersonalPensionDeposit();
     PersonalPensionDepositLogic logic = new PersonalPensionDepositLogic();
      Random randomGenerator = new Random();
      Integer randonInt= randomGenerator.nextInt(1000000000);
     deposit.setPurchaseNumber(randonInt.toString());
    deposit.setMemberNumber(memberNumberFundTransfer.getText());
    deposit.setFullName(fullNameFundTransfer.getText());
    
    double amount = Double.parseDouble(transferAmount_fundTransfer.getText());
    double buyPrice = logic.getBuyPriceFromDB();
    Double units=amount/buyPrice;
    DecimalFormat f = new DecimalFormat("##.00");
    String Funits=f.format(units);
   
    deposit.setPurchasePrice(buyPrice);
    deposit.setPurchaseAmount(transferAmount_fundTransfer.getText());
    deposit.setUnitsPurchased(Double.parseDouble(Funits));
    deposit.setDateOfDeposit(dateOfTransfer_fundTreansfer.getValue());
    deposit.setModeOfPayment("Internal transfer From Garanteed Pension");
    deposit.setSetByUser(userName);
    logic.setMemberNumber(memberNumberFundTransfer.getText());
    logic.setFullName(fullNameFundTransfer.getText());
    logic.setPurchaseNumber(randonInt.toString());
    logic.setUnitsPurchased(Double.parseDouble(Funits));
    logic.setPurchaseAmount(Double.parseDouble(transferAmount_fundTransfer.getText()));
        try {
            logic.updateDatabaseValue();
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
     
             
        return deposit;
      }
   
    public void FetchPersonalPensionDepositData(PersonalPensionDeposit deposit,PersonalPensionDepositLogic logic){
    	LocalDatePersistenceConverter date12= new LocalDatePersistenceConverter();
   /* deposit.setPurchaseNumber(PurchaseNumberPersonalPensionDeposit.getText());
    deposit.setMemberNumber(memberNumber_PersonalPension.getText());
    deposit.setFullName(fullName_PersonalPension.getText());
    deposit.setPurchasePrice(Double.parseDouble(PurchasePricePersonalPension.getText()));
    deposit.setPurchaseAmount(PurchaseAmount_PersonalPension.getText().replaceAll("[^0-9]", ""));
    
   
    deposit.setUnitsPurchased(Double.parseDouble(UnitsPurchasedPersonalPensionDeposits.getText()));
    deposit.setDateOfDeposit(dateOfDeposit_PersonalPension.getValue());
    deposit.setModeOfPayment(PersonalPPMOPD.getValue());
    deposit.setSetByUser(userName);
    logic.setMemberNumber(memberNumber_PersonalPension.getText());
    logic.setFullName(fullName_PersonalPension.getText());
    logic.setPurchaseNumber(PurchaseNumberPersonalPensionDeposit.getText());
    logic.setUnitsPurchased(Double.parseDouble(UnitsPurchasedPersonalPensionDeposits.getText()));
    logic.setPurchaseAmount(Double.parseDouble(PurchaseAmount_PersonalPension.getText().replaceAll("[^0-9]", "")));*/
    
    	
    	 double amount = Double.parseDouble(PurchaseAmount_PersonalPension.getText().replaceAll("[^0-9]", ""));
    	    double buyPrice = Double.parseDouble(PurchasePricePersonalPension.getText());
    	    Double units=amount/buyPrice;
    	    DecimalFormat f = new DecimalFormat("##.00");
    	        String Funits=f.format(units);
    	    UnitsPurchasedPersonalPensionDeposits.setText(Funits);
    	    
    conn=JavaFirebirdconnect.connectDb1();
    String sql1="INSERT INTO TRANS (TRANS_NO, TRANS_ID, TRANS_TYPE, TRANS_DATE, MEMBER_NO, FULL_NAME, ACCOUNT_NO, PORTFOLIO, MOP, AMOUNT, NETAMOUNT,NOOFSHARES,NAV,ADMIN_FEE,PRICE,SYSDATE, U_NAME) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?);";
    
    PreparedStatement preparedStatement;
	try {
		     preparedStatement = conn.prepareStatement(sql1);
		     preparedStatement.setString(1, PurchaseNumberPersonalPensionDeposit.getText());
		     preparedStatement.setInt(2, Integer.parseInt(PurchaseNumberPersonalPensionDeposit.getText()));
		     preparedStatement.setString(3, "PURCHASE");
		     preparedStatement.setTimestamp(4, date12.convertToTimestamp(date12.convertToDatabaseColumn(dateOfDeposit_PersonalPension.getValue())));
		     preparedStatement.setString(5, memberNumber_PersonalPension.getText());
		     preparedStatement.setString(6, fullName_PersonalPension.getText());
		     preparedStatement.setString(7,  memberNumber_PersonalPension.getText());
		     preparedStatement.setString(8, "Zimele Personal Pension Plan");
		     preparedStatement.setString(9, PersonalPPMOPD.getValue());
		     preparedStatement.setDouble(10,Double.parseDouble(PurchaseAmount_PersonalPension.getText().replaceAll("[^0-9]", "")));
		     preparedStatement.setDouble(11, Double.parseDouble(PurchaseAmount_PersonalPension.getText().replaceAll("[^0-9]", "")));
		     preparedStatement.setString(12, UnitsPurchasedPersonalPensionDeposits.getText());
		     preparedStatement.setDouble(13, Double.valueOf(PurchasePricePersonalPension.getText()));
		     preparedStatement.setDouble(14, 0.00);
		     preparedStatement.setDouble(15,Double.valueOf(PurchasePricePersonalPension.getText()));
		    /* preparedStatement.setTime(16, null);*/
		     preparedStatement.setTimestamp(16, date12.convertToTimestamp(date12.convertToDatabaseColumn(dateOfDeposit_PersonalPension.getValue())));
		     preparedStatement.setString(17, userName);
		     preparedStatement .executeUpdate();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
 
    
    
        sendSMSPP();
        
    }
    
    public void sendSMSPP(){
    SendSms sms=new SendSms();
     sms.setMemberNumber(memberNumber_PersonalPension.getText());
     sms.setAmount(PurchaseAmount_PersonalPension.getText());
     sms.setFullName(fullName_PersonalPension.getText());
        try {
            sms.getPhoneNumber("PENSION");
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            sms.sendSMS();
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ProtocolException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    
    
    }
    
    
    
    public PersonalPensionWithdrawal fundTransferPersonalPensionWithdrawal() throws SQLException {
      PersonalPensionWithdrawal withdrawal= new PersonalPensionWithdrawal();
     PersonalPensionWithdrawalLogic logic = new PersonalPensionWithdrawalLogic();
      Random randomGenerator = new Random();
      Integer randonInt= randomGenerator.nextInt(1000000000);
     withdrawal.setPurchaseNumber(randonInt.toString());
    withdrawal.setMemberNumber(memberNumberFundTransfer.getText());
    withdrawal.setFullName(fullNameFundTransfer.getText());
    
    double amount = Double.parseDouble(transferAmount_fundTransfer.getText());
    double buyPrice = logic.getsellPriceFromDB();
    Double units=amount/buyPrice;
    DecimalFormat f = new DecimalFormat("##.00");
    String Funits=f.format(units);
   
    withdrawal.setSellPrice(buyPrice);
    withdrawal.setWithdrawalAmount(transferAmount_fundTransfer.getText());
    withdrawal.setUnitsSold(Double.parseDouble(Funits));
    withdrawal.setDateOfWithdrawal(dateOfTransfer_fundTreansfer.getValue());
   // withdrawal.set("Internal transfer From Garanteed Pension");
    withdrawal.setSetByUser(userName);
    logic.setMemberNumber(memberNumberFundTransfer.getText());
    logic.setFullName(fullNameFundTransfer.getText());
    logic.setPurchaseNumber(randonInt.toString());
    logic.setSellPrice(buyPrice);
    logic.setUnitsSold(Double.parseDouble(Funits));
    logic.setWithdrawalAmount(Double.parseDouble(transferAmount_fundTransfer.getText()));
       try {
            logic. updateDatabaseValue();
           
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            logic. updateDatabaseValue1();
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
     
             
        return withdrawal;
      }
    
    public void FetchPersonalPensionWithdrawalData(PersonalPensionWithdrawal withdrawal,PersonalPensionWithdrawalLogic logic){
    	LocalDatePersistenceConverter date12= new LocalDatePersistenceConverter();
     /*   withdrawal.setPurchaseNumber(PurchaseNumber_personalPensionwithdrawal.getText());
        withdrawal.setMemberNumber(memberNumber_personalPensionwithdrawal.getText());
        withdrawal.setFullName(fullName_personalPensionwithdrawal.getText());
        withdrawal.setSellPrice(Double.parseDouble(SellPricePersonalPension.getText()));
        withdrawal.setWithdrawalAmount(withdrawAmountpersonalPension.getText().replaceAll("[^0-9]", ""));
        double amount = Double.parseDouble(withdrawAmountpersonalPension.getText().replaceAll("[^0-9]", ""));
        double sellPrice = Double.parseDouble(SellPricePersonalPension.getText());
        Double units=amount/sellPrice;
        DecimalFormat f = new DecimalFormat("##.00");
        String Funits=f.format(units);
        UnitsSoldPersonalPensionWithdrawal.setText(Funits);
        withdrawal.setUnitsSold(Double.parseDouble(UnitsSoldPersonalPensionWithdrawal.getText()));
        withdrawal.setDateOfWithdrawal(dateOfwithdrawal_personalPensionwithdrawal.getValue());
        withdrawal.setSetByUser(userName);
        logic.setMemberNumber(memberNumber_personalPensionwithdrawal.getText());
        logic.setFullName(fullName_personalPensionwithdrawal.getText());
        logic.setPurchaseNumber(PurchaseNumber_personalPensionwithdrawal.getText());
        logic.setUnitsSold(Double.parseDouble(UnitsSoldPersonalPensionWithdrawal.getText()));
        logic.setWithdrawalAmount(Double.parseDouble(withdrawAmountpersonalPension.getText().replaceAll("[^0-9]", "")));
        logic.setSellPrice(Double.parseDouble(SellPricePersonalPension.getText()));*/
       
        
        double amount = Double.parseDouble(withdrawAmountpersonalPension.getText().replaceAll("[^0-9]", ""));
        double sellPrice = Double.parseDouble(SellPricePersonalPension.getText());
        Double units=amount/sellPrice;
        DecimalFormat f = new DecimalFormat("##.00");
        String Funits=f.format(units);
        UnitsSoldPersonalPensionWithdrawal.setText(Funits);
        
        conn=JavaFirebirdconnect.connectDb1();
        String sql1="INSERT INTO TRANS (TRANS_NO, TRANS_ID, TRANS_TYPE, TRANS_DATE, MEMBER_NO, FULL_NAME, ACCOUNT_NO, PORTFOLIO, MOP, AMOUNT, NETAMOUNT,NOOFSHARES,NAV,ADMIN_FEE,PRICE,SYSDATE, U_NAME) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?);";
      
        
        PreparedStatement preparedStatement;
    	try {
    		
    		preparedStatement = conn.prepareStatement(sql1);
    		     preparedStatement.setString(1, TransNumberPPW.getText());
    		     preparedStatement.setInt(2, Integer.parseInt(TransNumberPPW.getText()));
    		     preparedStatement.setString(3, "WITHDRAWAL");
    		     preparedStatement.setTimestamp(4, date12.convertToTimestamp(date12.convertToDatabaseColumn(dateOfwithdrawal_personalPensionwithdrawal.getValue())));
    		     preparedStatement.setString(5, memberNumber_personalPensionwithdrawal.getText());
    		     preparedStatement.setString(6, fullName_personalPensionwithdrawal.getText());
    		     preparedStatement.setString(7,  memberNumber_PersonalPension.getText());
    		     preparedStatement.setString(8, "Zimele Personal Pension Plan");
    		     preparedStatement.setString(9, "EFT");
    		     preparedStatement.setDouble(10,Double.parseDouble(withdrawAmountpersonalPension.getText().replaceAll("[^0-9]", "")));
    		     preparedStatement.setDouble(11, Double.parseDouble(withdrawAmountpersonalPension.getText().replaceAll("[^0-9]", "")));
    		     preparedStatement.setString(12, UnitsSoldPersonalPensionWithdrawal.getText());
    		     preparedStatement.setDouble(13, Double.valueOf(SellPricePersonalPension.getText()));
    		     preparedStatement.setDouble(14, 0.00);
    		     preparedStatement.setDouble(15,Double.valueOf(SellPricePersonalPension.getText()));
    		    /* preparedStatement.setTime(16, null);*/
    		     preparedStatement.setTimestamp(16, date12.convertToTimestamp(date12.convertToDatabaseColumn(dateOfwithdrawal_personalPensionwithdrawal.getValue())));
    		     preparedStatement.setString(17, userName);
    		     preparedStatement .executeUpdate();
    	} catch (SQLException e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	}
        
        
        sendSMSPPW();
    }
    
    public void sendSMSPPW(){
        SendSms sms=new SendSms();
         sms.setMemberNumber(memberNumber_personalPensionwithdrawal.getText());
         sms.setAmount(withdrawAmountpersonalPension.getText());
         sms.setFullName(fullName_personalPensionwithdrawal.getText());
            try {
                sms.getPhoneNumber("PENSION");
            } catch (SQLException ex) {
                Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
            }
            try {
                sms.sendSMSWithdrawal();
            } catch (UnsupportedEncodingException ex) {
                Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ProtocolException ex) {
                Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        
        
        }
    

    @FXML
    private void saveTransactionMMD(ActionEvent event) {
       
        MoneyMarketDeposit deposit= new MoneyMarketDeposit() ;
        MoneyMarketDepositLogic Logic= new MoneyMarketDepositLogic();
        HibernateConnector connector= new HibernateConnector() ;
        FetchMoneyMarketDepositData(deposit,Logic);
        //connector.MakeHibernateTransaction(deposit);
        newTransactionMMD.setDisable(false);
         sendSMSMM();
         memberNumberField.setText(null);
        Alert alert2= new Alert(Alert.AlertType.INFORMATION);
        alert2.setContentText("Data Saved Successfully");
        alert2.showAndWait();

       
        
     
        
    }
public static boolean isInteger(String s) {
    try { 
        Integer.parseInt(s); 
    } catch(NumberFormatException e) { 
        return false; 
    } catch(NullPointerException e) {
        return false;
    }
    // only got here if we didn't return false
    return true;
}
   
    @FXML
    private void SearchBtnSearchSection(ActionEvent event) throws SQLException {
        
        conn=JavaFirebirdconnect.connectDb();
        conn1=JavaFirebirdconnect.connectDb1();
                String number =fullNameSearchField.getText();
                String account=chooseAccount.getValue();
                 //int num2=Integer.parseInt(number);
                   System.out.println(number);
                   System.out.println(account);
                   
                 
                if(account.equals("UNIT_TRUST")&&IDSearch.isSelected()){
                try{
                   
                String sql ="select * from MEMBERS ";
              
                sql=sql.concat("where ID_NO ='");
                sql=sql.concat(number);
                sql=sql.concat("'");
               // String sql1 =" select * from personalinformation where identificationNumber=?";
            PreparedStatement  statement1=conn.prepareStatement(sql);
            
             ResultSet result1=statement1.executeQuery();
              oblist.clear();
                if(result1.next()){
                for (int i = 2; i <= result1.getMetaData().getColumnCount(); i++) {
                   String columnName= result1.getMetaData().getColumnLabel(i);
                   System.out.println("column Name + "+columnName);
                   
                   String content=result1.getString(columnName);
                    System.out.println("column Values + "+content);
                      
                      oblist.add(columnName+" : "+content);
                   }
                }
                showProfilePhoto(fullNameSearchField.getText(),"UNIT_TRUST");
            
            }catch (Exception e){

           }
           }else if(account.equals("PENSION")){      
                 try{
                	 String sql= "select * from MEMBERS where MEMBER_NO='";
                     sql=sql.concat(fullNameSearchField.getText());sql=sql.concat("'");
                     PreparedStatement  statement2=conn1.prepareStatement(sql);
                  
                    ResultSet result2=statement2.executeQuery();
                    oblist.clear();
                if(result2.next()){
                for (int i = 2; i <= result2.getMetaData().getColumnCount(); i++) {
                   String columnName= result2.getMetaData().getColumnLabel(i);
                   System.out.println("column Name + "+columnName);
                   
                   String content=result2.getString(columnName);
                    System.out.println("column Values + "+content);
                      
                      oblist.add(columnName+" : "+content);
                   }
            }   
                   showProfilePhoto(fullNameSearchField.getText(),fullNameSearch.getText());
                   
                   
                    }catch (Exception e){
                    
                    }
                
                }else if(account.equals("UNIT_TRUST")){
                    try{
                        
                        String sql ="select * from MEMBERS ";
                      
                        sql=sql.concat("where MEMBER_NO ='");
                        sql=sql.concat(number);
                        sql=sql.concat("'");
                       // String sql1 =" select * from personalinformation where identificationNumber=?";
                    PreparedStatement  statement1=conn.prepareStatement(sql);
                    
                     ResultSet result1=statement1.executeQuery();
                      oblist.clear();
                        if(result1.next()){
                        for (int i = 2; i <= result1.getMetaData().getColumnCount(); i++) {
                           String columnName= result1.getMetaData().getColumnLabel(i);
                           System.out.println("column Name + "+columnName);
                           
                           String content=result1.getString(columnName);
                            System.out.println("column Values + "+content);
                              
                              oblist.add(columnName+" : "+content);
                           }
                        }
                        showProfilePhoto(fullNameSearchField.getText(),"UNIT_TRUST");
                    
                    }catch (Exception e){

                   }
                   }else if(account.equals("PENSION")&&IDSearch.isSelected()){
                       try{
                           
                           String sql ="select * from MEMBERS ";
                         
                           sql=sql.concat("where ID_NO ='");
                           sql=sql.concat(number);
                           sql=sql.concat("'");
                          // String sql1 =" select * from personalinformation where identificationNumber=?";
                       PreparedStatement  statement1=conn1.prepareStatement(sql);
                       
                        ResultSet result1=statement1.executeQuery();
                         oblist.clear();
                           if(result1.next()){
                           for (int i = 2; i <= result1.getMetaData().getColumnCount(); i++) {
                              String columnName= result1.getMetaData().getColumnLabel(i);
                              System.out.println("column Name + "+columnName);
                              
                              String content=result1.getString(columnName);
                               System.out.println("column Values + "+content);
                                 
                                 oblist.add(columnName+" : "+content);
                              }
                           }
                           showProfilePhoto(fullNameSearchField.getText(),"UNIT_TRUST");
                       
                       }catch (Exception e){

                      }
                      }
                
                
                
                
                /*else if(!account.equals("personalinformation")){
               
                if (number.matches("[0-9]+") && number.length() > 2) {
                String sql ="select * from ";
                sql=sql.concat("`");
                sql=sql.concat(account);
                sql=sql.concat("`");
                sql=sql.concat("where `MemberNumber` ='");
                sql=sql.concat(number);
                sql=sql.concat("'");
                
                statement=conn.prepareStatement(sql);
                result=statement.executeQuery();
                oblist.clear();
                if(result.next()){
                for (int i = 2; i <= result.getMetaData().getColumnCount(); i++) {
                   String columnName= result.getMetaData().getColumnLabel(i);
                   System.out.println("column Name + "+columnName);
                   
                   String content=result.getString(columnName);
                    System.out.println("column Values + "+content);
                      
                      oblist.add(columnName+" : "+content);
                   }
            }    System.out.println(sql);showProfilePhoto(fullNameSearchField.getText());
        }
                
               
                }*/
                
        
       
    }

 /*-------------------------------------------------------------------------------------------------------------------------------------------*/   
    @FXML
    private void viewTransactionHistoryBtnMMD(ActionEvent event) {
        
        ResultsetTableDisplay display = new ResultsetTableDisplay(MoneyMarketDepositTableView);
            display.executeSqlStatement("select * from moneymarketdeposit");
    }
   
    @FXML
    private void saveTransactionWithdrawalMMW(ActionEvent event) {
       MoneyMarketWithdrawal withdrawal = new MoneyMarketWithdrawal();
        MoneyMarketWithdrawalLogic Logic = new MoneyMarketWithdrawalLogic();
        HibernateConnector connector= new HibernateConnector() ;
        if( moneyMarketMOPW.getValue().equals("INTEREST_WITHDRAWAL")){
        	FetchMoneyMarketWithdrawalData("INTEREST_WITHDRAWAL");
        	
        }else if(moneyMarketMOPW.getValue().equals("PRINCIPAL_WITHDRAWAL")){
        	FetchMoneyMarketWithdrawalData("PRINCIPAL_WITHDRAWAL");
        	
        }
         
        //connector.MakeHibernateTransaction(withdrawal);
        newTransactionMMW.setDisable(false);
        sendSMSMMwithdrawal();
         memberNumberWithdrawalField.setText(null);
         Alert alert2= new Alert(Alert.AlertType.INFORMATION);
        alert2.setContentText("Data Saved Successfully");
        alert2.showAndWait();
        

    }

    @FXML
    private void viewTransactionHistoryWithdrawalMMW(ActionEvent event) {
        ResultsetTableDisplay display = new ResultsetTableDisplay(MainTableMMW);
            display.executeSqlStatement("select * from moneymarketwithdrawal");
    }

    @FXML
    private void viewHistoryWithdrawalBtnMM(ActionEvent event) {
        
        ResultsetTableDisplay display = new ResultsetTableDisplay(MainTableMMW);
               
                 String AccountNumber= withdrawalHistoryAccountNumberField.getText();
                String sql ="select * from `moneymarketwithdrawal` where `MemberNumber`=";
                sql=sql.concat("'");
                sql=sql.concat(AccountNumber);
                sql=sql.concat("'");
                System.out.println(sql);
             
                display.executeSqlStatement(sql);
    }

    @FXML
    private void saveTransactionpurchasesBtnBFP(ActionEvent event) {
        BalanceFundPurchase purchase = new BalanceFundPurchase();
         BalanceFundPurchaseLogic logic = new BalanceFundPurchaseLogic();
        HibernateConnector connector= new HibernateConnector() ;
         FetchBalanceFundPurchaseData(purchase,logic);
        //connector.MakeHibernateTransaction(purchase);
        newTransactionBFP.setDisable(false);
        sendSMSBF();
        memberNumberPurchasesfield.setText(null);
        Alert alert2= new Alert(Alert.AlertType.INFORMATION);
        alert2.setContentText("Data Saved Successfully");
        alert2.showAndWait();
        
       
    }

    @FXML
    private void viewTransactionHistoryPurchasesBtnBFP(ActionEvent event) {
         ResultsetTableDisplay display = new ResultsetTableDisplay(BalanceFundTransactionTable);
            display.executeSqlStatement("select * from  balancefundpurchase");
    }

    @FXML
    private void viewTransactionHistoryWithdrwalBFW(ActionEvent event) {
         ResultsetTableDisplay display = new ResultsetTableDisplay(BalanceFundTransactionTable);
            display.executeSqlStatement("select * from  balancefundwithdrawal");
    }

    @FXML
    private void saveTransactionsWithdrawalBtnBFW(ActionEvent event) {
        
        BalanceFundWithdrawal withdrawal = new BalanceFundWithdrawal();
        BalanceFundWithdrawalLogic Logic = new BalanceFundWithdrawalLogic();
        HibernateConnector connector= new HibernateConnector() ;
        FetchBalanceFundWithdrawalData(withdrawal,Logic);
       // connector.MakeHibernateTransaction(withdrawal);
        newTransactionBFW.setDisable(false);
          sendSMSBFWithdrawal();
         memberNumberwithdrawalField.setText(null);
        Alert alert2= new Alert(Alert.AlertType.INFORMATION);
        alert2.setContentText("Data Saved Successfully");
        alert2.showAndWait();
        
      
    }

    @FXML
    private void viewHistoryBalancefund(ActionEvent event) {
         ResultsetTableDisplay display = new ResultsetTableDisplay(BalanceFundTransactionTable);
               
                 String AccountNumber= transactionHistoryAccountSearchField.getText();
                String sql ="select * from `balancefundpurchase` where `memberNumber`=";
                sql=sql.concat("'");
                sql=sql.concat(AccountNumber);
                sql=sql.concat("'");
                System.out.println(sql);
             
                display.executeSqlStatement(sql);
    }


    @FXML
    private void saveDetailsPersonalInfoR(ActionEvent event) throws FileNotFoundException {
        PersonalInformation info = new PersonalInformation(); 
         FetchPersonalInformation(info);
        HibernateConnector connector= new  HibernateConnector() ;
        //connector.MakeHibernateTransaction(info);
        memberNumberPersonalInfo.setText(null);
        Alert alert2= new Alert(Alert.AlertType.INFORMATION);
        alert2.setContentText("Data Saved Successfully");
        alert2.showAndWait();
        
    }


    @FXML
    private void saveDetailsBtnNextOfKin(ActionEvent event) {
        NextOfKinInformation NKInfo= new NextOfKinInformation();
        HibernateConnector connector= new HibernateConnector();
       connector .MakeHibernateTransaction(NKInfo);
        Alert alert2= new Alert(Alert.AlertType.INFORMATION);
        alert2.setContentText("Data Saved Successfully");
        alert2.showAndWait();
        
    }

    @FXML
    private void saveDetailsBankDetails(ActionEvent event) {
        InvestmentApplication invest = new InvestmentApplication();
        BalanceFundAccount balanceFund = new BalanceFundAccount();
        MoneyMarketAccounts moneyMarket = new MoneyMarketAccounts();
        HomeOwnershipAccounts homeOwnership = new HomeOwnershipAccounts();
        GaranteedPensionAccount garanteedPension = new GaranteedPensionAccount();
        PersonalPensionAccounts personalPension = new PersonalPensionAccounts();
        
        HibernateConnector connector= new HibernateConnector() ;
        FetchInvestmentApplicationDate(invest,balanceFund,moneyMarket,homeOwnership,garanteedPension,personalPension);
        connector.MakeHibernateTransaction(invest);
         Alert alert2= new Alert(Alert.AlertType.INFORMATION);
        alert2.setContentText("Data Saved Successfully");
        alert2.showAndWait();
        
    }

    @FXML
    private void transferBtn_fundTransfer(ActionEvent event) {
        FundTransfer transfer = new FundTransfer();
        HibernateConnector connector= new HibernateConnector() ;
        FetchFundTransferData(transfer);
        connector.MakeHibernateTransaction(transfer);
        
        
    }

    @FXML
    private void saveTransaction_HomeOwnership(ActionEvent event) throws SQLException {
    	conn = javaconnect.connectDb();
		
    	if(selectFundPostInterest.getValue().equals("Money Market")){
    		
    		if(EditTransactionChoice.getValue().equals("INTEREST")){
    			String deleteInterest = "DELETE FROM money_market_transaction_new WHERE TRANS_NO='";
    			deleteInterest=deleteInterest.concat(transactionNumberHO.getText()+"' AND MEMBER_NO='");
    			deleteInterest=deleteInterest.concat(memberNumber_HomeOwnership.getText()+"'");
    			statement=conn.prepareStatement(deleteInterest);
    			statement.execute();
    	
    			 Alert alert2= new Alert(Alert.AlertType.INFORMATION);
      	        alert2.setContentText("Data deleted Successfully");
      	        alert2.showAndWait();
      
    		}else if(EditTransactionChoice.getValue().equals("WITHDRAWAL")){
    			String deleteInterest = "DELETE FROM moneymarketwithdrawal WHERE transactionNumber='";
    			deleteInterest=deleteInterest.concat(transactionNumberHO.getText()+"' AND MemberNumber='");
    			deleteInterest=deleteInterest.concat(memberNumber_HomeOwnership.getText()+"'");
    			statement=conn.prepareStatement(deleteInterest);
    			statement.execute();
    			
    			 Alert alert2= new Alert(Alert.AlertType.INFORMATION);
      	        alert2.setContentText("Data deleted Successfully");
      	        alert2.showAndWait();
      
    			
    		}else if(EditTransactionChoice.getValue().equals("PURCHASE")){
    			String deleteInterest = "DELETE FROM moneymarketdeposit WHERE transactionNumber='";
    			deleteInterest=deleteInterest.concat(transactionNumberHO.getText()+"' AND MemberNumber='");
    			deleteInterest=deleteInterest.concat(memberNumber_HomeOwnership.getText()+"'");
    			statement=conn.prepareStatement(deleteInterest);
    			statement.execute();
    	
    			 Alert alert2= new Alert(Alert.AlertType.INFORMATION);
      	        alert2.setContentText("Data deleted Successfully");
      	        alert2.showAndWait();
      
    		}
    		
    		
    		
    	}else if(selectFundPostInterest.getValue().equals("Guaranteed Pension")){
    		
    		if(EditTransactionChoice.getValue().equals("INTEREST")){
    			
    			String deleteInterest = "DELETE FROM garanteedpensiontrans WHERE TRANS_ID='";
    			deleteInterest=deleteInterest.concat(transactionNumberHO.getText()+"' AND MEMBER_NO='");
    			deleteInterest=deleteInterest.concat(memberNumber_HomeOwnership.getText()+"'");
    			statement=conn.prepareStatement(deleteInterest);
    			statement.execute();
    			 Alert alert2= new Alert(Alert.AlertType.INFORMATION);
      	        alert2.setContentText("Data deleted Successfully");
      	        alert2.showAndWait();
      		
    			
    		}else if(EditTransactionChoice.getValue().equals("WITHDRAWAL")){
    			String deleteInterest = "DELETE FROM garanteedpensionwithdrawals WHERE transactionNumber='";
    			deleteInterest=deleteInterest.concat(transactionNumberHO.getText()+"' AND MemberNumber='");
    			deleteInterest=deleteInterest.concat(memberNumber_HomeOwnership.getText()+"'");
    			statement=conn.prepareStatement(deleteInterest);
    			statement.execute();
    			 Alert alert2= new Alert(Alert.AlertType.INFORMATION);
      	        alert2.setContentText("Data deleted Successfully");
      	        alert2.showAndWait();
      
    			
    		}else if(EditTransactionChoice.getValue().equals("PURCHASE")){
    			String deleteInterest = "DELETE FROM garanteedpensiondeposit WHERE transactionNumber='";
    			deleteInterest=deleteInterest.concat(transactionNumberHO.getText()+"' AND MemberNumber='");
    			deleteInterest=deleteInterest.concat(memberNumber_HomeOwnership.getText()+"'");
    			statement=conn.prepareStatement(deleteInterest);
    			statement.execute();
    			
    			 Alert alert2= new Alert(Alert.AlertType.INFORMATION);
     	        alert2.setContentText("Data deleted Successfully");
     	        alert2.showAndWait();
     
    			
    		}
    		
    		
    		
    	}
        	

        
    }

    @FXML
    private void transactionHistory_HomeOwnership(ActionEvent event) {
         ResultsetTableDisplay display = new ResultsetTableDisplay(HomeOwnershipMainTable);
            display.executeSqlStatement("select * from  homeownershipdeposit");
    }

    @FXML
    private void saveTransAction_HomeOwnershipwithdrawal(ActionEvent event) {
    	
    	if(selectFundPostInterest.getValue().equals("Money Market")){
    		Random rand = new Random();
    		Integer value = rand.nextInt(1000000000);
    		LocalDatePersistenceConverter date12 = new LocalDatePersistenceConverter();
    		conn = javaconnect.connectDb();
    		String PostInterest = "INSERT INTO `money_market_transaction_new` (`TRANS_NO`, `TRANS_ID`, `TRANS_TYPE`, `TRANS_DATE`, `TRANS_DATE1`, `MEMBER_NO`, `FULL_NAME`, `ACCOUNT_NO`, `PORTFOLIO`, `MOP`, `AMOUNT`, `INTEREST_AMOUNT`, `U_NAME`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";

    		PreparedStatement preparedStatement;
    		try {
    			preparedStatement = conn.prepareStatement(PostInterest);
    			preparedStatement.setString(1, value.toString());
    			preparedStatement.setInt(2, value);
    			preparedStatement.setString(3, "INTEREST");
    			preparedStatement.setString(4, dateOfWithdrawal_HomeOwnershipwithdrawal.getValue().toString());
    			preparedStatement.setDate(5, date12.convertToDatabaseColumn(dateOfWithdrawal_HomeOwnershipwithdrawal.getValue()));
    			preparedStatement.setString(6, memberNumber_HomeOwnershipwithdrawal.getText());
    			preparedStatement.setString(7, fullName_HomeOwnershipwithdrawal.getText());
    			preparedStatement.setString(8,  memberNumber_HomeOwnershipwithdrawal.getText());
    			preparedStatement.setString(9, "Money Market");
    			preparedStatement.setString(10, "INTERES_POST");
    			preparedStatement.setDouble(11, Double.valueOf(withdrawFromInterestHomeOwnership.getText()));
    			preparedStatement.setDouble(12, Double.valueOf(withdrawFromInterestHomeOwnership.getText()));
    			preparedStatement.setString(13, "SYSTEM");

    			preparedStatement.executeUpdate();
    		} catch (SQLException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
	
    		 Alert alert2= new Alert(Alert.AlertType.INFORMATION);
    	        alert2.setContentText("Data Saved Successfully");
    	        alert2.showAndWait();
    	}else if(selectFundPostInterest.getValue().equals("Guaranteed Pension")){
    		
			Random rand = new Random();
			Integer value = rand.nextInt(1000000000);
			LocalDatePersistenceConverter date12 = new LocalDatePersistenceConverter();
			conn = javaconnect.connectDb();
			String PostInterest = "INSERT INTO `garanteedpensiontrans` (`TRANS_NO`, `TRANS_ID`, `TRANS_TYPE`, `TRANS_DATE`, `TRANS_DATE1`, `MEMBER_NO`, `FULL_NAME`, `ACCOUNT_NO`, `PORTFOLIO`, `MOP`, `AMOUNT`, `INTEREST_AMOUNT`, `U_NAME`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";

			PreparedStatement preparedStatement;
			try {
				preparedStatement = conn.prepareStatement(PostInterest);
				preparedStatement.setString(1, value.toString());
				preparedStatement.setInt(2, value);
				preparedStatement.setString(3, "INTEREST");
				preparedStatement.setString(4, dateOfWithdrawal_HomeOwnershipwithdrawal.getValue().toString());
				preparedStatement.setDate(5, date12.convertToDatabaseColumn(dateOfWithdrawal_HomeOwnershipwithdrawal.getValue()));
				preparedStatement.setString(6,  memberNumber_HomeOwnershipwithdrawal.getText());
				preparedStatement.setString(7,  fullName_HomeOwnershipwithdrawal.getText());
				preparedStatement.setString(8,  memberNumber_HomeOwnershipwithdrawal.getText());
				preparedStatement.setString(9, "Zimele Guaranteed Personal Pension Plan");
				preparedStatement.setString(10, "INTERES_POST");
				preparedStatement.setDouble(11,  Double.valueOf(withdrawFromInterestHomeOwnership.getText()));
				preparedStatement.setDouble(12,  Double.valueOf(withdrawFromInterestHomeOwnership.getText()));
				preparedStatement.setString(13, "SYSTEM");

				preparedStatement.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    		
			 Alert alert2= new Alert(Alert.AlertType.INFORMATION);
		        alert2.setContentText("Data Saved Successfully");
		        alert2.showAndWait();
    	}
    	
		    }

    @FXML
    private void viewTransactionHistory_HomeOwnershipwithdrawal(ActionEvent event) {
         ResultsetTableDisplay display = new ResultsetTableDisplay(HomeOwnershipMainTable);
            display.executeSqlStatement("select * from  homeownershipwithdrawal");
        
        
    }

    @FXML
    private void viewHistory_HomeOwnershipBtn(ActionEvent event) {
        ResultsetTableDisplay display = new ResultsetTableDisplay(HomeOwnershipMainTable);
               
                 String AccountNumber= depositHistoryAccountSearch_HomeOwnership.getText();
                String sql ="select * from `homeownershipdeposit` where `MemberNumber`=";
                sql=sql.concat("'");
                sql=sql.concat(AccountNumber);
                sql=sql.concat("'");
                System.out.println(sql);
             
                display.executeSqlStatement(sql);
        
    }

    @FXML
    private void saveTransAction_GaranteedPension(ActionEvent event) {
        GaranteedPensionDeposit deposit = new GaranteedPensionDeposit();
         GaranteedPensionDepositLogic Logic = new GaranteedPensionDepositLogic();
        HibernateConnector connector= new HibernateConnector() ;
        FetchGaranteedPensionDepositData(deposit,Logic);
        //connector.MakeHibernateTransaction(deposit);
         newTransactionGPD.setDisable(false);
         sendSMSGP();
         memberNumber_GaranteedPension.setText(null);
        Alert alert2= new Alert(Alert.AlertType.INFORMATION);
        alert2.setContentText("Data Saved Successfully");
        alert2.showAndWait();
        
    	
        
    }

    @FXML
    private void transactionHistory_GaranteedPension(ActionEvent event) {
         ResultsetTableDisplay display = new ResultsetTableDisplay(garanteedPensionMainTable);
            display.executeSqlStatement("select * from  garanteedpensiondeposit");
    }

    @FXML
    private void viewTransactionHistory_GaranteedPensionwithdrawal(ActionEvent event) {
         ResultsetTableDisplay display = new ResultsetTableDisplay(garanteedPensionMainTable);
            display.executeSqlStatement("select * from  garanteedpensionwithdrawals");
    }

    @FXML
    private void saveTransAction_GaranteedPensionwithdrawal(ActionEvent event) {
        
        GaranteedPensionWithdrawals withdrawal = new GaranteedPensionWithdrawals();
         GaranteedPensionWithdrawalLogic logic = new GaranteedPensionWithdrawalLogic();
        HibernateConnector connector= new HibernateConnector() ;
        if(garanteedPPMOPW.getValue().equals("PRINCIPAL_WITHDRAWAL")){
        	FetchGaranteesPensionWithdrawalData("PRINCIPAL_WITHDRAWAL");
        }else if(garanteedPPMOPW.getValue().equals("INTEREST_WITHDRAWAL")){
        	FetchGaranteesPensionWithdrawalData("INTEREST_WITHDRAWAL");
        	
        }
        //connector.MakeHibernateTransaction(withdrawal);
         newTransactionGPW.setDisable(false);
         sendSMSGPWithdrawal();
         memberNumber_GaranteedPensionWithdrawal.setText(null);
         Alert alert2= new Alert(Alert.AlertType.INFORMATION);
        alert2.setContentText("Data Saved Successfully");
        alert2.showAndWait();
        
        
    	
    }

    @FXML
    private void viewHistory_GaranteedPension(ActionEvent event) {
         ResultsetTableDisplay display = new ResultsetTableDisplay(garanteedPensionMainTable);
               
                 String AccountNumber= depositHistoryAccountSearch_GaranteedPension.getText();
                String sql ="select * from `garanteedpensiondeposit` where `MemberNumber`=";
                sql=sql.concat("'");
                sql=sql.concat(AccountNumber);
                sql=sql.concat("'");
                System.out.println(sql);
             
                display.executeSqlStatement(sql);
    }

    @FXML
    private void saveTrnsaction_PersonalPension(ActionEvent event) {
        PersonalPensionDeposit deposit = new PersonalPensionDeposit();
         PersonalPensionDepositLogic logic = new PersonalPensionDepositLogic();
        HibernateConnector connector= new HibernateConnector() ;
        FetchPersonalPensionDepositData(deposit,logic);
        //connector.MakeHibernateTransaction(deposit);
        newTransactionPPP.setDisable(false);
        memberNumber_PersonalPension.setText(null);
         Alert alert2= new Alert(Alert.AlertType.INFORMATION);
        alert2.setContentText("Data Saved Successfully");
        alert2.showAndWait();
        
    }

    @FXML
    private void viewTransactionHistory_PersonalPension(ActionEvent event) {
         ResultsetTableDisplay display = new ResultsetTableDisplay(personalPensionMainTable);
            display.executeSqlStatement("select * from  personalpensiondeposit");
    }

    @FXML
    private void saveTransAction_personalPensionwithdrawal(ActionEvent event) {
        
        PersonalPensionWithdrawal withdrawal = new PersonalPensionWithdrawal();
         PersonalPensionWithdrawalLogic logic = new PersonalPensionWithdrawalLogic();
         HibernateConnector connector= new HibernateConnector() ;
        FetchPersonalPensionWithdrawalData(withdrawal,logic);
       // connector.MakeHibernateTransaction(withdrawal);
        newTransactionPPW.setDisable(false);
         memberNumber_personalPensionwithdrawal.setText(null);
         Alert alert2= new Alert(Alert.AlertType.INFORMATION);
        alert2.setContentText("Data Saved Successfully");
        alert2.showAndWait();
                
    }

    @FXML
    private void viewTransactionHistory_personalPensionwithdrawal(ActionEvent event) {
         ResultsetTableDisplay display = new ResultsetTableDisplay(personalPensionMainTable);
            display.executeSqlStatement("select * from  personalpensionwithdrawal");
    }

    @FXML
    private void viewHistory_PersonalPension(ActionEvent event) {
         ResultsetTableDisplay display = new ResultsetTableDisplay(personalPensionMainTable);
               
                 String AccountNumber= depositHistoryAccountSearch_PersonalPension.getText();
                String sql ="select * from `personalpensiondeposit` where `MemberNumber`=";
                sql=sql.concat("'");
                sql=sql.concat(AccountNumber);
                sql=sql.concat("'");
                System.out.println(sql);
             
                display.executeSqlStatement(sql);
        
        
        
    }
    
    public void runReportParam(InputStream path, String sql){
        
        try{
       
        Map parameter= new HashMap();
             parameter.put("memberNumber", memberNumberReport.getText());
             
             
             
            JasperDesign jd = JRXmlLoader.load(path);
              JRDesignQuery newQuery = new JRDesignQuery();
            newQuery.setText(sql);
            jd.setQuery(newQuery);
            JasperReport jr = JasperCompileManager.compileReport(jd);

            JasperPrint jp = JasperFillManager.fillReport(jr, null, conn);
            if(jp.getPages().isEmpty()){
            System.out.println("Empty report ....");
            
            }else{
             JasperViewer.viewReport(jp, false);
            
            }
           
           
//            JRViewerFx view = new JRViewerFx(jp, JRViewerFxMode.REPORT_VIEW, newStage);
//            view.start(newStage);
            


        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText(e.toString());
            alert.showAndWait();
            System.out.println(e.toString());

        }
    
    
    }
     public void runReportParam(InputStream path, InputStream path1){
        
        try{
       
        Map parameter= new HashMap();
             parameter.put("memberNumber", memberNumberReport.getText());
             
             
             JasperDesign jd = JRXmlLoader.load(path);
	            JasperReport jr = JasperCompileManager.compileReport(jd);

	            JasperPrint jp = JasperFillManager.fillReport(jr, parameter, conn);
             
            /*JasperDesign jd = JRXmlLoader.load(path);
              JRDesignQuery newQuery = new JRDesignQuery();
            newQuery.setText(sql);
            jd.setQuery(newQuery);
            JasperReport jr = JasperCompileManager.compileReport(jd);

            JasperPrint jp = JasperFillManager.fillReport(jr, null, conn);*/
            
            
            if(jp.getPages().isEmpty()){
                
            System.out.println("Empty report ....");
            System.out.println("Building new  report ....");
             JasperDesign jd1 = JRXmlLoader.load(path1);
              
            JasperReport jr1 = JasperCompileManager.compileReport(jd1);
            
            JasperPrint jp1 = JasperFillManager.fillReport(jr1, parameter, conn);
            JasperViewer.viewReport(jp1, false);
            }else{
             JasperViewer.viewReport(jp, false);
            
            }
           
           
//            JRViewerFx view = new JRViewerFx(jp, JRViewerFxMode.REPORT_VIEW, newStage);
//            view.start(newStage);
            


        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText(e.toString());
            alert.showAndWait();
            System.out.println(e.toString());

        }
    
    
    }
     
     
     public void runReportParam(InputStream path){
         
    	 conn=JavaFirebirdconnect.connectDb();
     	try{
            
            Map parameter= new HashMap();
                 parameter.put("memberNumber", memberNumberReport.getText());
                 
                 
                
               /* JasperReport report = (JasperReport) JRLoader.loadObject(path);*/
               JasperDesign jd = JRXmlLoader.load(path);
//                 
               JasperReport jr = JasperCompileManager.compileReport(jd);

                JasperPrint jp = JasperFillManager.fillReport(jr, parameter, conn);
                JasperViewer.viewReport(jp, false);
//                Stage newStage = new Stage();
//                JRViewerFx view = new JRViewerFx(jp, JRViewerFxMode.REPORT_VIEW, newStage);
//                view.start(newStage);
                

            } catch (Exception e) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText(e.toString());
                alert.showAndWait();

            }
        
        
        }
    
     public void runReportParamP(InputStream path){
         
    	 conn=JavaFirebirdconnect.connectDb1();
     	try{
            
            Map parameter= new HashMap();
                 parameter.put("memberNumber", memberNumberReport.getText());
                 
                 
                
               /* JasperReport report = (JasperReport) JRLoader.loadObject(path);*/
               JasperDesign jd = JRXmlLoader.load(path);
//                 
               JasperReport jr = JasperCompileManager.compileReport(jd);

                JasperPrint jp = JasperFillManager.fillReport(jr, parameter, conn);
                JasperViewer.viewReport(jp, false);
//                Stage newStage = new Stage();
//                JRViewerFx view = new JRViewerFx(jp, JRViewerFxMode.REPORT_VIEW, newStage);
//                view.start(newStage);
                

            } catch (Exception e) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText(e.toString());
                alert.showAndWait();

            }
        
        
        }
/*public void runReportParam(InputStream path){
        
     conn=javaconnect.connectDb1();try{
        
        Map parameter= new HashMap();
             parameter.put("memberNumber", memberNumberReport.getText());
             
             
            
            JasperReport report = (JasperReport) JRLoader.loadObject(path);
//            JasperDesign jd = JRXmlLoader.load(path);
//             
//            JasperReport jr = JasperCompileManager.compileReport(jd);

            JasperPrint jp = JasperFillManager.fillReport(report, parameter, conn);
            JasperViewer.viewReport(jp, false);
//            Stage newStage = new Stage();
//            JRViewerFx view = new JRViewerFx(jp, JRViewerFxMode.REPORT_VIEW, newStage);
//            view.start(newStage);
            

        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText(e.toString());
            alert.showAndWait();

        }
    
    
    }*/

    @FXML
    private void generateReport(ActionEvent event) {
    	LocalDatePersistenceConverter date12= new LocalDatePersistenceConverter();
    	 java.sql.Date dbSqlCurrentDate22 = null;
    	 UpdateDataMoneyMarket mk = new  UpdateDataMoneyMarket();
    	 UpdateDataGaranteedPension gp= new UpdateDataGaranteedPension();
    /*  conn=javaconnect.connectDb();
      try {
  		
    	  if("moneymarket".equals(chooseReport.getValue())){
    		  String sql1="SELECT * FROM `money_market_transaction_new` WHERE MEMBER_NO ='";
    	        sql1=sql1.concat(memberNumberReport.getText());
    	        sql1=sql1.concat("' AND `TRANS_TYPE` LIKE 'INTEREST' ORDER BY `TRANS_DATE1` DESC");
    	     statement = conn.prepareStatement(sql1);
    	     ResultSet rs1 = statement.executeQuery(); 
    		  
    		 
    		      if(rs1.isBeforeFirst()){
    		    	  rs1.next();
    		    	  dbSqlCurrentDate22 = rs1.getDate("TRANS_DATE1");
    		    	     
    		      System.out.println("Trying to work out"); 
    		      if(dbSqlCurrentDate22.compareTo(date12.convertToDatabaseColumn(LocalDate.now()))<0){
    		    	  System.out.println("Trying to work out222222222"); 
    		    	 
    		      }   
    		    	   mk.makeInterestUpdate(memberNumberReport.getText());
    		      }else{
    		    	  
    		    	 System.out.println("STATEMENT NEVER UPDATED");
    		    	  String sql11="SELECT * FROM `money_market_transaction_new` WHERE MEMBER_NO ='";
    	    	        sql11=sql11.concat(memberNumberReport.getText());
    	    	        sql11=sql11.concat("' ORDER BY `TRANS_DATE1` ASC");
    	    	     statement = conn.prepareStatement(sql11);
    	    	     ResultSet rs11 = statement.executeQuery(); 
    	    	     System.out.println("query works");
    	    	     if(rs11.next()){
    	    	    	 System.out.println("resultset Not EMPTY"); 
       		    	  dbSqlCurrentDate22 = rs11.getDate("TRANS_DATE1");
       		    	     
       		      System.out.println("Trying to work out"); 
       		      if(dbSqlCurrentDate22.compareTo(date12.convertToDatabaseColumn(LocalDate.now()))<0){
       		    	  System.out.println("Trying to work out NO INTEREST"); 
       		    	  mk.makeInterestUpdate(memberNumberReport.getText());
       		    	    
       		    	  
       		      }
    	    	     
    		      }
    		      }
    		
           }else if("garanteedpension".equals(chooseReport.getValue())){
        	   String sql11="SELECT * FROM `garanteedpensiontrans` WHERE MEMBER_NO ='";
   	        sql11=sql11.concat(memberNumberReport.getText());
   	        sql11=sql11.concat("' AND `TRANS_TYPE` LIKE 'INTEREST' ORDER BY `TRANS_DATE1` DESC");
        	   statement = conn.prepareStatement(sql11);
       		ResultSet rs = statement.executeQuery();
       	      if(rs.isBeforeFirst()){
       	    	  rs.next();
       	      dbSqlCurrentDate22 = rs.getDate("TRANS_DATE1");
       	      if(dbSqlCurrentDate22.compareTo(date12.convertToDatabaseColumn(LocalDate.now()))<0){
       	    	  
       	        gp.makeInterestUpdate(memberNumberReport.getText());
       	      }
       	      }else {
       	    	  
       	    	String sql111="SELECT * FROM `garanteedpensiontrans` WHERE MEMBER_NO ='";
       	    	sql111=sql111.concat(memberNumberReport.getText());
       	    	sql111=sql111.concat("'  ORDER BY `TRANS_DATE1` ASC");
            	   statement = conn.prepareStatement(sql111);
           		ResultSet rs11 = statement.executeQuery();
           	      if(rs11.next()){
           	      dbSqlCurrentDate22 = rs11.getDate("TRANS_DATE1");
           	      if(dbSqlCurrentDate22.compareTo(date12.convertToDatabaseColumn(LocalDate.now()))<0){
           	    	  
           	        gp.makeInterestUpdate(memberNumberReport.getText());
           	      }
           	      }
       	    	  
       	      }
        	   
             
           }
    	  
    
     
    
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}*/
      
    	
    	
    	
    	
    	
    	
    	
    	
    	
    InputStream MemberTransactionsPPpath1=getClass().getResourceAsStream("/Reports/AsDateStatements/Personal_Pension_Statement_2.jrxml");
    InputStream MemberTransactionsMMpath1=getClass().getResourceAsStream("/Reports/AsDateStatements/MoneyMarketAccountBalanceStatement_2.jrxml");
    InputStream MemberTransactionsHOpath1=getClass().getResourceAsStream("/Reports/AsDateStatements/HomeOwnershipTransactionStatement.jrxml");
    InputStream MemberTransactionsGPpath1=getClass().getResourceAsStream("/Reports/AsDateStatements/GaranteedPensionAccountBalanceStatement_2.jrxml");
    InputStream MemberTransactionsBFpath1=getClass().getResourceAsStream("/Reports/AsDateStatements/BalanceFundStatement_2.jrxml");


        /*String balancedFund="SELECT p.PurchaseNumberBalanceFundPurchase,p.DateOfPurchase,p.ModeOfPaymment,p.purchaseAmount,p.purchasePrice,p.unitsPurchased,w.sellPrice=null, w.withdrawalAmount=null,w.unitsSold=null,p.memberNumber,p.FullName,c.BalanceFundCurrentPrice,b.TotalUnitBalance FROM balancefundpurchase p,balancefundwithdrawal w,`Current Price` c,balacefundaccounts b WHERE p.memberNumber='"; 
        balancedFund=balancedFund.concat(memberNumberReport.getText());balancedFund=balancedFund.concat("' and w.memberNumber='");
        balancedFund=balancedFund.concat(memberNumberReport.getText());balancedFund=balancedFund.concat("' and b.memberNumber='");balancedFund=balancedFund.concat(memberNumberReport.getText()); balancedFund=balancedFund.concat("' UNION SELECT w.TRANS_NO,w.DateOfWithdrawal,w.ModeOfPaymment,p.purchaseAmount=null,p.purchasePrice=null,p.unitsPurchased=null, w.sellPrice,w.withdrawalAmount,w.unitsSold,p.memberNumber,p.FullName,c.BalanceFundCurrentPrice,b.TotalUnitBalance FROM balancefundpurchase p,balancefundwithdrawal w,`Current Price` c,balacefundaccounts b WHERE w.memberNumber='");
        balancedFund=balancedFund.concat(memberNumberReport.getText()); balancedFund=balancedFund.concat("' and p.memberNumber='");balancedFund=balancedFund.concat(memberNumberReport.getText());balancedFund=balancedFund.concat("' and b.memberNumber='");balancedFund=balancedFund.concat(memberNumberReport.getText());
        balancedFund=balancedFund.concat("' ORDER BY `DateOfPurchase` DESC");
        
        String moneyMarket="SELECT p.transactionNumber, p.DateOfDeposit,p.DepositAmount,w.withdrawalAmount = null,w.WithdrawalFromInterest= null,b.AccountBalance,b.Interest,p.MemberNumber,p.FullName  FROM moneymarketdeposit p, moneymarketwithdrawal w,moneymarketaccounts b WHERE p.MemberNumber='";moneyMarket=moneyMarket.concat(memberNumberReport.getText());	moneyMarket=moneyMarket.concat("' AND b.MemberNumber='");moneyMarket=moneyMarket.concat(memberNumberReport.getText());  moneyMarket=moneyMarket.concat("' AND w.MemberNumber='"); moneyMarket=moneyMarket.concat(memberNumberReport.getText());
        moneyMarket=moneyMarket.concat( "' UNION  SELECT w.transactionNumber, w.DateOfWithdrawal,p.DepositAmount= null,w.withdrawalAmount,w.WithdrawalFromInterest,b.AccountBalance,b.Interest,w.MemberNumber,w.FullName FROM moneymarketdeposit p, moneymarketwithdrawal w,moneymarketaccounts b WHERE p.MemberNumber='");moneyMarket=moneyMarket.concat(memberNumberReport.getText());moneyMarket=moneyMarket.concat( "' AND b.MemberNumber='");moneyMarket=moneyMarket.concat(memberNumberReport.getText());moneyMarket=moneyMarket.concat("' AND w.MemberNumber='"); moneyMarket=moneyMarket.concat(memberNumberReport.getText()); moneyMarket=moneyMarket.concat("' ORDER BY DateOfDeposit  ASC");
        
         String moneyMarket="SELECT p.transactionNumber, p.DateOfDeposit,p.DepositAmount,w.withdrawalAmount = null,w.WithdrawalFromInterest= null,b.AccountBalance,b.Interest,p.MemberNumber,p.FullName  FROM moneymarketdeposit p, moneymarketwithdrawal w,moneymarketaccounts b WHERE p.MemberNumber='";moneyMarket=moneyMarket.concat(memberNumberReport.getText());	moneyMarket=moneyMarket.concat("' AND b.MemberNumber='");moneyMarket=moneyMarket.concat(memberNumberReport.getText());  moneyMarket=moneyMarket.concat("' AND w.MemberNumber='"); moneyMarket=moneyMarket.concat(memberNumberReport.getText());
   moneyMarket=moneyMarket.concat( "' UNION  SELECT w.transactionNumber, w.DateOfWithdrawal,p.DepositAmount= null,w.withdrawalAmount,w.WithdrawalFromInterest,b.AccountBalance,b.Interest,w.MemberNumber,w.FullName FROM moneymarketdeposit p, moneymarketwithdrawal w,moneymarketaccounts b WHERE p.MemberNumber='");moneyMarket=moneyMarket.concat(memberNumberReport.getText());moneyMarket=moneyMarket.concat( "' AND b.MemberNumber='");moneyMarket=moneyMarket.concat(memberNumberReport.getText());moneyMarket=moneyMarket.concat("' AND w.MemberNumber='"); moneyMarket=moneyMarket.concat(memberNumberReport.getText()); moneyMarket=moneyMarket.concat("' ORDER BY DateOfDeposit  ASC");
    
   String guarantedPension="SELECT DISTINCT(p.transactionNumber), p.DateOfDeposit,p.DepositAmount,w.withdrawFromPrincipal = null,w.withdrawFromInterest= null,AccountBalance,b.Interest,p.MemberNumber,p.FullName  FROM garanteedpensiondeposit p, garanteedpensionwithdrawals w,garanteedpensionaccounts b WHERE p.MemberNumber='";guarantedPension=guarantedPension.concat(memberNumberReport.getText()); guarantedPension=guarantedPension.concat("' AND w.MemberNumber='");guarantedPension=guarantedPension.concat(memberNumberReport.getText());guarantedPension=guarantedPension.concat("' AND b.MemberNumber='");guarantedPension=guarantedPension.concat(memberNumberReport.getText());
guarantedPension=guarantedPension.concat("' UNION SELECT w.transactionNumber, w.DateOfWithdrawal,p.DepositAmount=null,w.withdrawFromPrincipal,w.withdrawFromInterest,b.AccountBalance,b.Interest,w.MemberNumber,w.FullName FROM garanteedpensiondeposit p, garanteedpensionwithdrawals w,garanteedpensionaccounts b WHERE p.MemberNumber='");guarantedPension=guarantedPension.concat(memberNumberReport.getText());guarantedPension=guarantedPension.concat("' AND w.MemberNumber='");guarantedPension=guarantedPension.concat(memberNumberReport.getText()); guarantedPension=guarantedPension.concat("' AND b.MemberNumber='");guarantedPension=guarantedPension.concat(memberNumberReport.getText());guarantedPension=guarantedPension.concat("' AND w.transactionNumber NOT IN(SELECT transactionNumber from  garanteedpensiondeposit)  ORDER BY DateOfDeposit  ASC");
   

    String personalpension="SELECT p.PurchaseNumber,p.DateOfDeposit,p.purchaseAmount,p.purchasePrice,p.unitsPurchased,w.sellPrice=null, w.withdrawalAmount=null,w.unitsSold=null,p.memberNumber,p.FullName,c.`personalPension Current Price`,b.TotalUnitBalance FROM personalpensiondeposit p,personalpensionwithdrawal w,`Current Price` c,personalpensionpurchase b WHERE p.memberNumber='";personalpension=personalpension.concat(memberNumberReport.getText()); personalpension=personalpension.concat("' and w.memberNumber='");
    personalpension=personalpension.concat(memberNumberReport.getText());personalpension=personalpension.concat("' and b.memberNumber='");personalpension=personalpension.concat(memberNumberReport.getText()); personalpension=personalpension.concat("' UNION SELECT w.PurchaseNumber, w.DateOfWithdrawal,p.purchaseAmount=null,p.purchasePrice=null,p.unitsPurchased=null, w.sellPrice,w.withdrawalAmount,w.unitsSold,p.memberNumber,p.FullName,c.`personalPension Current Price`,b.TotalUnitBalance FROM personalpensiondeposit p,personalpensionwithdrawal w,`Current Price` c,personalpensionpurchase b WHERE w.memberNumber='");
    personalpension=personalpension.concat(memberNumberReport.getText()); personalpension=personalpension.concat("' and p.memberNumber='");
    personalpension=personalpension.concat(memberNumberReport.getText());personalpension=personalpension.concat("' and b.memberNumber='");personalpension=personalpension.concat(memberNumberReport.getText());personalpension=personalpension.concat("' ORDER BY `DateOfDeposit` DESC");
*/
    InputStream MemberTransactionsPPpath=getClass().getResourceAsStream("/Reports/FullStatements/Personal_Pension_Statement_1.jrxml");
    InputStream MemberTransactionsMMpath=getClass().getResourceAsStream("/Reports/FullStatements/MoneyMarketAccountBalanceStatement_1.jrxml");
    InputStream MemberTransactionsHOpath=getClass().getResourceAsStream("/Reports/HomeOwnershipTransactionStatement.jrxml");
    InputStream MemberTransactionsGPpath=getClass().getResourceAsStream("/Reports/FullStatements/GaranteedPensionAccountBalanceStatement_1.jrxml");
    InputStream MemberTransactionsBFpath=getClass().getResourceAsStream("/Reports/FullStatements/BalanceFundStatement_1.jrxml");
  /*  if("balancefund".equals(chooseReport.getValue())){
        runReportStatementByDate(MemberTransactionsBFpath1);
        }else if("moneymarket".equals(chooseReport.getValue())){
           runReportStatementByDate(MemberTransactionsMMpath1);
      }else if("garanteedpension".equals(chooseReport.getValue())){
           runReportStatementByDate(MemberTransactionsGPpath1);
      }else if("homeownership".equals(chooseReport.getValue())){
         runReportStatementByDate(MemberTransactionsHOpath);
      }else if("personalpension".equals(chooseReport.getValue())){
         runReportStatementByDate(MemberTransactionsPPpath1);
      }*/
           if("balancefund".equals(chooseReport.getValue())){
            
             runReportParam(MemberTransactionsBFpath);
             }else if("moneymarket".equals(chooseReport.getValue())){
             
               runReportParam(MemberTransactionsMMpath);
           }else if("garanteedpension".equals(chooseReport.getValue())){
        	   runReportParamP(MemberTransactionsGPpath);
                
           }else if("homeownership".equals(chooseReport.getValue())){
              //runReportParam(MemberTransactionsHOpath);
           }else if("personalpension".equals(chooseReport.getValue())){
        	   runReportParamP(MemberTransactionsPPpath); 
           
           }
       
        
    }

    @FXML
    private void viewAccountHistoryMMD(ActionEvent event) {
        
           ResultsetTableDisplay display = new ResultsetTableDisplay(MoneyMarketDepositTableView);
               
                 String AccountNumber= depositHistoryAccountNumberField.getText();
                String sql ="select * from `moneymarketdeposit` where `MemberNumber`=";
                sql=sql.concat("'");
                sql=sql.concat(AccountNumber);
                sql=sql.concat("'");
                System.out.println(sql);
             
                display.executeSqlStatement(sql);
    }
    
    
    
    public void updateInterestReport(ActionEvent event){
    	
    	
    	
    	
    	
    }

    @FXML
    private void SetMainTableViewEditable(ActionEvent event) {
       
        if(EditTableRadioBtn.isSelected()){
          String selectedTable = chooseTableCombobox.getValue();
          
          String sql="select * from ";
           sql=sql.concat(selectedTable);
                   
            edit.setTableEditable(MainTableViewnew,sql,selectedTable);
             
                 
             
        
        }else{
        edit.setTableEditableFalse(MainTableViewnew);
        
        }
        
           
    }

    @FXML
    private void loadTableData(ActionEvent event) {
//       try{
//          String selectedTable = chooseTableCombobox.getValue();
//          ResultsetTableDisplay display = new ResultsetTableDisplay(MainTableViewnew);
//           String sql="select * from ";
//           sql=sql.concat(selectedTable);
//           display.executeSqlStatement(sql);
//           EditTableRadioBtn.setSelected(false);
//           MainTableViewnew.setEditable(false);
//           System.out.println(sql);
//       }catch(Exception e){
//       Alert alert2= new Alert(Alert.AlertType.ERROR);
//        alert2.setContentText(e.toString());
//        alert2.showAndWait();
//       
//       }
        
        specificDate.setValue(null);
        toDate.setValue(null);
        fromDate.setValue(null);
    }

    @FXML
    private void refreshMainTable(ActionEvent event) {
    	
        if(EditTableRadioBtn.isSelected()){
           
        	/*InputStream MemberTransactionsPPpath=getClass().getResourceAsStream("/Reports/AsDateStatements/Personal_Pension_Statement1.jrxml");
            InputStream MemberTransactionsMMpath=getClass().getResourceAsStream("/Reports/AsDateStatements/MoneyMarketAccountBalanceStatement1.jrxml");
            InputStream MemberTransactionsHOpath=getClass().getResourceAsStream("/Reports/HomeOwnershipTransactionStatement.jrxml");
            InputStream MemberTransactionsGPpath=getClass().getResourceAsStream("/Reports/AsDateStatements/GaranteedPensionAccountBalanceStatement1.jrxml");
            InputStream MemberTransactionsBFpath=getClass().getResourceAsStream("/Reports/AsDateStatements/BalanceFundStatement1.jrxml");
                */
        	
        	 InputStream MemberTransactionsPPpath=getClass().getResourceAsStream("/Reports/AsDateStatements/Personal_Pension_Statement_2.jrxml");
        	    InputStream MemberTransactionsMMpath=getClass().getResourceAsStream("/Reports/AsDateStatements/MoneyMarketAccountBalanceStatement_2.jrxml");
        	    InputStream MemberTransactionsHOpath1=getClass().getResourceAsStream("/Reports/AsDateStatements/HomeOwnershipTransactionStatement.jrxml");
        	    InputStream MemberTransactionsGPpath=getClass().getResourceAsStream("/Reports/AsDateStatements/GaranteedPensionAccountBalanceStatement_2.jrxml");
        	    InputStream MemberTransactionsBFpath=getClass().getResourceAsStream("/Reports/AsDateStatements/BalanceFundStatement_2.jrxml");
                  if("balancefund".equals(chooseReport.getValue())){
                     runReportStatementByDate(MemberTransactionsBFpath);
                     }else if("moneymarket".equals(chooseReport.getValue())){
                        runReportStatementByDate(MemberTransactionsMMpath);
                   }else if("garanteedpension".equals(chooseReport.getValue())){
                        runReportStatementByDateP(MemberTransactionsGPpath);
                   }else if("homeownership".equals(chooseReport.getValue())){
                    /*  runReportStatementByDate(MemberTransactionsHOpath);*/
                   }else if("personalpension".equals(chooseReport.getValue())){
                      runReportStatementByDateP(MemberTransactionsPPpath);
                   }
                   
               
          
          }else{
        	  try{
        	         ResultsetTableDisplay display= new ResultsetTableDisplay(MainTableViewnew);

        	           
        	           if("moneymarketdeposit".equals(chooseTableCombobox.getValue())){
        	              
        	                   if(specificDate.getValue() != null){
        	                    String sortBySpecificDateMM="SELECT * FROM moneymarketdeposit WHERE  DateOfDeposit='";
        	                    sortBySpecificDateMM=sortBySpecificDateMM.concat(specificDate.getValue().toString());
        	                    sortBySpecificDateMM=sortBySpecificDateMM.concat("'");
        	                     display.executeSqlStatement(sortBySpecificDateMM);
        	                 }else if(fromDate.getValue() !=null){
        	                    String sortByDateRangeMM="SELECT * FROM moneymarketdeposit WHERE  DateOfDeposit >='";
        	                    sortByDateRangeMM=sortByDateRangeMM.concat(fromDate.getValue().toString());sortByDateRangeMM=sortByDateRangeMM.concat("'");
        	                    sortByDateRangeMM=sortByDateRangeMM.concat(" AND DateOfDeposit<='");sortByDateRangeMM=sortByDateRangeMM.concat(toDate.getValue().toString());
        	                    sortByDateRangeMM=sortByDateRangeMM.concat("'");
        	                    display.executeSqlStatement(sortByDateRangeMM);
        	                 }
        	              
        	              }else if("garanteedpensiondeposit".equals(chooseTableCombobox.getValue())){
        	                   if(specificDate.getValue() != null){
        	                      String sortBySpecificDateGP="SELECT * FROM garanteedpensiondeposit WHERE  DateOfDeposit ='";
        	                      sortBySpecificDateGP=sortBySpecificDateGP.concat(specificDate.getValue().toString());
        	                      sortBySpecificDateGP=sortBySpecificDateGP.concat("'");
        	                       display.executeSqlStatement(sortBySpecificDateGP);
        	                 }else if(fromDate.getValue() !=null){
        	                        String sortByDateRangeGP="SELECT * FROM garanteedpensiondeposit WHERE  DateOfDeposit >='";
        	                        sortByDateRangeGP=sortByDateRangeGP.concat(fromDate.getValue().toString());sortByDateRangeGP=sortByDateRangeGP.concat("'");
        	                        sortByDateRangeGP=sortByDateRangeGP.concat(" AND DateOfDeposit<='");sortByDateRangeGP=sortByDateRangeGP.concat(toDate.getValue().toString());
        	                        sortByDateRangeGP=sortByDateRangeGP.concat("'");
        	                        display.executeSqlStatement(sortByDateRangeGP);
        	                 }
        	              }else if("homeownershipdeposit".equals(chooseTableCombobox.getValue())){
        	                  
        	                  if(specificDate.getValue() != null){
        	                    String sortBySpecificDateHO="SELECT * FROM homeownershipdeposit WHERE  DateOfDeposit ='";
        	                    sortBySpecificDateHO=sortBySpecificDateHO.concat(specificDate.getValue().toString());
        	                    sortBySpecificDateHO=sortBySpecificDateHO.concat("'");
        	                     display.executeSqlStatement(sortBySpecificDateHO);
        	                 }else if(fromDate.getValue() !=null){
        	                    String sortByDateRangeHO="SELECT * FROM homeownershipdeposit WHERE  DateOfDeposit >='";
        	                    sortByDateRangeHO=sortByDateRangeHO.concat(fromDate.getValue().toString());sortByDateRangeHO=sortByDateRangeHO.concat("'");
        	                    sortByDateRangeHO=sortByDateRangeHO.concat(" AND DateOfDeposit<='");sortByDateRangeHO=sortByDateRangeHO.concat(toDate.getValue().toString());
        	                    sortByDateRangeHO=sortByDateRangeHO.concat("'");
        	                    display.executeSqlStatement(sortByDateRangeHO);
        	                 }
        	          
        	              }else if("personalpensiondeposit".equals(chooseTableCombobox.getValue())){
        	                  if(specificDate.getValue() != null){
        	                    String sortBySpecificDatePP="SELECT * FROM personalpensiondeposit WHERE  DateOfDeposit ='";
        	                    sortBySpecificDatePP=sortBySpecificDatePP.concat(specificDate.getValue().toString());
        	                    sortBySpecificDatePP=sortBySpecificDatePP.concat("'");  
        	                     display.executeSqlStatement(sortBySpecificDatePP);
        	                 }else if(fromDate.getValue() !=null){
        	                    String sortByDateRangePP="SELECT * FROM personalpensiondeposit WHERE  DateOfDeposit >='";
        	                    sortByDateRangePP=sortByDateRangePP.concat(fromDate.getValue().toString());sortByDateRangePP=sortByDateRangePP.concat("'");
        	                    sortByDateRangePP=sortByDateRangePP.concat(" AND DateOfDeposit<='");sortByDateRangePP=sortByDateRangePP.concat(toDate.getValue().toString());
        	                    sortByDateRangePP=sortByDateRangePP.concat("'");
        	                    display.executeSqlStatement(sortByDateRangePP);
        	                 }
        	              
        	              }else if("balancefundpurchase".equals(chooseTableCombobox.getValue())){
        	                    if(specificDate.getValue() != null){
        	                    String sortBySpecificDateBF="SELECT * FROM balancefundpurchase WHERE  DateOfPurchase ='";
        	                    sortBySpecificDateBF=sortBySpecificDateBF.concat(specificDate.getValue().toString());
        	                    sortBySpecificDateBF=sortBySpecificDateBF.concat("'");  
        	                   display.executeSqlStatement(sortBySpecificDateBF);
        	                 }else if(fromDate.getValue() !=null){
        	                    String sortByDateRangeBF="SELECT * FROM balancefundpurchase WHERE  DateOfPurchase >='";
        	                    sortByDateRangeBF=sortByDateRangeBF.concat(fromDate.getValue().toString());sortByDateRangeBF=sortByDateRangeBF.concat("'");
        	                    sortByDateRangeBF=sortByDateRangeBF.concat(" AND DateOfPurchase<='");sortByDateRangeBF=sortByDateRangeBF.concat(toDate.getValue().toString());
        	                    sortByDateRangeBF=sortByDateRangeBF.concat("'");
        	                    display.executeSqlStatement(sortByDateRangeBF);
        	                 }
        	              }else if("balancefundwithdrawal".equals(chooseTableCombobox.getValue())){
        	                 
        	                if(specificDate.getValue() != null){
        	                     String sortBySpecificDateBF="SELECT * FROM balancefundwithdrawal WHERE  DateOfWithdrawal='";
        	                    sortBySpecificDateBF=sortBySpecificDateBF.concat(specificDate.getValue().toString());sortBySpecificDateBF=sortBySpecificDateBF.concat("'");
        	                     display.executeSqlStatement(sortBySpecificDateBF);
        	                 }else if(fromDate.getValue() !=null){
        	                     String sortByDateRangeBF="SELECT * FROM balancefundwithdrawal WHERE DateOfWithdrawal >= '"; 
        	                    sortByDateRangeBF=sortByDateRangeBF.concat(fromDate.getValue().toString());sortByDateRangeBF=sortByDateRangeBF.concat("'");
        	                    sortByDateRangeBF=sortByDateRangeBF.concat(" AND DateOfWithdrawal<='");sortByDateRangeBF=sortByDateRangeBF.concat(toDate.getValue().toString());
        	                    sortByDateRangeBF=sortByDateRangeBF.concat("'");
        	                    System.out.println(sortByDateRangeBF);
        	                    display.executeSqlStatement(sortByDateRangeBF);
        	                 }
        	             
        	             }else if("moneymarketwithdrawal".equals(chooseTableCombobox.getValue())){
        	                if(specificDate.getValue() != null){
        	                    System.out.println("spesific date :"+specificDate.getValue().toString());
        	                    String sortBySpecificDateMM="SELECT * FROM moneymarketwithdrawal WHERE  DateOfWithdrawal='";
        	                    sortBySpecificDateMM=sortBySpecificDateMM.concat(specificDate.getValue().toString());
        	                    sortBySpecificDateMM=sortBySpecificDateMM.concat("'");
        	                      System.out.println(sortBySpecificDateMM);
        	                   display.executeSqlStatement(sortBySpecificDateMM);
        	                 }else if(fromDate.getValue() !=null){
        	                        String sortByDateRangeMM="SELECT * FROM moneymarketwithdrawal WHERE  DateOfWithdrawal >='";
        	                        sortByDateRangeMM=sortByDateRangeMM.concat(fromDate.getValue().toString());sortByDateRangeMM=sortByDateRangeMM.concat("'");
        	                        sortByDateRangeMM=sortByDateRangeMM.concat(" AND DateOfWithdrawal<='");sortByDateRangeMM=sortByDateRangeMM.concat(toDate.getValue().toString());
        	                        sortByDateRangeMM=sortByDateRangeMM.concat("'");
        	                       display.executeSqlStatement(sortByDateRangeMM); 
        	                 }
        	             
        	             }else if("garanteedpensionwithdrawals".equals(chooseTableCombobox.getValue())){
        	                if(specificDate.getValue() != null){
        	                    String sortBySpecificDateGP="select * from garanteedpensionwithdrawals WHERE DateOfWithdrawal='";
        	                    sortBySpecificDateGP=sortBySpecificDateGP.concat(specificDate.getValue().toString());
        	                    sortBySpecificDateGP=sortBySpecificDateGP.concat("'");
        	                    display.executeSqlStatement(sortBySpecificDateGP);
        	                 
        	                 }else if(fromDate.getValue() !=null){
        	                    String sortByDateRangeGP="SELECT * FROM garanteedpensionwithdrawals WHERE  DateOfWithdrawal >='";
        	                    sortByDateRangeGP=sortByDateRangeGP.concat(fromDate.getValue().toString());sortByDateRangeGP=sortByDateRangeGP.concat("'");
        	                    sortByDateRangeGP=sortByDateRangeGP.concat(" AND DateOfWithdrawal<='");sortByDateRangeGP=sortByDateRangeGP.concat(toDate.getValue().toString());
        	                    sortByDateRangeGP=sortByDateRangeGP.concat("'");
        	                     display.executeSqlStatement(sortByDateRangeGP);
        	                 
        	                 }
        	             
        	             }else if("homeownershipwithdrawal".equals(chooseTableCombobox.getValue())){
        	                  if(specificDate.getValue() != null){
        	                    String sortBySpecificDateHO="select * from homeownershipwithdrawal where DateOfWithdrawal='";
        	                    sortBySpecificDateHO=sortBySpecificDateHO.concat(specificDate.getValue().toString());
        	                    sortBySpecificDateHO=sortBySpecificDateHO.concat("'");
        	                     display.executeSqlStatement(sortBySpecificDateHO);
        	                 }else if(fromDate.getValue() !=null){
        	                    String sortByDateRangeHO="SELECT * FROM homeownershipwithdrawal WHERE  DateOfWithdrawal >='";
        	                    sortByDateRangeHO=sortByDateRangeHO.concat(fromDate.getValue().toString());sortByDateRangeHO=sortByDateRangeHO.concat("'");
        	                    sortByDateRangeHO=sortByDateRangeHO.concat(" AND DateOfWithdrawal<='");sortByDateRangeHO=sortByDateRangeHO.concat(toDate.getValue().toString());
        	                    sortByDateRangeHO=sortByDateRangeHO.concat("'");
        	                    display.executeSqlStatement(sortByDateRangeHO);
        	                 
        	                 }
        	             
        	             }else if("personalpensionwithdrawal".equals(chooseTableCombobox.getValue())){
        	                 if(specificDate.getValue() != null){
        	                    String sortBySpecificDatePP="select * from personalpensionwithdrawal WHERE DateOfWithdrawal='";
        	                    sortBySpecificDatePP=sortBySpecificDatePP.concat(specificDate.getValue().toString());
        	                    sortBySpecificDatePP=sortBySpecificDatePP.concat("'");
        	                    display.executeSqlStatement(sortBySpecificDatePP);
        	                 }else if(fromDate.getValue() !=null){
        	                    String sortByDateRangePP="SELECT * FROM personalpensionwithdrawal WHERE  DateOfWithdrawal >='";
        	                    sortByDateRangePP=sortByDateRangePP.concat(fromDate.getValue().toString());sortByDateRangePP=sortByDateRangePP.concat("'");
        	                    sortByDateRangePP=sortByDateRangePP.concat(" AND DateOfWithdrawal<='");sortByDateRangePP=sortByDateRangePP.concat(toDate.getValue().toString());
        	                    sortByDateRangePP=sortByDateRangePP.concat("'");
        	                     System.out.println(sortByDateRangePP);
        	                    display.executeSqlStatement(sortByDateRangePP);
        	                 }
        	             
        	             }
        	        }catch(Exception e){
        	         Alert alert = new Alert(Alert.AlertType.INFORMATION);
        	                alert.setContentText(e.toString());
        	              alert.showAndWait();
        	        }
          
          }
       
           
    }

    @FXML
    private void chooseAccount(ActionEvent event) {
        
        
        
    }

    @FXML
    private void viewWithdrawalsHomeOwnership(ActionEvent event) {
         ResultsetTableDisplay display = new ResultsetTableDisplay(HomeOwnershipMainTable);
               
                 String AccountNumber= depositHistoryAccountSearch_HomeOwnership.getText();
                String sql ="select * from `homeownershipwithdrawal` where `MemberNumber`=";
                sql=sql.concat("'");
                sql=sql.concat(AccountNumber);
                sql=sql.concat("'");
                System.out.println(sql);
             
                display.executeSqlStatement(sql);
    }

    
    
    @FXML
    private void viewWithdrawalGaranteedPension(ActionEvent event) {
        ResultsetTableDisplay display = new ResultsetTableDisplay(garanteedPensionMainTable);
               
                 String AccountNumber= depositHistoryAccountSearch_GaranteedPension.getText();
                String sql ="select * from `garanteedpensionwithdrawals` where `MemberNumber`=";
                sql=sql.concat("'");
                sql=sql.concat(AccountNumber);
                sql=sql.concat("'");
                System.out.println(sql);
             
                display.executeSqlStatement(sql);
    }

    @FXML
    private void viewWithdrawalPersonalPension(ActionEvent event) {
         ResultsetTableDisplay display = new ResultsetTableDisplay(personalPensionMainTable);
               
                 String AccountNumber= depositHistoryAccountSearch_PersonalPension.getText();
                String sql ="select * from `personalpensionwithdrawal` where `MemberNumber`=";
                sql=sql.concat("'");
                sql=sql.concat(AccountNumber);
                sql=sql.concat("'");
                System.out.println(sql);
             
                display.executeSqlStatement(sql);
    }

    @FXML
    private void withdrawalsBalanceFund(ActionEvent event) {
         ResultsetTableDisplay display = new ResultsetTableDisplay(BalanceFundTransactionTable);
               
                 String AccountNumber= transactionHistoryAccountSearchField.getText();
                String sql ="select * from `balancefundwithdrawal` where `MemberNumber`=";
                sql=sql.concat("'");
                sql=sql.concat(AccountNumber);
                sql=sql.concat("'");
                System.out.println(sql);
             
                display.executeSqlStatement(sql);
    }

    
    private void getMemberDataMMD(KeyEvent event) {
        conn=javaconnect.connectDb1();
        try{
        String sql="select * from investmentapplication where MemberNumber=?";
        statement=conn.prepareStatement(sql);
        statement.setString(1, memberNumberField.getText());
        result=statement.executeQuery();
        if(result.next()){
        String fullname=result.getString("FullName");
        fullNameField.setText(fullname);
        
        }
        
        }catch(Exception e){
        Alert alert2= new Alert(Alert.AlertType.ERROR);
        alert2.setContentText(e.toString());
        alert2.showAndWait();
        
        }
        
        
    }

    
    private void getMemberDataMMW(KeyEvent event) {
        
        conn=javaconnect.connectDb1();
        try{
        String sql="select * from investmentapplication where MemberNumber=?";
        statement=conn.prepareStatement(sql);
        statement.setString(1, memberNumberField.getText());
        result=statement.executeQuery();
        if(result.next()){
        String fullname=result.getString("FullName");
        fullNamewithdrawalField.setText(fullname);
        
        }
        
        }catch(Exception e){
        Alert alert2= new Alert(Alert.AlertType.ERROR);
        alert2.setContentText(e.toString());
        alert2.showAndWait();
        
        }
    }

   
    private void getMemberDataBFP(KeyEvent event) {
        conn=javaconnect.connectDb1();
        try{
        String sql="select * from investmentapplication where MemberNumber=?";
        statement=conn.prepareStatement(sql);
        statement.setString(1, memberNumberPurchasesfield.getText());
        System.out.println( memberNumberPurchasesfield.getText());
        result=statement.executeQuery();
        if(result.next()){
        String fullname=result.getString("FullName");
        fulNamePurchasesField.setText(fullname);
        unitsPurchasedPurchasesField.setDisable(true);
         Random randomGenerator = new Random();
        
            Integer randonInt= randomGenerator.nextInt(1000000000);
            PurchaseNumberBalanceFundPurchase.setText(randonInt.toString());
            BalanceFundPurchaseLogic logic= new BalanceFundPurchaseLogic();
            Double price = logic.getsellPriceFromDB();
            purchasePricePurchasefield.setText(price.toString());
            
        
        }
        
        }catch(Exception e){
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, e);
        Alert alert2= new Alert(Alert.AlertType.ERROR);
        alert2.setContentText(e.toString());
        alert2.showAndWait();
        
        }
    }

    private void getMemberDataBFW(KeyEvent event) {
        
        
        
    }

    @FXML
    private void getMemberDataHOD(KeyEvent event) {
        conn=javaconnect.connectDb1();
        try{
        String sql="select * from investmentapplication where MemberNumber=?";
        statement=conn.prepareStatement(sql);
        statement.setString(1, memberNumber_HomeOwnership.getText());
        result=statement.executeQuery();
        if(result.next()){
        String fullname=result.getString("FullName");
        fullName_HomeOwnership.setText(fullname);
        
        }
        
        }catch(Exception e){
        Alert alert2= new Alert(Alert.AlertType.ERROR);
        alert2.setContentText(e.toString());
        alert2.showAndWait();
        
        }
        
    }

    @FXML
    private void getMemberDataHOW(KeyEvent event) {
        conn=javaconnect.connectDb1();
        try{
        String sql="select * from investmentapplication where MemberNumber=?";
        statement=conn.prepareStatement(sql);
        statement.setString(1, memberNumber_HomeOwnershipwithdrawal.getText());
        result=statement.executeQuery();
        if(result.next()){
        String fullname=result.getString("FullName");
        fullName_HomeOwnershipwithdrawal.setText(fullname);
        
        }
        
        }catch(Exception e){
        Alert alert2= new Alert(Alert.AlertType.ERROR);
        alert2.setContentText(e.toString());
        alert2.showAndWait();
        
        }
    }

    
    private void getMemberDataGPD(KeyEvent event) {
        conn=javaconnect.connectDb1();
        try{
        String sql="select * from investmentapplication where MemberNumber=?";
        statement=conn.prepareStatement(sql);
        statement.setString(1, memberNumber_GaranteedPension.getText());
        result=statement.executeQuery();
        if(result.next()){
        String fullname=result.getString("FullName");
        fullName_GarnteedPension.setText(fullname);
        
        }
        
        }catch(Exception e){
        Alert alert2= new Alert(Alert.AlertType.ERROR);
        alert2.setContentText(e.toString());
        alert2.showAndWait();
        
        }
    }

   
    private void getMemberDataGPW(KeyEvent event) {
        
        conn=javaconnect.connectDb1();
        try{
        String sql="select * from investmentapplication where MemberNumber=?";
        statement=conn.prepareStatement(sql);
        statement.setString(1, memberNumber_GaranteedPensionWithdrawal.getText());
        result=statement.executeQuery();
        if(result.next()){
        String fullname=result.getString("FullName");
        fullName_GaranteedPensionwithdrawal.setText(fullname);
        
        }
        
        }catch(Exception e){
        Alert alert2= new Alert(Alert.AlertType.ERROR);
        alert2.setContentText(e.toString());
        alert2.showAndWait();
        
        }
    }

    
    private void getMemberDataPPD(KeyEvent event) {
        conn=javaconnect.connectDb1();
        try{
        String sql="select * from investmentapplication where MemberNumber=?";
        statement=conn.prepareStatement(sql);
        statement.setString(1, memberNumber_PersonalPension.getText());
        result=statement.executeQuery();
         Random randomGenerator = new Random();
        Integer randonInt= randomGenerator.nextInt(1000000000);
            PurchaseNumberPersonalPensionDeposit.setText(randonInt.toString());
            PersonalPensionDepositLogic logic=new PersonalPensionDepositLogic();
           Double price = logic.getBuyPriceFromDB();
            PurchasePricePersonalPension.setText(price.toString());
        if(result.next()){
        String fullname=result.getString("FullName");
        fullName_PersonalPension.setText(fullname);
        
        }
        
        }catch(Exception e){
        Alert alert2= new Alert(Alert.AlertType.ERROR);
        alert2.setContentText(e.toString());
        alert2.showAndWait();
        
        }
    }

    
    private void getMemberDataPPW(KeyEvent event) {
        conn=javaconnect.connectDb1();
        try{
        String sql="select *  from investmentapplication where MemberNumber=?";
        statement=conn.prepareStatement(sql);
        statement.setString(1, memberNumber_personalPensionwithdrawal.getText());
        result=statement.executeQuery();
        PersonalPensionWithdrawalLogic logic= new PersonalPensionWithdrawalLogic();
        Double sellPrice=logic.getsellPriceFromDB();
        SellPricePersonalPension.setText(sellPrice.toString());
        if(result.next()){
        String fullname=result.getString("FullName");
        fullName_personalPensionwithdrawal.setText(fullname);
         String MemberNumber=result.getString("MemberNumber");
       
        
        }
        
        }catch(Exception e){
        Alert alert2= new Alert(Alert.AlertType.ERROR);
        alert2.setContentText(e.toString());
        alert2.showAndWait();
        
        }
        
        
    }


    @FXML
    private void setMemberDataBFW(KeyEvent event) {
        
        conn=javaconnect.connectDb1();
        try{
        String sql="select * from investmentapplication where MemberNumber=?";
        statement=conn.prepareStatement(sql);
        statement.setString(1, memberNumberwithdrawalField.getText());
        result=statement.executeQuery();
        if(result.next()){
        String fullname=result.getString("FullName");
        String membernuber=result.getString("MemberNumber");
        fullNamewithdrawalFieldBalanceFund.setText(fullname);
       
           unitsSoldWithdrwalField.setDisable(true);
            BalanceFundWithdrawalLogic logic= new BalanceFundWithdrawalLogic();
            Double price = logic.getsellPriceFromDB();
            sellPriceWithdrawalsField.setText(price.toString());
            
        
        }
        
        }catch(Exception e){
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, e);
        Alert alert2= new Alert(Alert.AlertType.ERROR);
        alert2.setContentText(e.toString());
        alert2.showAndWait();
        
        }
        
        
    }
    

    


    private void disableButton(MouseEvent event) {
        
//            saveTransactionBtn.disableProperty().bind(
//    Bindings.createBooleanBinding( () -> 
//        fullNameField.getText().trim().isEmpty(), fullNameField.textProperty()
//            
//    )
    // If you want to check more text field, use it as by removing comments
    //.or(  Bindings.createBooleanBinding(
    //         first_name.getText.trim().isEmpty(), first_name.textProperty()
    //     )
    //  )

//);
    }

    @FXML
    private void ValidateFieldsMMW(MouseEvent event) {
        
//               saveTransactionWithdrawalField.disableProperty().bind(
//    Bindings.createBooleanBinding( () -> 
//        memberNumberWithdrawalField.getText().trim().isEmpty(), memberNumberWithdrawalField.textProperty()
//            
//    ).or( Bindings.createBooleanBinding( () -> 
//           fullNamewithdrawalField.getText().trim().isEmpty(), fullNamewithdrawalField.textProperty()      
//        )
//    ).or( Bindings.createBooleanBinding( () -> 
//           withdrawalAmountField.getText().trim().isEmpty(), withdrawalAmountField.textProperty()      
//        )
//    ).or( Bindings.createBooleanBinding( () -> 
//           withdrawFromInterestMoneyMarket.getText().trim().isEmpty(), withdrawFromInterestMoneyMarket.textProperty()      
//        )
//    )
//               
// );
      saveTransactionWithdrawalField.disableProperty().bind(
                 withdrawalDateWithdrawalField.valueProperty().isNull()
              .or(memberNumberWithdrawalField.textProperty().isEmpty() )
               .or(fullNamewithdrawalField.textProperty().isEmpty() )
              
      );
              
    }

    @FXML
    private void validateFieldsBFP(MouseEvent event) {
 
        saveTransactionpurchasesBtn.disableProperty().bind(
                 dateOfPurchasePurchasesField.valueProperty().isNull()
              .or(purchaseAmountPurchasesField.textProperty().isEmpty() )
               .or(memberNumberPurchasesfield.textProperty().isEmpty() )
               .or(fulNamePurchasesField.textProperty().isEmpty() )
              
      );
    }

    @FXML
    private void ValidateFieldsBFW(MouseEvent event) {

            saveTransactionsWithdrawalBtn.disableProperty().bind(
                 dateOfWithdrawalWithdrawalsField.valueProperty().isNull()
              .or(memberNumberwithdrawalField.textProperty().isEmpty() )
               .or(fullNamewithdrawalFieldBalanceFund.textProperty().isEmpty() )
               .or(purchaseAmountWithdrawalField.textProperty().isEmpty() )
               
              
      );
    }

    @FXML
    private void ValidateFieldsPI(MouseEvent event) {
    saveDetailsPersonalInfo.disableProperty().bind(
                 dateOfBirthPersonalInfo.valueProperty().isNull()
              .or(dateOfRegistrationPersonalInfo.valueProperty().isNull() )
              .or(IDNumberPersonalInfo.textProperty().isEmpty() )
               .or(firstNamePersonalInfo.textProperty().isEmpty() )
               .or(lastNamePersonalInfo.textProperty().isEmpty() )
                .or(surNamePersonalInfo.textProperty().isEmpty() )
                .or(FullNamePersonalInfo.textProperty().isEmpty() )
               .or(EmailAddressPersonalInfo.textProperty().isEmpty() )
                .or(physicalAddressPersonalInfo.textProperty().isEmpty() )
                .or(phoneNumberPersonalInfo.textProperty().isEmpty() ) 
               .or(postalAddressPersonalInfo.textProperty().isEmpty() ) 
                .or(ResidentTownPersonalInfo.textProperty().isEmpty() )  
                 .or(residentCountyPersonalInfo.textProperty().isEmpty() ) 
                     
              
      );
        
        
    }

    @FXML
    private void ValidateFieldsNOK(MouseEvent event) {
        
          
            saveDetailsBtnNextOfKin.disableProperty().bind(
                 dateOfRegistrationNextOfKin.valueProperty().isNull()
               .or(MemberNumberNextOfKin.textProperty().isEmpty() )
               .or(firstNameNextOfKin.textProperty().isEmpty() )
               .or(lastNameNextOfKin.textProperty().isEmpty() )
                .or(surNameNextOfKin.textProperty().isEmpty() )
                .or(fullNameNextOfKin.textProperty().isEmpty() )
               .or(IDNumberNextOfKin.textProperty().isEmpty() )
                .or(EmailAddressNextOfKin.textProperty().isEmpty() )
                .or(physicalAddressNextOfKin.textProperty().isEmpty() ) 
               .or(phoneNumberNextOfKin.textProperty().isEmpty() ) 
                .or(postalAddressNextOfKin.textProperty().isEmpty() )  
                 .or(relationshipTooNextOfKin.textProperty().isEmpty() ) 
                  .or(persentageNextOfKin.textProperty().isEmpty() )
            );
    }


    @FXML
    private void ValidateFieldsHOP(MouseEvent event) {

                 saveTransaction_HomeOwnership.disableProperty().bind(
                 dateOfDeposit_HomeOwnership.valueProperty().isNull()
               .or(memberNumber_HomeOwnership.textProperty().isEmpty() )
               .or(fullName_HomeOwnership.textProperty().isEmpty() )
                );
    }

    @FXML
    private void ValidateFieldsHOW(MouseEvent event) {


        saveTransAction_HomeOwnershipwithdrawal.disableProperty().bind(
                 dateOfWithdrawal_HomeOwnershipwithdrawal.valueProperty().isNull()
               .or(memberNumber_HomeOwnershipwithdrawal.textProperty().isEmpty() )
               .or(fullName_HomeOwnershipwithdrawal.textProperty().isEmpty() )
               
                .or(withdrawFromInterestHomeOwnership.textProperty().isEmpty() )
                );
    }

    @FXML
    private void ValidateFieldsGPD(MouseEvent event) {
    saveTransAction_GaranteedPension.disableProperty().bind(
                 dateOfDeposit_GaranteedPension.valueProperty().isNull()
               .or(memberNumber_GaranteedPension.textProperty().isEmpty() )
               .or(fullName_GarnteedPension.textProperty().isEmpty() )
               .or(depositAmount_GaranteedPension.textProperty().isEmpty() )
                     );
    }

    @FXML
    private void ValidateFieldsGPW(MouseEvent event) {
    
         saveTransAction_GaranteedPensionwithdrawal.disableProperty().bind(
                 dateOfwithdrawal_GaranteedPensionwithdrawal.valueProperty().isNull()
               .or(memberNumber_GaranteedPensionWithdrawal.textProperty().isEmpty() )
               .or(fullName_GaranteedPensionwithdrawal.textProperty().isEmpty() )
               .or(withdrawalAmount_GaranteedPensionwithdrawal.textProperty().isEmpty() )
                
                );
    }

    @FXML
    private void ValidateFieldsPPP(MouseEvent event) {
    

            saveTrnsaction_PersonalPensionBtn.disableProperty().bind(
                 dateOfDeposit_PersonalPension.valueProperty().isNull()
               .or(memberNumber_PersonalPension.textProperty().isEmpty() )
               .or(fullName_PersonalPension.textProperty().isEmpty() )
               .or(PurchaseAmount_PersonalPension.textProperty().isEmpty() )
               .or(PurchaseNumberPersonalPensionDeposit.textProperty().isEmpty() )
            		);
    }

    @FXML
    private void ValidateFieldsPPW(MouseEvent event) {
  
     saveTransAction_personalPensionwithdrawal.disableProperty().bind(
                 dateOfwithdrawal_personalPensionwithdrawal.valueProperty().isNull()
               .or(memberNumber_personalPensionwithdrawal.textProperty().isEmpty() )
               .or(fullName_personalPensionwithdrawal.textProperty().isEmpty() )
               .or(withdrawAmountpersonalPension.textProperty().isEmpty() )
                     );   
    }

    @FXML
    private void validateFieldsMMw(MouseEvent event) {
  
         saveTransactionBtn.disableProperty().bind(
                 dateOfDepositField.valueProperty().isNull()
                 .or(fullNameField.textProperty().isEmpty() )
                 .or(memberNumberField.textProperty().isEmpty() )
                  .or(depositAmountField.textProperty().isEmpty() )
        );
         
    }

    @FXML
    private void clearMMDFields(ActionEvent event) {
        transactionNumberMM.setText(null);
        memberNumberField.setText(null);
        fullNameField.setText(null);
        depositAmountField.setText(null);
        dateOfDepositField.setValue(null);
        transactionNumberMM.setText(getLastTransactionNumber("unittrust").toString());
        newTransactionMMD.setDisable(true);
        memberNumberField.requestFocus();
       
        
    }

    @FXML
    private void clearMMWFields(ActionEvent event) {
        TransNumberMMW.setText(null);
        memberNumberWithdrawalField.setText(null);
        fullNamewithdrawalField.setText(null);
        withdrawalDateWithdrawalField.setValue(null);
        withdrawalAmountField.setText(null);
        withdrawFromInterestMoneyMarket.setText(null);
        TransNumberMMW.setText(getLastTransactionNumber("unittrust").toString());
        newTransactionMMW.setDisable(true);
        memberNumberWithdrawalField.requestFocus();
    }

    @FXML
    private void clearBFPFields(ActionEvent event) {
        PurchaseNumberBalanceFundPurchase.setText(null);
        memberNumberPurchasesfield.setText(null);
        fulNamePurchasesField.setText(null);
        purchaseAmountPurchasesField.setText(null);
        unitsPurchasedPurchasesField.setText(null);
        dateOfPurchasePurchasesField.setValue(null);
        purchasePricePurchasefield.setText(null);
        PurchaseNumberBalanceFundPurchase.setText(getLastTransactionNumber("unittrust").toString());
         BalanceFundPurchaseLogic logic= new BalanceFundPurchaseLogic();
            Double price = null;
        try {
            price = logic.getsellPriceFromDB();
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
            purchasePricePurchasefield.setText(price.toString());
           
        newTransactionBFP.setDisable(true);
        memberNumberPurchasesfield.requestFocus();
        
    }

    @FXML
    private void clearBFWFields(ActionEvent event) throws SQLException {
        TransNumberBFW.setText(null);
        memberNumberwithdrawalField.setText(null);
        fullNamewithdrawalFieldBalanceFund.setText(null);
        purchaseAmountWithdrawalField.setText(null);
        dateOfWithdrawalWithdrawalsField.setValue(null);
        Double price= null;
        BalanceFundWithdrawalLogic logic = new BalanceFundWithdrawalLogic();
        price=logic.getsellPriceFromDB();
        
        sellPriceWithdrawalsField.setText(price.toString());
        TransNumberBFW.setText(getLastTransactionNumber("unittrust").toString());
        
         newTransactionBFW.setDisable(true);
         memberNumberwithdrawalField.requestFocus();
    }

    @FXML
    private void clearPIFields(ActionEvent event) {
    	
    	
        memberNumberPersonalInfo.setText(null);
        IDNumberPersonalInfo.setText(null);
        firstNamePersonalInfo.setText(null);
        lastNamePersonalInfo.setText(null);
        surNamePersonalInfo.setText(null);
        FullNamePersonalInfo.setText(null);
        dateOfBirthPersonalInfo.setValue(null);
        dateOfRegistrationPersonalInfo.setValue(null);
        EmailAddressPersonalInfo.setText(null);
        physicalAddressPersonalInfo.setText(null);
        phoneNumberPersonalInfo.setText(null);
        postalAddressPersonalInfo.setText(null);
        ResidentTownPersonalInfo.setText(null);
        residentCountyPersonalInfo.setText(null);
        PreviousMemberNumber.setText(null);
        
        if(chooseFundType.getValue().equals("UNIT_TRUST")){
       	 editNumber("UNIT_TRUST");
              	
       }else if(chooseFundType.getValue().equals("PENSION")){
       	
       	editNumber("PENSION");
       }
        
        
        IDNumberPersonalInfo.requestFocus();
        
        
        
        
        
        
        
        
        
    }
    public void clearPIFeilds(){
        memberNumberPersonalInfo.setText(null);
        IDNumberPersonalInfo.setText(null);
        firstNamePersonalInfo.setText(null);
        lastNamePersonalInfo.setText(null);
        surNamePersonalInfo.setText(null);
        FullNamePersonalInfo.setText(null);
        dateOfBirthPersonalInfo.setValue(null);
        dateOfRegistrationPersonalInfo.setValue(null);
        EmailAddressPersonalInfo.setText(null);
        physicalAddressPersonalInfo.setText(null);
        phoneNumberPersonalInfo.setText(null);
        postalAddressPersonalInfo.setText(null);
        ResidentTownPersonalInfo.setText(null);
        residentCountyPersonalInfo.setText(null);
        PreviousMemberNumber.setText(null);
        
    	
    }

    @FXML
    private void clearNOKFields(ActionEvent event) {
        MemberNumberNextOfKin.setText(null);
        firstNameNextOfKin.setText(null);
        lastNameNextOfKin.setText(null);
        surNameNextOfKin.setText(null);
        fullNameNextOfKin.setText(null);
        dateOfRegistrationNextOfKin.setValue(null);
        IDNumberNextOfKin.setText(null);
        EmailAddressNextOfKin.setText(null);
        physicalAddressNextOfKin.setText(null);
        phoneNumberNextOfKin.setText(null);
        postalAddressNextOfKin.setText(null);
        relationshipTooNextOfKin.setText(null);
        persentageNextOfKin.setText(null);
        
        MemberNumberNextOfKin.requestFocus();
        
        
        
        
        
        
        
    }

    @FXML
    private void clearHODFields(ActionEvent event) {
        transactionNumberHO.setText(null);
        memberNumber_HomeOwnership.setText(null);
        fullName_HomeOwnership.setText(null);
       // DepositAmmount_HomeOwnership.setText(null);
        dateOfDeposit_HomeOwnership.setValue(null);
         transactionNumberHO.setText(getLastTransactionNumber("HomeOwnership").toString());
         
         newTransactionHOD.setDisable(true);
         memberNumber_HomeOwnership.requestFocus();
        
        
    }

    @FXML
    private void clearHOWFields(ActionEvent event) {
        TransNumberHOW.setText(null);
        memberNumber_HomeOwnershipwithdrawal.setText(null);
        fullName_HomeOwnershipwithdrawal.setText(null);
        depositAmount_HomeOwnershipwithdrawal.setText(null);
        withdrawFromInterestHomeOwnership.setText(null);
        dateOfWithdrawal_HomeOwnershipwithdrawal.setValue(null);
        TransNumberHOW.setText(getLastTransactionNumber("HomeOwnership").toString());
        newTransactionHOW.setDisable(true);
        memberNumber_HomeOwnershipwithdrawal.requestFocus();
        
        
    }

    @FXML
    private void clearGPDFields(ActionEvent event) {
        transactionNumberGP.setText(null);
        memberNumber_GaranteedPension.setText(null);
        fullName_GarnteedPension.setText(null);
        depositAmount_GaranteedPension.setText(null);
        dateOfDeposit_GaranteedPension.setValue(null);
        transactionNumberGP.setText(getLastTransactionNumber("pensionfunds").toString());
        newTransactionGPD.setDisable(true);
        memberNumber_GaranteedPension.requestFocus();
        
    }

    @FXML
    private void clearGPWFields(ActionEvent event) {
        TransNumberGPW.setText(null);
        memberNumber_GaranteedPensionWithdrawal.setText(null);
        fullName_GaranteedPensionwithdrawal.setText(null);
        withdrawalAmount_GaranteedPensionwithdrawal.setText(null);
        withdrawFromInterestGaranteedpension.setText(null);
        dateOfwithdrawal_GaranteedPensionwithdrawal.setValue(null);
        TransNumberGPW.setText(getLastTransactionNumber("pensionfunds").toString());
        newTransactionGPW.setDisable(true);
        memberNumber_GaranteedPensionWithdrawal.requestFocus();
       
    }

    @FXML
    private void clearPPPFields(ActionEvent event) {
        
        PurchaseNumberPersonalPensionDeposit.setText(null);
        memberNumber_PersonalPension.setText(null);
        fullName_PersonalPension.setText(null);
        PurchaseAmount_PersonalPension.setText(null);
        UnitsPurchasedPersonalPensionDeposits.setText(null);
        dateOfDeposit_PersonalPension.setValue(null);
        PurchasePricePersonalPension.setText(null);
        PurchaseNumberPersonalPensionDeposit.setText(getLastTransactionNumber("pensionfunds").toString());
        PersonalPensionDepositLogic logic=new PersonalPensionDepositLogic();
           Double price = null;
        try {
            price = logic.getBuyPriceFromDB();
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
            PurchasePricePersonalPension.setText(price.toString());
       
        newTransactionPPP.setDisable(true);
        memberNumber_PersonalPension.requestFocus();
        
        
        
        
        
    }

    @FXML
    private void clearPPWFields(ActionEvent event) throws SQLException {
        TransNumberPPW.setText(null);
        memberNumber_personalPensionwithdrawal.setText(null);
        fullName_personalPensionwithdrawal.setText(null);
        withdrawAmountpersonalPension.setText(null);
        UnitsSoldPersonalPensionWithdrawal.setText(null);
        dateOfwithdrawal_personalPensionwithdrawal.setValue(null);
        
        Double price = null;
        PersonalPensionWithdrawalLogic logic = new PersonalPensionWithdrawalLogic();
       price= logic.getsellPriceFromDB();
        
        TransNumberPPW.setText(getLastTransactionNumber("pensionfunds").toString());
         SellPricePersonalPension.setText(price.toString());
         
         newTransactionPPW.setDisable(true);
         memberNumber_personalPensionwithdrawal.requestFocus();
    }

    
    @FXML
    private void setPhoto(ActionEvent event) throws IOException {
        
        Stage stage =  (Stage)((Node)event.getSource()).getScene().getWindow();
        
         fileChooser= new FileChooser();
         fileChooser.getExtensionFilters().addAll(new ExtensionFilter("Text Files","*txt"),
                                                  new ExtensionFilter("Image Files","*.png","*.jpg","*.gif"),      
                                                  new ExtensionFilter("Audio Files","*.wav","*.mp3","*.aac"),
                                                  new ExtensionFilter("All Files","*.*")
         );
        file=fileChooser.showOpenDialog(stage);
        if(file!=null){
        System.out.println("file not null"+file.getAbsolutePath());
        image= new Image(file.toURI().toURL().toString(),600,600,true,true);
        System.out.println("Image not null"+file.toURI().toURL().toString());
        
        imageViewer.setImage(image);
        imageViewer.setVisible(true);
        
        FileInputStream  fs2= new FileInputStream(file);
        logic.setFile(file);
       logic.setImage(fs2);
        
        
        }
        
    }

    @FXML
    private void dateRange(ActionEvent event) {
        specificDate.setValue(null);
    }

    @FXML
    private void specificDate(ActionEvent event) {
        fromDate.setValue(null);
        toDate.setValue(null);
    }

    
    AutoCompletionBinding<String> acb0;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
		conn = JavaFirebirdconnect.connectDb();
		conn2 = JavaFirebirdconnect.connectDb1();
        String sql= "select ALLNAMES,MEMBER_NO from MEMBERS";
        PreparedStatement  statement2;
        String sql3= "select ALLNAMES,MEMBER_NO from MEMBERS";
        PreparedStatement  statement3;
try {
 statement2 = conn.prepareStatement(sql);
  ResultSet result2=statement2.executeQuery();
  statement3 = conn2.prepareStatement(sql);
  ResultSet result3=statement3.executeQuery();
  while(result2.next()){
  
  possibleMemberNumbers.add(result2.getString("MEMBER_NO")+" "+result2.getString("ALLNAMES"));
  possibleALLNames.add(result2.getString("MEMBER_NO")+" "+result2.getString("ALLNAMES"));
  }
  while(result3.next()){
      
	  possibleMemberNumbersPENSION.add(result3.getString("MEMBER_NO")+" "+result3.getString("ALLNAMES"));
	  possibleALLNames.add(result3.getString("MEMBER_NO")+" "+result3.getString("ALLNAMES"));
	  
      }
  
} catch (SQLException ex) {
 Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
}
   
      
         acb0 = TextFields.bindAutoCompletion(fullNameSearchField, possibleALLNames);
        acb0.setOnAutoCompleted(e ->  fullNameSearchField.setText(checkForNumbers(e.getCompletion(),fullNameSearch)));
        
        firstNamePersonalInfo.textProperty().addListener((ov, oldValue, newValue) -> {
        	firstNamePersonalInfo.setText(newValue.toUpperCase());
       }); 
        
        lastNamePersonalInfo.textProperty().addListener((ov, oldValue, newValue) -> {
        	lastNamePersonalInfo.setText(newValue.toUpperCase());
       });
        
        surNamePersonalInfo.textProperty().addListener((ov, oldValue, newValue) -> {
        	surNamePersonalInfo.setText(newValue.toUpperCase());
       });
        
        FullNamePersonalInfo.textProperty().addListener((ov, oldValue, newValue) -> {
        	FullNamePersonalInfo.setText(newValue.toUpperCase());
       });
        
        physicalAddressPersonalInfo.textProperty().addListener((ov, oldValue, newValue) -> {
        	physicalAddressPersonalInfo.setText(newValue.toUpperCase());
       });
        postalAddressPersonalInfo.textProperty().addListener((ov, oldValue, newValue) -> {
        	postalAddressPersonalInfo.setText(newValue.toUpperCase());
       });
        
        ResidentTownPersonalInfo.textProperty().addListener((ov, oldValue, newValue) -> {
        	ResidentTownPersonalInfo.setText(newValue.toUpperCase());
       });
        
        residentCountyPersonalInfo.textProperty().addListener((ov, oldValue, newValue) -> {
        	residentCountyPersonalInfo.setText(newValue.toUpperCase());
       });
        
        
        
        
        firstNameNextOfKin.textProperty().addListener((ov, oldValue, newValue) -> {
        	firstNameNextOfKin.setText(newValue.toUpperCase());
       });
        lastNameNextOfKin.textProperty().addListener((ov, oldValue, newValue) -> {
        	lastNameNextOfKin.setText(newValue.toUpperCase());
       });
        surNameNextOfKin.textProperty().addListener((ov, oldValue, newValue) -> {
        	surNameNextOfKin.setText(newValue.toUpperCase());
       });
        fullNameNextOfKin.textProperty().addListener((ov, oldValue, newValue) -> {
        	fullNameNextOfKin.setText(newValue.toUpperCase());
       });
        IDNumberNextOfKin.textProperty().addListener((ov, oldValue, newValue) -> {
        	IDNumberNextOfKin.setText(newValue.toUpperCase());
       });
        physicalAddressNextOfKin.textProperty().addListener((ov, oldValue, newValue) -> {
        	physicalAddressNextOfKin.setText(newValue.toUpperCase());
       });
        postalAddressNextOfKin.textProperty().addListener((ov, oldValue, newValue) -> {
        	postalAddressNextOfKin.setText(newValue.toUpperCase());
       });
        relationshipTooNextOfKin.textProperty().addListener((ov, oldValue, newValue) -> {
        	relationshipTooNextOfKin.setText(newValue.toUpperCase());
       });
        fullNameSearchField.textProperty().addListener((ov, oldValue, newValue) -> {
        	fullNameSearchField.setText(newValue.toUpperCase());
       });
        BankAccountNameBankDetails.textProperty().addListener((ov, oldValue, newValue) -> {
        	BankAccountNameBankDetails.setText(newValue.toUpperCase());
       });
        BankNameBankDetails.textProperty().addListener((ov, oldValue, newValue) -> {
        	BankNameBankDetails.setText(newValue.toUpperCase());
       });
        
        fullNameInvestmentApplication.textProperty().addListener((ov, oldValue, newValue) -> {
        	fullNameInvestmentApplication.setText(newValue.toUpperCase());
       });
        
        BankAccountNameBankDetails.textProperty().addListener((ov, oldValue, newValue) -> {
        	BankAccountNameBankDetails.setText(newValue.toUpperCase());
       });
        
        BankNameBankDetails.textProperty().addListener((ov, oldValue, newValue) -> {
        	BankNameBankDetails.setText(newValue.toUpperCase());
       });
        
        fullNameFundTransfer.textProperty().addListener((ov, oldValue, newValue) -> {
        	fullNameFundTransfer.setText(newValue.toUpperCase());
       });
        
        accountNumberBankDetails.textProperty().addListener((ov, oldValue, newValue) -> {
        	accountNumberBankDetails.setText(newValue.toUpperCase());
       });
        
        branchLocationBankDetails.textProperty().addListener((ov, oldValue, newValue) -> {
        	branchLocationBankDetails.setText(newValue.toUpperCase());
       });
        
        KRAPinBankDetails.textProperty().addListener((ov, oldValue, newValue) -> {
        	KRAPinBankDetails.setText(newValue.toUpperCase());
       });
        
        branchLocationBankDetails.textProperty().addListener((ov, oldValue, newValue) -> {
        	branchLocationBankDetails.setText(newValue.toUpperCase());
       });
        
        accountNumberBankDetails.textProperty().addListener((ov, oldValue, newValue) -> {
        	accountNumberBankDetails.setText(newValue.toUpperCase());
       });
        KRAPinBankDetails.textProperty().addListener((ov, oldValue, newValue) -> {
        	KRAPinBankDetails.setText(newValue.toUpperCase());
       });
     /*   depositAmountField.textProperty().addListener((ov, oldValue, newValue) -> {
        	BigDecimal bd = new BigDecimal(newValue);
        	DecimalFormat formatter  = new DecimalFormat(",###");
        	String newestValue = formatter.format(bd)+newValue.substring(newValue.indexOf(""));
        	depositAmountField.setText(newestValue);
       }); */ 
        
        
        
        AutoCompletionBinding<String> acb71 =   TextFields.bindAutoCompletion(memberNumberInvestmentApplication,possibleMemberNumbers);
        acb71.setOnAutoCompleted(e ->  memberNumberInvestmentApplication.setText(checkForNumbers(e.getCompletion(),fullNameInvestmentApplication)));
       
        AutoCompletionBinding<String> acb72 =   TextFields.bindAutoCompletion(memberNumberFundTransfer,possibleMemberNumbers);
        acb72.setOnAutoCompleted(e ->  memberNumberFundTransfer.setText(checkForNumbers(e.getCompletion(),fullNameFundTransfer)));
       
        AutoCompletionBinding<String> acb =   TextFields.bindAutoCompletion(memberNumberReport,possibleALLNames);
        acb.setOnAutoCompleted(e ->  memberNumberReport.setText(checkForNumbers(e.getCompletion())));
        
        AutoCompletionBinding<String> acb1 =   TextFields.bindAutoCompletion(depositHistoryAccountNumberField,possibleMemberNumbers);
        acb1.setOnAutoCompleted(e ->  depositHistoryAccountNumberField.setText(checkForNumbers(e.getCompletion())));
          
        AutoCompletionBinding<String> acb2 =   TextFields.bindAutoCompletion(withdrawalHistoryAccountNumberField,possibleMemberNumbers);
        acb2.setOnAutoCompleted(e ->  withdrawalHistoryAccountNumberField.setText(checkForNumbers(e.getCompletion())));
        
        AutoCompletionBinding<String> acb3 =   TextFields.bindAutoCompletion(transactionHistoryAccountSearchField,possibleMemberNumbers);
        acb3.setOnAutoCompleted(e ->  transactionHistoryAccountSearchField.setText(checkForNumbers(e.getCompletion())));
        
        AutoCompletionBinding<String> acb4 =   TextFields.bindAutoCompletion(depositHistoryAccountSearch_HomeOwnership,possibleMemberNumbers);
        acb4.setOnAutoCompleted(e ->  depositHistoryAccountSearch_HomeOwnership.setText(checkForNumbers(e.getCompletion())));
        
        AutoCompletionBinding<String> acb5 =   TextFields.bindAutoCompletion(depositHistoryAccountSearch_GaranteedPension,possibleMemberNumbers);
        acb5.setOnAutoCompleted(e ->  depositHistoryAccountSearch_GaranteedPension.setText(checkForNumbers(e.getCompletion())));
        
         AutoCompletionBinding<String> acb6 =   TextFields.bindAutoCompletion(depositHistoryAccountSearch_PersonalPension,possibleMemberNumbers);
        acb6.setOnAutoCompleted(e ->  depositHistoryAccountSearch_PersonalPension.setText(checkForNumbers(e.getCompletion())));
        
        AutoCompletionBinding<String> acb7 =   TextFields.bindAutoCompletion(memberNumberField,possibleMemberNumbers);
        acb7.setOnAutoCompleted(e ->  memberNumberField.setText(checkForNumbers(e.getCompletion(),fullNameField)));
        
        AutoCompletionBinding<String> acb8 =   TextFields.bindAutoCompletion(memberNumberWithdrawalField,possibleMemberNumbers);
        acb8.setOnAutoCompleted(e ->  memberNumberWithdrawalField.setText(checkForNumbers(e.getCompletion(),fullNamewithdrawalField)));
       
         AutoCompletionBinding<String> acb9 =   TextFields.bindAutoCompletion(memberNumberPurchasesfield,possibleMemberNumbers);
        acb9.setOnAutoCompleted(e ->  memberNumberPurchasesfield.setText(checkForNumbers(e.getCompletion(),fulNamePurchasesField)));
       
        AutoCompletionBinding<String> acb10 =   TextFields.bindAutoCompletion(memberNumberwithdrawalField,possibleMemberNumbers);
        acb10.setOnAutoCompleted(e ->  memberNumberwithdrawalField.setText(checkForNumbers(e.getCompletion(),fullNamewithdrawalFieldBalanceFund)));
        
        AutoCompletionBinding<String> acb11 =   TextFields.bindAutoCompletion(MemberNumberNextOfKin,possibleMemberNumbers);
        acb11.setOnAutoCompleted(e ->  MemberNumberNextOfKin.setText(checkForNumbers(e.getCompletion())));
        
        AutoCompletionBinding<String> acb12 =   TextFields.bindAutoCompletion(memberNumber_HomeOwnership,possibleMemberNumbers);
        acb12.setOnAutoCompleted(e ->  memberNumber_HomeOwnership.setText(checkForNumbers(e.getCompletion(),fullName_HomeOwnership)));
        
        AutoCompletionBinding<String> acb13 =   TextFields.bindAutoCompletion(memberNumber_HomeOwnershipwithdrawal,possibleMemberNumbers);
        acb13.setOnAutoCompleted(e ->  memberNumber_HomeOwnershipwithdrawal.setText(checkForNumbers(e.getCompletion(),fullName_HomeOwnershipwithdrawal)));
        
        AutoCompletionBinding<String> acb14 =   TextFields.bindAutoCompletion(memberNumber_GaranteedPension,possibleMemberNumbersPENSION);
        acb14.setOnAutoCompleted(e ->  memberNumber_GaranteedPension.setText(checkForNumbers(e.getCompletion(),fullName_GarnteedPension)));
        
        AutoCompletionBinding<String> acb15 =   TextFields.bindAutoCompletion(memberNumber_GaranteedPensionWithdrawal,possibleMemberNumbersPENSION);
        acb15.setOnAutoCompleted(e ->  memberNumber_GaranteedPensionWithdrawal.setText(checkForNumbers(e.getCompletion(),fullName_GaranteedPensionwithdrawal)));
        
         AutoCompletionBinding<String> acb16 =   TextFields.bindAutoCompletion(memberNumber_PersonalPension,possibleMemberNumbersPENSION);
        acb16.setOnAutoCompleted(e ->  memberNumber_PersonalPension.setText(checkForNumbers(e.getCompletion(),fullName_PersonalPension)));
        
         AutoCompletionBinding<String> acb17 =   TextFields.bindAutoCompletion(memberNumber_personalPensionwithdrawal,possibleMemberNumbersPENSION);
        acb17.setOnAutoCompleted(e ->  memberNumber_personalPensionwithdrawal.setText(checkForNumbers(e.getCompletion(),fullName_personalPensionwithdrawal)));
        
        AutoCompletionBinding<String> acb18 =   TextFields.bindAutoCompletion(PreviousMemberNumber,possibleMemberNumbers);
        acb18.setOnAutoCompleted(e ->  PreviousMemberNumber.setText(checkForNumbers(e.getCompletion(),firstNamePersonalInfo)));
        
        
          
          listview.setItems(oblist); 
       chooseAccount.getItems().addAll("UNIT_TRUST","PENSION");
        chooseAccount.setValue("UNIT_TRUST");
        
        
        chooseFundType.getItems().addAll("UNIT_TRUST","PENSION");
        chooseFundType.setValue("UNIT_TRUST");
        PurchaseNumberBalanceFundPurchase.setDisable(true);
        memberNumberPersonalInfo.setDisable(true);
        unitsPurchasedPurchasesField.setDisable(true);
        purchasePricePurchasefield.setDisable(true);
        sellPriceWithdrawalsField.setDisable(true);
        unitsSoldWithdrwalField.setDisable(true);
        PurchasePricePersonalPension.setDisable(true);
        SellPricePersonalPension.setDisable(true);
        UnitsPurchasedPersonalPensionDeposits.setDisable(true);
        UnitsSoldPersonalPensionWithdrawal.setDisable(true);
        PurchaseNumberPersonalPensionDeposit.setDisable(true);
        //PreviousMemberNumber.setDisable(true);
        transactionNumberGP.setDisable(true);
        //transactionNumberHO.setDisable(true);
        transactionNumberMM.setDisable(true);
        TransNumberPPW.setDisable(true);
        TransNumberGPW.setDisable(true);
        //TransNumberHOW.setDisable(true);
        TransNumberBFW.setDisable(true);
        TransNumberMMW.setDisable(true);
       /* EditTableRadioBtn.setDisable(true);*/
        chooseReport.getItems().addAll("balancefund","moneymarket","garanteedpension","homeownership",
                "personalpension");
        chooseReport.setValue("balancefund");
        
        
        MoneyMarketMOPDeposit.getItems().addAll("M-PESA","Cheque","Standing_Order","Bank_Transfer","RE-INVESTING","ETF");
        MoneyMarketMOPDeposit.setValue("M-PESA");
        
        
        
        moneyMarketMOPW.getItems().addAll("INTEREST_WITHDRAWAL","PRINCIPAL_WITHDRAWAL");
        moneyMarketMOPW.setValue("PRINCIPAL_WITHDRAWAL");
        
        garanteedPPMOPW.getItems().addAll("INTEREST_WITHDRAWAL","PRINCIPAL_WITHDRAWAL");
        garanteedPPMOPW.setValue("PRINCIPAL_WITHDRAWAL");
        
        
        
        PersonalPPMOPD.getItems().addAll("M-PESA","Cheque","Standing_Order","Bank_Transfer");
        PersonalPPMOPD.setValue("M-PESA");
                
        
        balabceFundMOPP.getItems().addAll("M-PESA","Cheque","Standing_Order","Bank_Transfer");
        balabceFundMOPP.setValue("M-PESA");
       
         
       // balabceFundMOPW.getItems().addAll("None","Cash","Cheque","KCB","Barclays","Standard Chartered","National Bank","K-Rep");
        balabceFundMOPW.setValue("None");
        
       
         memberType.getItems().addAll("Individual","Joint","Group");
         memberType.setValue("Individual");
         
         accountTypeFundTransfer.getItems().addAll("Individual","Joint","Group");
         accountTypeFundTransfer.setValue("Individual");
              
         genderPersonalInfo.getItems().addAll("Male","Female");
         genderPersonalInfo.setValue("Male");
         
         maritalStutus.getItems().addAll("Single","Married","Devorced");
         maritalStutus.setValue("Single");
               
         selectFundPostInterest.getItems().addAll("Money Market","Guatanteed Pension");
         selectFundPostInterest.setValue("Money Market");
         
         
         EditTransactionChoice.getItems().addAll("INTEREST","PURCHASE","WITHDRAWAL");
         EditTransactionChoice.setValue("INTEREST");
         
         
        homeOwnershipMOPD.getItems().addAll("Money Market","Guatanteed Pension");
        homeOwnershipMOPD.setValue("Money Market");
        
        
        garanteedPPMOPD.getItems().addAll("M-PESA","Cheque","Standing Order","Bank_Transfer","RE-INVESTING");
        garanteedPPMOPD.setValue("M-PESA");
        
        investmentTypeInvestmentApplication.getItems().addAll("MoneyMarket","BalanceFund","HomeOwnerShip","GaranteedPension","PersonalPension");
        investmentTypeInvestmentApplication.setValue("MoneyMarket");
        
        fromInvestmentType_FundTransfer.getItems().addAll("MoneyMarket","BalanceFund","HomeOwnerShip","GuaranteedPension","PersonalPension");
        fromInvestmentType_FundTransfer.setValue("MoneyMarket");
        
        
        toInvestmentType_fundTransfer.getItems().addAll("MoneyMarket","BalanceFund","HomeOwnerShip","GuaranteedPension","PersonalPension");
        toInvestmentType_fundTransfer.setValue("MoneyMarket");
        
        AccountTypeInvestmentApplication.getItems().addAll("Individual","Joint","Group");
        AccountTypeInvestmentApplication.setValue("Individual");
        
        chooseTableCombobox.getItems().addAll("balancefundwithdrawal","moneymarketdeposit","moneymarketwithdrawal",
                "fundtransfer","investmentapplication","garanteedpensiondeposit","garanteedpensionwithdrawals",
                "homeownershipdeposit","homeownershipwithdrawal","nextofkininformation","personalinformation",
                "personalpensiondeposit","balancefundpurchase","personalpensionwithdrawal");
        chooseTableCombobox.setValue("personalinformation");
        
    } 
    
    public String checkForNumbers(String input){
         String str = input;
         str = str.replaceAll("[^0-9]", "");
        
    return str;
    }

    public String TrimText(String input){
        
         
        
    return input.trim();
    }
    public String checkForNumbers(String input,TextField field){
         System.out.println("input before name : "+input);
         String str = input;
         str = str.replaceAll("[^0-9]", "");
         String name = input;
         System.out.println("input after name : "+input);
        /* name=name.replaceAll("[^a-zA-Z-./&;'|!#$%@*()_+-<>,?`~ ]+", "");*/
         name=name.replaceAll("[^a-zA-Z-./&;'|!#$%@*()_`~,?<> ]+", "");
         field.setText(name.trim());
         System.out.println("extracted name : "+name);
                 //[a-zA-Z]+
        
    return str;
    }
    
    public String AppostropheNames(String input){
        System.out.println("input before name : "+input);
        String str = input;
        str = str.replaceAll("[^0-9]", "");
        String name = input;
        System.out.println("input after name : "+input);
        name=name.replaceAll("[^a-zA-Z-./&;|!#$%@*()_+-<>,?`~ ]+", "");
       /* name=name.replaceAll("[^a-zA-Z-./&;'|!#$%@*()_`~,?<> ]+", "");*/
        name.trim();
        System.out.println("extracted name : "+name);
                //[a-zA-Z]+
       
   return str;
   }
    public void showProfilePhoto(String value,String FundType){
        InputStream is=null;
        OutputStream os=null;
       if(FundType.equals("UNIT_TRUST")){
    	   conn=JavaFirebirdconnect.connectDb();
    }else if(FundType.equals("PENSION")){
    	
    	conn=JavaFirebirdconnect.connectDb1();
    	
    }
      
                   String sql= "select * from MEMBERS where MEMBER_NO='";
                   sql=sql.concat(value); sql=sql.concat("'");
                   PreparedStatement  statement2;
        try {
            statement2 = conn.prepareStatement(sql);
             ResultSet result2=statement2.executeQuery();
             while(result2.next()){
                 is=result2.getBinaryStream("PICTURE");
                 }
             os=new FileOutputStream(new File("./resources/photo.jpg"));  
                  byte [] content= new byte[1024];
                  int size=0;
                  while((size=is.read(content))!=-1){
                  os.write(content,0,size);
                   }
                  os.close();
                  is.close();
                   System.out.println("image code not running");
                  image1= new Image("file:./resources/photo.jpg",600,600,true,true);
                    System.out.println("image path ./resources/photo.jpg");
                  imageViewProfile.setImage(image1);
                   imageViewProfile.setVisible(true);
                   System.out.println("image code running");
                   
                   deleteFile("./resources/photo.jpg");
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    
    }
    
    public void showProfilePhoto(String value){
        InputStream is=null;
        OutputStream os=null;
       
      conn=javaconnect.connectDb1();
                   String sql= "select * from personalinfo_photo where MemberNumber='";
                   sql=sql.concat(value); sql=sql.concat("' AND FullName ='");
                   sql=sql.concat("'");
                   PreparedStatement  statement2;
        try {
            statement2 = conn.prepareStatement(sql);
             ResultSet result2=statement2.executeQuery();
             while(result2.next()){
                 is=result2.getBinaryStream("Passport_Photo");
                 }
             os=new FileOutputStream(new File("./resources/photo.jpg"));  
                  byte [] content= new byte[1024];
                  int size=0;
                  while((size=is.read(content))!=-1){
                  os.write(content,0,size);
                   }
                  os.close();
                  is.close();
                   System.out.println("image code not running");
                  image1= new Image("file:./resources/photo.jpg",600,600,true,true);
                    System.out.println("image path ./resources/photo.jpg");
                    imageViewProfile.setImage(image1);
                    imageViewProfile.setVisible(true);
                   System.out.println("image code running");
                   
                   deleteFile("./resources/photo.jpg");
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    
    }
    
    public void showProfilePhoto1( ResultSet result2){
        InputStream is=null;
        OutputStream os=null;
        InputStream is1=null;
        OutputStream os1=null;
     
        try {
           
             while(result2.next()){
                 is=result2.getBinaryStream("PICTURE");
                 is1=result2.getBinaryStream("SIGNATURE");
                 }
             os=new FileOutputStream(new File("./resources/photo.jpg"));  
             os1=new FileOutputStream(new File("./resources/photo1.jpg"));
                  byte [] content= new byte[1024];
                  int size=0;
                  while((size=is.read(content))!=-1){
                  os.write(content,0,size);
                   }
                  byte [] content1= new byte[1024];
                  int size1=0;
                  while((size1=is.read(content1))!=-1){
                  os1.write(content1,0,size1);
                   }
                  os.close();
                  is.close();
                  
                  os1.close();
                  is1.close();
                   System.out.println("image code not running");
                  image1= new Image("file:./resources/photo.jpg",600,600,true,true);
                    System.out.println("image path ./resources/photo.jpg");
                    imageViewer.setImage(image1);
                    imageViewer.setVisible(true);
                    
                    
                    image = new Image("file:./resources/photo1.jpg",600,600,true,true);
                    System.out.println("image path ./resources/photo1.jpg");
                    imageViewer1.setImage(image);
                    imageViewer1.setVisible(true);
                   System.out.println("image code running");
                   
                   deleteFile("./resources/photo.jpg");
                   deleteFile("./resources/photo1.jpg");
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    
    }
    
       public void deleteFile(String path){
        try{
            File f = null;
            f = new File(path);
            f.delete();
             System.out.println("file deleted successful");
        } catch (Exception e){
         e.printStackTrace();
        }
     
    
    }

    
  
    @FXML
    private void trimTextfield2(MouseEvent event) {
       
    }

    @FXML
    private void trimTextfield3(ContextMenuEvent event) {
       
    }

    @FXML
    private void trimTextField(ActionEvent event) {
    }

    @FXML
    private void keypressed(KeyEvent event) {
     
        
        
    }

    @FXML
    private void keyReleased(KeyEvent event) {
       
       
    }

    @FXML
    private void callchequeWindowMM(ActionEvent event) {
        if(MoneyMarketMOPDeposit.getValue()=="Cheque"){
        Stage primaryStage= new Stage();
        callChequeWindow window= new callChequeWindow(primaryStage,memberNumberField.getText(),transactionNumberMM.getText());
        }
    }

    @FXML
    private void callchequeWindowBF(ActionEvent event) {
         if(balabceFundMOPP.getValue()=="Cheque"){
         Stage primaryStage= new Stage();
        callChequeWindow window= new callChequeWindow(primaryStage,memberNumberPurchasesfield.getText(),PurchaseNumberBalanceFundPurchase.getText());
         }
    }

    @FXML
    private void callchequeWindowHO(ActionEvent event) {
        if(homeOwnershipMOPD.getValue()=="Cheque"){
         Stage primaryStage= new Stage();
        callChequeWindow window= new callChequeWindow(primaryStage,memberNumber_HomeOwnership.getText(),transactionNumberHO.getText());
        }
    }

    @FXML
    private void callchequeWindowGP(ActionEvent event) {
         if(garanteedPPMOPD.getValue()=="Cheque"){
         Stage primaryStage= new Stage();
        callChequeWindow window= new callChequeWindow(primaryStage,memberNumber_GaranteedPension.getText(),transactionNumberGP.getText());
         }
    }

    @FXML
    private void callchequeWindowPP(ActionEvent event) {
           if(PersonalPPMOPD.getValue()=="Cheque"){
         Stage primaryStage= new Stage();
        callChequeWindow window= new callChequeWindow(primaryStage,memberNumber_PersonalPension.getText(),PurchaseNumberPersonalPensionDeposit.getText());
           }
    }
    
    @FXML
    public void showAboutMenu(ActionEvent event){
    	Stage primaryStage= new Stage();
        callAboutWindow window= new callAboutWindow(primaryStage);
          
    	
    }

    @FXML
    private void searchByID(ActionEvent event) {
        
        if(IDSearch.isSelected()){
        acb0.dispose();
        
        }else{
        
         acb0 = TextFields.bindAutoCompletion(fullNameSearchField, possibleMemberNumbers);
        acb0.setOnAutoCompleted(e ->  fullNameSearchField.setText(checkForNumbers(e.getCompletion())));
        }
    }

    @FXML
    private void updateMemberDetails(ActionEvent event) {
    	  LocalDatePersistenceConverter date12= new LocalDatePersistenceConverter();
          String notify="N";
          if(smsNotify.isSelected()){
          	
          	notify="Y";
          	}
          String sql="";
    	 
    	 		
    	 		  if(chooseFundType.getValue().equals("UNIT_TRUST")){
    	         	 conn=JavaFirebirdconnect.connectDb();
    	              
    	        	  sql="UPDATE MEMBERS SET MEMBER_NO=?,CUSTOMER_NAME=?,SURNAME=?,LASTNAME=?,OTHERNAMES=?,ALLNAMES=?,POST_ADDRESS=?,REG_DATE=?,TEL_NO=?,TOWN=?,STREET=?,COUNTRY=?,SMS_NTFY=?,GSM_NO=?,E_MAIL=?,ID_NO=?,PICTURE=?,SIGNATURE=?,DOB=?,GENDER=?,MARITALSTATUS=?,UNAME=?"
    	            		+ " WHERE MEMBER_NO='";sql=sql.concat(PreviousMemberNumber.getText()+"'");
    	         }else if(chooseFundType.getValue().equals("PENSION")){
    	         	
    	         	conn=JavaFirebirdconnect.connectDb1();
    	         	sql="UPDATE MEMBERS SET MEMBER_NO=?,FIRSTNAME=?,SURNAME=?,LASTNAME=?,OTHERNAMES=?,ALLNAMES=?,POST_ADDRESS=?,REG_DATE=?,TEL_NO=?,TOWN=?,STREET=?,COUNTRY=?,SMS_NTFY=?,GSM_NO=?,E_MAIL=?,ID_NO=?,PICTURE=?,SIGNATURE=?,DOB=?,GENDER=?,MARITALSTATUS=?,UNAME=?"
    	            		+ " WHERE MEMBER_NO='";sql=sql.concat(PreviousMemberNumber.getText()+"'");
    	         }
    	 		  
    	 		 PreparedStatement preparedStatement;
    	 	   	try {
    	 	   		System.out.println(sql);
    	 	   		     preparedStatement = conn.prepareStatement(sql);
    	 	   		     preparedStatement.setString(1, memberNumberPersonalInfo.getText());
    	 		   		 preparedStatement.setString(2, firstNamePersonalInfo.getText());
    	 		   		 preparedStatement.setString(3, surNamePersonalInfo.getText());
    	 		   		 preparedStatement.setString(4, lastNamePersonalInfo.getText());
    	 		   		 preparedStatement.setString(5, lastNamePersonalInfo.getText());
    	 		   		 preparedStatement.setString(6, FullNamePersonalInfo.getText());
    	 		   		 preparedStatement.setString(7, postalAddressPersonalInfo.getText());
    	 		   		 preparedStatement.setTimestamp(8, date12.convertToTimestamp(date12.convertToDatabaseColumn(dateOfRegistrationPersonalInfo.getValue())));
    	 	   		     preparedStatement.setString(9, phoneNumberPersonalInfo.getText());
    	 		   		 preparedStatement.setString(10, ResidentTownPersonalInfo.getText());
    	 		   		 preparedStatement.setString(11, physicalAddressPersonalInfo.getText());
    	 			   	 preparedStatement.setString(12, residentCountyPersonalInfo.getText());
    	 			     preparedStatement.setString(13, notify);
    	 			   	 preparedStatement.setString(14, phoneNumberPersonalInfo.getText());
    	 			   	 preparedStatement.setString(15, EmailAddressPersonalInfo.getText());
    	 			   	 preparedStatement.setString(16, IDNumberPersonalInfo.getText());
    	 			   	 preparedStatement.setBinaryStream(17, new FileInputStream(file));
    	 			   	 preparedStatement.setBinaryStream(18, new FileInputStream(file1));
    	 			   	 preparedStatement.setTimestamp(19,date12.convertToTimestamp(date12.convertToDatabaseColumn(dateOfBirthPersonalInfo.getValue())));
    	 			   	 preparedStatement.setString(20, genderPersonalInfo.getValue());
    	 				 preparedStatement.setString(21, maritalStutus.getValue());
    	 				 preparedStatement.setString(22, userName);
    	 				 preparedStatement .executeUpdate();
    	 				 
    	 				 Alert alert = new Alert(Alert.AlertType.INFORMATION);
    	 	             alert.setContentText("Data saved Successfull !");
    	 	           alert.showAndWait();
    	 	   	} catch (SQLException e) {
    	 	   		// TODO Auto-generated catch block
    	 	   		e.printStackTrace();
    	 	   	} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    	 		  
    	 		  
    	
    	
    }

    @FXML
    private void editMemberDetails(ActionEvent event) {
        LocalDatePersistenceConverter date= new LocalDatePersistenceConverter();
        
        String sql="";
        String firstName="";
        try {
            if(chooseFundType.getValue().equals("UNIT_TRUST")){
             	conn=JavaFirebirdconnect.connectDb();
          	  
          	  sql= "select * from MEMBERS where MEMBER_NO='";
              sql=sql.concat(PreviousMemberNumber.getText()+"'");
              
              firstName="CUSTOMER_NAME";
           }else if(chooseFundType.getValue().equals("PENSION")){
           	
           	conn=JavaFirebirdconnect.connectDb1();
           	firstName="FIRSTNAME";
            sql= "select * from MEMBERS where MEMBER_NO='";
            sql=sql.concat(PreviousMemberNumber.getText()+"'");
           	  
           }
            
            
            /*  preparedStatement = conn.prepareStatement(sql);
    	 	   			 result.getString(1, memberNumberPersonalInfo.getText());
    	 		   		 String firstName=result.getString(2, firstNamePersonalInfo.getText());
    	 		   		 String surName=result.getString(3, surNamePersonalInfo.getText());
    	 		   		 String lastName=result.getString(4, lastNamePersonalInfo.getText());
    	 		   		 result.getString(5, lastNamePersonalInfo.getText());
    	 		   		 result.getString(6, FullNamePersonalInfo.getText());
    	 		   		 result.getString(7, postalAddressPersonalInfo.getText());
    	 		   		 LocalDate dateofReg=result.getTimestamp(8, date12.convertToTimestamp(date12.convertToDatabaseColumn(dateOfRegistrationPersonalInfo.getValue())));
    	 	   		     String phoneNumber=result.getString(9, phoneNumberPersonalInfo.getText());
    	 		   		 String ResidentTown=result.getString(10, ResidentTownPersonalInfo.getText());
    	 		   		 String pyhsicalAddress=result.getString(11, physicalAddressPersonalInfo.getText());
    	 			   	 result.getString(12, residentCountyPersonalInfo.getText());
    	 			     result.getString(13, notify);
    	 			   	 result.getString(14, phoneNumberPersonalInfo.getText());
    	 			   	 String email=result.getString(15, EmailAddressPersonalInfo.getText());
    	 			   	 String idNumber=result.getString(16, IDNumberPersonalInfo.getText());
    	 			   	 result.getBinaryStream(17, new FileInputStream(file));
    	 			   	 result.getBinaryStream(18, new FileInputStream(file1));
    	 			   	 LocalDate dateofBirth=result.getTimestamp(19,date12.convertToTimestamp(date12.convertToDatabaseColumn(dateOfBirthPersonalInfo.getValue())));
    	 			   	 result.getString(20, genderPersonalInfo.getValue());
    	 				 result.getString(21, maritalStutus.getValue());
    	 				 result.getString(22, userName);*/
       
                   String fullName=firstNamePersonalInfo.getText();
           statement=conn.prepareStatement(sql);
                   
                      
             result=statement.executeQuery();
            System.out.println(" working sql : "+sql);
            while(result.next()){
         /*       System.out.println("working");
            String idNumber=result.getString("identificationNumber");
           
            String lastName=result.getString("lastname");
            String surName=result.getString("surName");
            String email=result.getString("EmailAddress");
            LocalDate dateofReg=date.convertToEntityAttribute(result.getDate("DateOfRegistration"));
            LocalDate dateofBirth=date.convertToEntityAttribute(result.getDate("DateOfBirth")); 
            String phoneNumber=result.getString("phoneNumber"); 
            String pyhsicalAddress=result.getString("pyhsicalAddress"); 
            String postalCode=result.getString("postalCode"); 
            String ResidentTown=result.getString("ResidentTown"); 
            String county=result.getString("county"); 
            String gender=result.getString("gender"); 
            String maritalStatus=result.getString("maritalStutus"); 
            String memberType1=result.getString("memberType"); 
            String SavedByUser=result.getString("SavedByUser"); 
            sql="UPDATE MEMBERS (MEMBER_NO=?,CUSTOMER_NAME=?,SURNAME=?,LASTNAME=?,OTHERNAMES=?,ALLNAMES=?,POST_ADDRESS=?,REG_DATE=?,TEL_NO=?,TOWN=?,STREET=?,COUNTRY=?,SMS_NTFY=?,GSM_NO=?,E_MAIL=?,ID_NO=?,PICTURE=?,SIGNATURE=?,DOB=?,GENDER=?,MARITALSTATUS=?,UNAME=?)"
            		+ " WHERE MEMBER_NO='";sql=sql.concat(PreviousMemberNumber.getText()+"'");*/
            
            memberNumberPersonalInfo.setText(PreviousMemberNumber.getText());
            IDNumberPersonalInfo.setText(result.getString("ID_NO"));
            firstNamePersonalInfo.setText(result.getString(firstName));
            lastNamePersonalInfo.setText(result.getString("LASTNAME"));
            surNamePersonalInfo.setText(result.getString("SURNAME"));
            FullNamePersonalInfo.setText(result.getString("ALLNAMES"));
          /*  dateOfBirthPersonalInfo.setValue(dateofBirth);
            dateOfRegistrationPersonalInfo.setValue(null);*/
            EmailAddressPersonalInfo.setText(result.getString("E_MAIL"));
            physicalAddressPersonalInfo.setText(result.getString("STREET"));
            phoneNumberPersonalInfo.setText(result.getString("GSM_NO"));
            postalAddressPersonalInfo.setText(result.getString("POST_ADDRESS"));
            ResidentTownPersonalInfo.setText(result.getString("TOWN"));
            residentCountyPersonalInfo.setText(result.getString("COUNTRY"));
            genderPersonalInfo.setValue(result.getString("GENDER"));
            maritalStutus.setValue(result.getString("MARITALSTATUS"));
            
           
            showProfilePhoto1(result);
            
            
            
            
            }
            } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
            
            
            
        
        
    }
    
    @FXML
    private void ValidateFieldsPIUpdates(MouseEvent event) {
    	
    	updateMemberDetails.disableProperty().bind(
                  dateOfBirthPersonalInfo.valueProperty().isNull()
                .or(IDNumberPersonalInfo.textProperty().isEmpty() )
                .or(firstNamePersonalInfo.textProperty().isEmpty() )
                .or(lastNamePersonalInfo.textProperty().isEmpty() )
                 .or(surNamePersonalInfo.textProperty().isEmpty() )
                 .or(FullNamePersonalInfo.textProperty().isEmpty() )
                .or(EmailAddressPersonalInfo.textProperty().isEmpty() )
                 .or(physicalAddressPersonalInfo.textProperty().isEmpty() )
                 .or(phoneNumberPersonalInfo.textProperty().isEmpty() ) 
                .or(postalAddressPersonalInfo.textProperty().isEmpty() ) 
                 .or(ResidentTownPersonalInfo.textProperty().isEmpty() )  
                  .or(residentCountyPersonalInfo.textProperty().isEmpty() ) 
                      
               
       );

    }
    @FXML
    private void changePasswordMenu(ActionEvent event){
    	Stage primaryStage= new Stage();
    	MainPassword pass = new MainPassword(primaryStage, userName, userType);
    	System.out.println("userName: "+userName+" userType: "+userType);
    	
    	
    }

	public static String getUserType() {
		return userType;
	}

	public static void setUserType(String userType) {
		FXMLDocumentController.userType = userType;
	}
	
	@FXML
	private void ExitMenu(ActionEvent event){
	}
	
	@FXML
    private void MoveToAdmin(ActionEvent event) {
		 try {
			   System.out.println("UserName : "+userName);
			   System.out.println("passworsd : "+password);
			   System.out.println("userType : "+userType);
			 if(AuthenticateAdmin(userName,password,userType)){
				 Zimele_AdminController.setUserName(userName);
          		Zimele_AdminController.setUserType("Admin");
          		Zimele_AdminController.setPass(password);
	            Parent  root;
	             root = FXMLLoader.load(getClass().getResource("/Zimele_Admin/Zimele_Admin.fxml"));
	            Scene scene = new Scene(root);
	             scene.getStylesheets().add(STYLESHEET_CASPIAN);
	             Stage stage =(Stage) myMenuBar.getScene().getWindow();
	          /* Stage stage =  (Stage)((Node)event.getSource()).getScene().getWindow();*/
	        stage.setScene(scene);
	        stage.show();
	        
	        
			 }else{
			       Alert alert2= new Alert(Alert.AlertType.INFORMATION);
			       alert2.setContentText("Access Denied .You cant access back office !");
			       alert2.showAndWait();
			       }
			
	        } catch (IOException ex) {
	            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
	        } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 
		
	}
   
	@FXML
    private void MoveToBackOffice(ActionEvent event) {
		   try {
			   System.out.println("UserName : "+userName);
			   System.out.println("passwors : "+password);
			   System.out.println("userType : "+userType);
			if(AuthenticateBackOffice(userName,password,userType)){
			 try {
				 Back_Office_ModuleController.setUserName(userName);
			     Back_Office_ModuleController.setUserType(userType);
			     Back_Office_ModuleController.setPass(password);
			        Parent  root;
			         root = FXMLLoader.load(getClass().getResource("/Zimele_Back_Office/Back_Office_Module.fxml"));
			        Scene scene = new Scene(root);
			         scene.getStylesheets().add(STYLESHEET_CASPIAN);
			         Stage stage =(Stage) myMenuBar.getScene().getWindow();
			      /* Stage stage =  (Stage)((Node)event.getSource()).getScene().getWindow();*/
			    stage.setScene(scene);
			    stage.show();
			    
			    
			    
			    } catch (IOException ex) {
			        Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
			    }
			   }else{
			       Alert alert2= new Alert(Alert.AlertType.INFORMATION);
			       alert2.setContentText("Access Denied .You cant access back office !");
			       alert2.showAndWait();
			       }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	 
	}
	
	
	
	static int count=1;
    public boolean AuthenticateBackOffice(String userName,String password1,String userType) throws SQLException{
        JaspytPasswordEncryptor encryptor= new JaspytPasswordEncryptor();
      
        conn=javaconnect.connectDb1();
        String sql1="select * FROM  `userdatatable` where `UserName`='";
        sql1=sql1.concat(userName);
        sql1=sql1.concat("'");
        
        statement = conn.prepareStatement(sql1);
         ResultSet rs=statement.executeQuery();
        count=1;
        while(rs.next()){
         
            String userName1=rs.getString("UserName");
            if(userName.equals(userName1)){
               
              break;
            }
        count++;
        }
        rs.absolute(count);
        password=rs.getString("password");
        String pass=encryptor.getDecryptedString(rs.getString("password"));
        String usertype=rs.getString("userType");
          
        return (pass.equals(encryptor.getDecryptedString(password1))&userType.equals("BackOffice"));
       
    
      
    }
    
    static int count1=1;
    public boolean AuthenticateAdmin(String userName,String password1,String userType) throws SQLException{
        JaspytPasswordEncryptor encryptor= new JaspytPasswordEncryptor();
      
        conn=javaconnect.connectDb1();
        String sql1="select * FROM  `userdatatable` where `UserName`='";
        sql1=sql1.concat(userName);
        sql1=sql1.concat("'");
        
        statement = conn.prepareStatement(sql1);
         ResultSet rs=statement.executeQuery();
        count1=1;
        while(rs.next()){
         
            String userName1=rs.getString("UserName");
            if(userName.equals(userName1)){
               
              break;
            }
        count++;
        }
        rs.absolute(count);
        password=rs.getString("password");
        String pass=encryptor.getDecryptedString(rs.getString("password"));
        String usertype=rs.getString("userType");
          
        return (pass.equals(encryptor.getDecryptedString(password1))&userType.equals("Admin"));
       
    
      
    }
    
    
	@FXML
    public void setDepositFormatMMD(KeyEvent event) {
		
		try{
    	Double currentPrice1=Double.parseDouble(depositAmountField.getText().replaceAll("[^0-9]", ""));

    	System.out.println(depositAmountField.getText().replaceAll("[^0-9]", ""));
    	 DecimalFormat f = new DecimalFormat("###,###,###");
         
         String number=f.format(currentPrice1);
         depositAmountField.setText(number);
         depositAmountField.end(); 
		}catch( Exception e){
			
			
		}
    }
	
	@FXML
	public void setDepositWithdrawalFormatMMWP(KeyEvent event){
		try{
	    	Double currentPrice1=Double.parseDouble(withdrawalAmountField.getText().replaceAll("[^0-9]", ""));

	    	System.out.println(withdrawalAmountField.getText().replaceAll("[^0-9]", ""));
	    	 DecimalFormat f = new DecimalFormat("###,###,###");
	         
	         String number=f.format(currentPrice1);
	         withdrawalAmountField.setText(number);
	         withdrawalAmountField.end(); 
			}catch( Exception e){
				
				
			}
		
	}
	
	
	@FXML
	public void setDepositWithdrawalFormatMMWI(KeyEvent event){
		
		try{
	    	Double currentPrice1=Double.parseDouble(withdrawFromInterestMoneyMarket.getText().replaceAll("[^0-9]", ""));

	    	System.out.println(withdrawFromInterestMoneyMarket.getText().replaceAll("[^0-9]", ""));
	    	 DecimalFormat f = new DecimalFormat("###,###,###");
	         
	         String number=f.format(currentPrice1);
	         withdrawFromInterestMoneyMarket.setText(number);
	         withdrawFromInterestMoneyMarket.end(); 
			}catch( Exception e){
				
				
			}
		
		
	}
	
	@FXML
	public void setPurchaseFormartBFP(KeyEvent event){
		
		
		try{
	    	Double currentPrice1=Double.parseDouble(purchaseAmountPurchasesField.getText().replaceAll("[^0-9]", ""));

	    	System.out.println(purchaseAmountPurchasesField.getText().replaceAll("[^0-9]", ""));
	    	 DecimalFormat f = new DecimalFormat("###,###,###");
	         
	         String number=f.format(currentPrice1);
	         purchaseAmountPurchasesField.setText(number);
	         purchaseAmountPurchasesField.end(); 
			}catch( Exception e){
				
				
			}
		
	}
	
	@FXML
	public void setWithdrawalFormartBFW(KeyEvent event){
		
		try{
	    	Double currentPrice1=Double.parseDouble(purchaseAmountWithdrawalField.getText().replaceAll("[^0-9]", ""));

	    	System.out.println(purchaseAmountWithdrawalField.getText().replaceAll("[^0-9]", ""));
	    	 DecimalFormat f = new DecimalFormat("###,###,###");
	         
	         String number=f.format(currentPrice1);
	         purchaseAmountWithdrawalField.setText(number);
	         purchaseAmountWithdrawalField.end(); 
			}catch( Exception e){
				
				
			}
		
		
	}
	
	@FXML
	public void setDepositFormartGPD(KeyEvent event){
		
		try{
	    	Double currentPrice1=Double.parseDouble(depositAmount_GaranteedPension.getText().replaceAll("[^0-9]", ""));

	    	System.out.println(depositAmount_GaranteedPension.getText().replaceAll("[^0-9]", ""));
	    	 DecimalFormat f = new DecimalFormat("###,###,###.##");
	         
	         String number=f.format(currentPrice1);
	         depositAmount_GaranteedPension.setText(number);
	         depositAmount_GaranteedPension.end(); 
			}catch( Exception e){
				
				
			}
		
	}
	
	
	@FXML
	public void setWithdrawalFormartGPI(KeyEvent event){
		
		try{
	    	Double currentPrice1=Double.parseDouble(withdrawFromInterestGaranteedpension.getText().replaceAll("[^0-9]", ""));

	    	System.out.println(withdrawFromInterestGaranteedpension.getText().replaceAll("[^0-9]", ""));
	    	 DecimalFormat f = new DecimalFormat("###,###,###");
	         
	         String number=f.format(currentPrice1);
	         withdrawFromInterestGaranteedpension.setText(number);
	         withdrawFromInterestGaranteedpension.end(); 
			}catch( Exception e){
				
				
			}
	}
	
	
	@FXML
	public void setWithdrawalFormartGPP(KeyEvent event){
		try{
	    	Double currentPrice1=Double.parseDouble(withdrawalAmount_GaranteedPensionwithdrawal.getText().replaceAll("[^0-9]", ""));

	    	System.out.println(withdrawalAmount_GaranteedPensionwithdrawal.getText().replaceAll("[^0-9]", ""));
	    	 DecimalFormat f = new DecimalFormat("###,###,###");
	         
	         String number=f.format(currentPrice1);
	         withdrawalAmount_GaranteedPensionwithdrawal.setText(number);
	         withdrawalAmount_GaranteedPensionwithdrawal.end(); 
			}catch( Exception e){
				
				
			}
		
	}
	
	@FXML
	public void setPurchaseFormartPPP(KeyEvent event){
		
		try{
	    	Double currentPrice1=Double.parseDouble(PurchaseAmount_PersonalPension.getText().replaceAll("[^0-9]", ""));

	    	System.out.println(PurchaseAmount_PersonalPension.getText().replaceAll("[^0-9]", ""));
	    	 DecimalFormat f = new DecimalFormat("###,###,###");
	         
	         String number=f.format(currentPrice1);
	         PurchaseAmount_PersonalPension.setText(number);
	         PurchaseAmount_PersonalPension.end(); 
			}catch( Exception e){
				
				
			}
		
	}
	
	
	@FXML
	public void setWithdrawalFormartPPW(KeyEvent event){
		try{
	    	Double currentPrice1=Double.parseDouble(withdrawAmountpersonalPension.getText().replaceAll("[^0-9]", ""));

	    	System.out.println(withdrawAmountpersonalPension.getText().replaceAll("[^0-9]", ""));
	    	 DecimalFormat f = new DecimalFormat("###,###,###");
	         
	         String number=f.format(currentPrice1);
	         withdrawAmountpersonalPension.setText(number);
	         withdrawAmountpersonalPension.end(); 
			}catch( Exception e){
				
				
			}
		
	}
	
public void runReportParamDate(InputStream path, InputStream path1){
        
        try{
       
        Map parameter= new HashMap();
             parameter.put("memberNumber", memberNumberReport.getText());
             parameter.put("toDate",toDate.getValue().toString());
             
             JasperDesign jd = JRXmlLoader.load(path);
	            JasperReport jr = JasperCompileManager.compileReport(jd);

	            JasperPrint jp = JasperFillManager.fillReport(jr, parameter, conn);
             
            /*JasperDesign jd = JRXmlLoader.load(path);
              JRDesignQuery newQuery = new JRDesignQuery();
            newQuery.setText(sql);
            jd.setQuery(newQuery);
            JasperReport jr = JasperCompileManager.compileReport(jd);

            JasperPrint jp = JasperFillManager.fillReport(jr, null, conn);*/
            
            
            if(jp.getPages().isEmpty()){
                
            System.out.println("Empty report ....");
            System.out.println("Building new  report ....");
             JasperDesign jd1 = JRXmlLoader.load(path1);
              
            JasperReport jr1 = JasperCompileManager.compileReport(jd1);
            
            JasperPrint jp1 = JasperFillManager.fillReport(jr1, parameter, conn);
            JasperViewer.viewReport(jp1, false);
            }else{
             JasperViewer.viewReport(jp, false);
            
            }
           
           
//            JRViewerFx view = new JRViewerFx(jp, JRViewerFxMode.REPORT_VIEW, newStage);
//            view.start(newStage);
            


        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText(e.toString());
            alert.showAndWait();
            System.out.println(e.toString());

        }
    
    
    }
	 public void runReportStatementByDate(InputStream path){
		 conn=JavaFirebirdconnect.connectDb();
	    
	        try{
	        
	           LocalDate fromdate=fromDate.getValue();
               LocalDate todate=toDate.getValue();
	            Date date = java.sql.Date.valueOf(fromdate);
	            Date date1 = java.sql.Date.valueOf(todate);
	            Map parameter= new HashMap();
	             parameter.put("memberNumber", memberNumberReport.getText());
	            
	             parameter.put("toDate",toDate.getValue().toString());
	           
	            JasperDesign jd = JRXmlLoader.load(path);
	            JasperReport jr = JasperCompileManager.compileReport(jd);

	            JasperPrint jp = JasperFillManager.fillReport(jr, parameter, conn);
	            
      /*JasperViewer.viewReport(jp, false);*/
            Stage newStage = new Stage();
	            JRViewerFx view = new JRViewerFx(jp, JRViewerFxMode.REPORT_VIEW, newStage);
	            view.start(newStage);
	          
	            


	        } catch (Exception e) {
	            Alert alert = new Alert(Alert.AlertType.INFORMATION);
	            alert.setContentText(e.toString());
	            alert.showAndWait();
	        System.out.println(e.toString());  
	        }
	    
	    
	    }
	 
	 public void runReportStatementByDateP(InputStream path){
		 conn=JavaFirebirdconnect.connectDb1();
	    
	        try{
	        
	           LocalDate fromdate=fromDate.getValue();
               LocalDate todate=toDate.getValue();
	            Date date = java.sql.Date.valueOf(fromdate);
	            Date date1 = java.sql.Date.valueOf(todate);
	            Map parameter= new HashMap();
	             parameter.put("memberNumber", memberNumberReport.getText());
	            
	             parameter.put("toDate",toDate.getValue().toString());
	           
	            JasperDesign jd = JRXmlLoader.load(path);
	            JasperReport jr = JasperCompileManager.compileReport(jd);

	            JasperPrint jp = JasperFillManager.fillReport(jr, parameter, conn);
	            
      /*JasperViewer.viewReport(jp, false);*/
            Stage newStage = new Stage();
	            JRViewerFx view = new JRViewerFx(jp, JRViewerFxMode.REPORT_VIEW, newStage);
	            view.start(newStage);
	          
	            


	        } catch (Exception e) {
	            Alert alert = new Alert(Alert.AlertType.INFORMATION);
	            alert.setContentText(e.toString());
	            alert.showAndWait();
	        System.out.println(e.toString());  
	        }
	    
	    
	    }
	 
	 @FXML
	 public void addExistingMember(ActionEvent event){
		 
		 conn=javaconnect.connectDb();
		
		 
		 
        
       
	try {
		
		
		
		 String sql ="select * from ";
         sql=sql.concat("`");
         sql=sql.concat("moneymarketaccounts");
         sql=sql.concat("`");
         sql=sql.concat("where `MemberNumber` ='");
         sql=sql.concat(memberNumberInvestmentApplication.getText());
         sql=sql.concat("'"); 
		
         PreparedStatement statement1 = conn.prepareStatement(sql);
 		ResultSet result1=statement1.executeQuery();
 		
 		if (!result1.isBeforeFirst()) {
 			
 			String newMember="insert into";
 			newMember=newMember.concat("`");
 			newMember=newMember.concat("moneymarketaccounts");
 			newMember=newMember.concat("` (MemberNumber,FullName) values(?,?) ");
 			PreparedStatement statement2 = conn.prepareStatement(newMember);
 			statement2.setString(1, memberNumberInvestmentApplication.getText());
 			statement2.setString(2, fullNameInvestmentApplication.getText());
 			statement2.executeUpdate();
 		}
		
		
		 String sqlPI= "insert into personalinformation(memberNumber,fullName ) values(?,?)";
         PreparedStatement statement3 = conn.prepareStatement(sqlPI);
		    statement3.setString(1, memberNumberInvestmentApplication.getText());
			statement3.setString(2, fullNameInvestmentApplication.getText());
			statement3.executeUpdate();
			
			Alert alert = new Alert(Alert.AlertType.INFORMATION);
	        alert.setContentText("Member Added Successfull");
	        alert.showAndWait();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setContentText(e.toString());
        alert.showAndWait();
	}
      
        
		 
		 
		 
	 }
	 
	 @FXML
	 public void setSignature(ActionEvent event) throws MalformedURLException, FileNotFoundException{
		 
		 
		  Stage stage =  (Stage)((Node)event.getSource()).getScene().getWindow();
	        
	         fileChooser1= new FileChooser();
	         fileChooser1.getExtensionFilters().addAll(new ExtensionFilter("Text Files","*txt"),
	                                                  new ExtensionFilter("Image Files","*.png","*.jpg","*.gif"),      
	                                                  new ExtensionFilter("Audio Files","*.wav","*.mp3","*.aac"),
	                                                  new ExtensionFilter("All Files","*.*")
	         );
	        file1=fileChooser1.showOpenDialog(stage);
	        if(file1!=null){
	        System.out.println("file not null"+file1.getAbsolutePath());
	        image4= new Image(file1.toURI().toURL().toString(),600,600,true,true);
	        System.out.println("Image not null"+file1.toURI().toURL().toString());
	        
	        imageViewer1.setImage(image4);
	        imageViewer1.setVisible(true);
	        
	        FileInputStream  fs1= new FileInputStream(file1);
	        image2= new FileInputStream(file1);
	        logic.setFile(file1);
	       logic.setImage(fs1);
	        
	        
	        }
		 
		 
	 }
	 
}

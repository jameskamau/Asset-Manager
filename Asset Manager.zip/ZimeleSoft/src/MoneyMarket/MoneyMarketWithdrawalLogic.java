/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package MoneyMarket;

import DataBaseConnector.javaconnect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author james kamau
 */
public class MoneyMarketWithdrawalLogic {
    
    Connection connect;
    PreparedStatement statement;
    ResultSet result;
    
    private String memberNumber;
    private double WithdrwalInterest;
    private double WithdrwalPrincipal;
    
    private String FullName;

    /**
     * @return the memberNumber
     */
    public String getMemberNumber() {
        return memberNumber;
    }

    /**
     * @param memberNumber the memberNumber to set
     */
    public void setMemberNumber(String memberNumber) {
        this.memberNumber = memberNumber;
    }

   
    

    /**
     * @return the FullName
     */
    public String getFullName() {
        return FullName;
    }

    /**
     * @param FullName the FullName to set
     */
    public void setFullName(String FullName) {
        this.FullName = FullName;
    }

    /**
     * @return the WithdrwalInterest
     */
    public double getWithdrwalInterest() {
        return WithdrwalInterest;
    }

    /**
     * @param WithdrwalInterest the WithdrwalInterest to set
     */
    public void setWithdrwalInterest(double WithdrwalInterest) {
        this.WithdrwalInterest = WithdrwalInterest;
    }

    /**
     * @return the WithdrwalPrincipal
     */
    public double getWithdrwalPrincipal() {
        return WithdrwalPrincipal;
    }

    /**
     * @param WithdrwalPrincipal the WithdrwalPrincipal to set
     */
    public void setWithdrwalPrincipal(double WithdrwalPrincipal) {
        this.WithdrwalPrincipal = WithdrwalPrincipal;
    }
    static int count=1;
    public  void updateDatabaseValue() throws SQLException{
       connect=javaconnect.connectDb();
        String sql1="select * FROM `moneymarketaccounts` ";
       
        statement = connect.prepareStatement(sql1);
        
        ResultSet rs1 = statement.executeQuery(); 
        count=1;
        while(rs1.next()){
         
            String membernumber=rs1.getString("MemberNumber");
            System.out.println("local variable"+membernumber);
             System.out.println("from field"+memberNumber);
            
            if(Integer.parseInt(membernumber)==Integer.parseInt(memberNumber)){
               System.out.println("this is the selected number"+membernumber);
              break;
            }
        count++;
        }
        
       
        System.out.println("row from moneyMarketAccount "+count);
        System.out.println(sql1);
        
        
        
        String sql2 ="select * from   moneymarketaccounts";
        statement = connect.prepareStatement(sql2,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
        ResultSet rs = statement.executeQuery();
        rs.absolute(count);
       
        double balance=rs.getDouble("AccountBalance");
        double finalBalance=balance-WithdrwalPrincipal;
      
        double Interest=rs.getDouble("Interest");
        double finalInterestBalance=Interest-WithdrwalInterest;
        rs.updateDouble("AccountBalance",finalBalance);
        rs.updateDouble("Interest", finalInterestBalance);
       
        rs.updateRow();
        
    
    
    
    }
    
    
}

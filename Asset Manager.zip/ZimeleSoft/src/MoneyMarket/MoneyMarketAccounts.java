/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package MoneyMarket;

import DataBaseConnector.javaconnect;
import java.sql.Connection;

/**
 *
 * @author james kamau
 */
public class MoneyMarketAccounts {
     Connection connection;
    private String fullName;
    private String memberNumber;

    /**
     * @return the fullName
     */
    public String getFullName() {
        return fullName;
    }

    /**
     * @param fullName the fullName to set
     */
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    /**
     * @return the memberNumber
     */
    public String getMemberNumber() {
        return memberNumber;
    }

    /**
     * @param memberNumber the memberNumber to set
     */
    public void setMemberNumber(String memberNumber) {
        this.memberNumber = memberNumber;
    }
    
     public void saveMoneyMarketAccount(){
        connection = javaconnect.connectDb();
        javaconnect connect = new javaconnect();
        String sql="INSERT INTO   moneymarketaccounts (MemberNumber,FullName) VALUES(";    
        sql = sql.concat(memberNumber);
        sql= sql.concat(",");
        sql=sql.concat("'");
        sql= sql.concat(fullName);
        sql=sql.concat("'");
        sql=sql.concat(")");
        
        connect.executeSqlStatement(sql, connection);
    
    }
   
}


package MoneyMarket;

import DateConverter.LocalDatePersistenceConverter;
import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author james kamau
 */
@Entity
public class MoneyMarketWithdrawal implements Serializable {
    
    
       @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="ID")
    private int id;
    
    private String MemberNumber;
    
    private String FullName;
    
    private String withdrawalAmount;
    
    private String WithdrawalFromInterest;
    
   @Convert(converter = LocalDatePersistenceConverter.class)
    private LocalDate DateOfWithdrawal;
    
   private String modeOfPayment;
   
   private String SavedByUser;
   private String transactionNumber;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the MemberNumber
     */
    public String getMemberNumber() {
        return MemberNumber;
    }

    /**
     * @param MemberNumber the MemberNumber to set
     */
    public void setMemberNumber(String MemberNumber) {
        this.MemberNumber = MemberNumber;
    }

    /**
     * @return the FullName
     */
    public String getFullName() {
        return FullName;
    }

    /**
     * @param FullName the FullName to set
     */
    public void setFullName(String FullName) {
        this.FullName = FullName;
    }

    /**
     * @return the withdrawalAmount
     */
    public String getWithdrawalAmount() {
        return withdrawalAmount;
    }

    /**
     * @param withdrawalAmount the withdrawalAmount to set
     */
    public void setWithdrawalAmount(String withdrawalAmount) {
        this.withdrawalAmount = withdrawalAmount;
    }

    /**
     * @return the DateOfWithdrawal
     */
    public LocalDate getDateOfWithdrawal() {
        return DateOfWithdrawal;
    }

    /**
     * @param DateOfWithdrawal the DateOfWithdrawal to set
     */
    public void setDateOfWithdrawal(LocalDate DateOfWithdrawal) {
        this.DateOfWithdrawal = DateOfWithdrawal;
    }

    /**
     * @return the modeOfPayment
     */
    public String getModeOfPayment() {
        return modeOfPayment;
    }

    /**
     * @param modeOfPayment the modeOfPayment to set
     */
    public void setModeOfPayment(String modeOfPayment) {
        this.modeOfPayment = modeOfPayment;
    }

    /**
     * @return the WithdrawalFromInterest
     */
    public String getWithdrawalFromInterest() {
        return WithdrawalFromInterest;
    }

    /**
     * @param WithdrawalFromInterest the WithdrawalFromInterest to set
     */
    public void setWithdrawalFromInterest(String WithdrawalFromInterest) {
        this.WithdrawalFromInterest = WithdrawalFromInterest;
    }

    /**
     * @return the SavedByUser
     */
    public String getSetByUser() {
        return SavedByUser;
    }

    /**
     * @param SetByUser the SavedByUser to set
     */
    public void setSetByUser(String SetByUser) {
        this.SavedByUser = SetByUser;
    }

    /**
     * @return the transactionNumber
     */
    public String getTransactionNumber() {
        return transactionNumber;
    }

    /**
     * @param transactionNumber the transactionNumber to set
     */
    public void setTransactionNumber(String transactionNumber) {
        this.transactionNumber = transactionNumber;
    }

    
   
   
    
}

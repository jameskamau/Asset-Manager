

package EmailNotify;

/**
 *
 * @author james kamau
 */

import  java.util.Properties;
import javafx.scene.control.Alert;
import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class SendMail {

    
    
    public void sendMail(String Email, String password,String recipientMail,String exportPath,String fileName){
        
       
    
        Properties props= new Properties();
        props.put("mail.smtp.host", "smtp.pepea.co.ke");
        props.put("mail.smtp.socketFactory.port", "2525");
        props.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.port", "2525");
        
        
        Session session=Session.getDefaultInstance(props,new javax.mail.Authenticator() {
     
                    protected PasswordAuthentication getPasswordAuthentication(){
                            return new PasswordAuthentication(Email,password);
                     }
              });
              
        try{
            
            Message message= new  MimeMessage(session);
            message.setFrom(new InternetAddress(Email));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientMail));
            message.setSubject("This is a Zimele Mail");
            
            MimeBodyPart messageBodyPart= new MimeBodyPart();
            messageBodyPart.setText("this is a Zimele Email Statement");
            Multipart multipart= new MimeMultipart();
            multipart.addBodyPart(messageBodyPart);
            
            messageBodyPart= new MimeBodyPart();
            javax.activation.DataSource source= new FileDataSource(exportPath);
            messageBodyPart.setDataHandler(new DataHandler(source));
            messageBodyPart.setFileName(fileName);
            multipart.addBodyPart(messageBodyPart);
            message.setContent(multipart);
            
            
            //message.setText("The Attachment below is client statement"); 
            Transport.send(message);
            
            
             Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Mail sent Succesful");
            alert.showAndWait();
            
        }catch(Exception e){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText(e.toString());
            alert.showAndWait();
        
        }
    
    }
    
    public void sendMail(String Email, String password,String recipientMail){
        
       
    
        Properties props= new Properties();
        props.put("mail.smtp.host", "smtp.pepea.co.ke");
        props.put("mail.smtp.socketFactory.port", "2525");
        props.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.port", "2525");
        
        
        Session session=Session.getDefaultInstance(props,new javax.mail.Authenticator() {
     
                    protected PasswordAuthentication getPasswordAuthentication(){
                            return new PasswordAuthentication(Email,password);
                     }
              });
              
        try{
            
            Message message= new  MimeMessage(session);
            message.setFrom(new InternetAddress(Email));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientMail));
            message.setSubject("This is a Zimele Mail");
            
            message.setText("The Attachment below is client statement"); 
            Transport.send(message);
            
            
             Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Mail sent Succesful");
            alert.showAndWait();
            
        }catch(Exception e){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText(e.toString());
            alert.showAndWait();
        
        }
    
    }
}

package comppanyinfo;

import javafx.fxml.FXML;

public class CompanyInformationController {

}

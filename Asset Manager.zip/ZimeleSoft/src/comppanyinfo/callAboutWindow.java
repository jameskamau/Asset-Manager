package comppanyinfo;

import java.io.InputStream;

import ChequeWindow.ChequeWindowController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class callAboutWindow extends Application {

	@Override
	public void start(Stage primaryStage) throws Exception {
	      InputStream fxmlStream = null;
			try {
				fxmlStream = getClass().getResourceAsStream("CompanyInformation.fxml");
				FXMLLoader loader = new FXMLLoader();
				Parent page = (Parent) loader.load(fxmlStream);
	      Scene scene = new Scene(page);
	            primaryStage.setScene(scene);
	            primaryStage.setTitle("About Asset Manager");
	            primaryStage.show();
	         /* Object o = loader.getController();
	            if(o instanceof ChequeWindowController){

	            	CompanyInformationController window = (CompanyInformationController)o;
	                
	            }*/
	            
	        } catch (Exception ex) {
	          ex.printStackTrace();
	        }
	        
		
	}
	
	 public callAboutWindow( Stage primaryStage ){
		
			try {
				start(primaryStage);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

}

package changePassword;
import java.io.InputStream;


import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
public class MainPassword extends Application {
	private String userName1;
    private String userType;
	
    public MainPassword( Stage mainStage,String userName,String userType ){
    	this.userName1=userName;
		this.userType=userType;
	try {
		start(mainStage);
	} catch (Exception e) {
		e.printStackTrace();
	}
	}


	@Override
	public void start(Stage primaryStage) throws Exception {
		   InputStream fxmlStream = null;
			try {
				changePasswordController.setUserName1(userName1);
            	changePasswordController.setUserType(userType);
				fxmlStream = getClass().getResourceAsStream("changePassword.fxml");
				FXMLLoader loader = new FXMLLoader();
				Parent page = (Parent) loader.load(fxmlStream);
	      Scene scene = new Scene(page);
	            primaryStage.setScene(scene);
	            primaryStage.setTitle("Change Password");
	            primaryStage.show();
	          Object o = loader.getController();
	          
	            if(o instanceof changePasswordController){
	            	
	            	changePasswordController window = (changePasswordController)o;
	            	
	            	
	            	System.out.println("MAIN PASSWORD CLASS userName: "+userName1+" userType: "+userType);
	            	
	            }
	            
	        } catch (Exception ex) {
	          ex.printStackTrace();
	        }
	        
		
	}

}

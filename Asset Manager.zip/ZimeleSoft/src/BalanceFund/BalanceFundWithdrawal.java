


package BalanceFund;

import DateConverter.LocalDatePersistenceConverter;
import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author james kamau
 */
@Entity
public class BalanceFundWithdrawal implements Serializable {
    
    
     
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="ID")
    private int id;
    private String memberNumber;
    private String FullName;
    private String withdrawalAmount;
    private String unitsSold;
    @Convert(converter = LocalDatePersistenceConverter.class)
    private LocalDate DateOfWithdrawal;
    private String ModeOfPaymment;
    private String sellPrice;
    private String SavedByUser;
    private String TRANS_NO;
    
    
    
    public String getTRANS_NO() {
		return TRANS_NO;
	}

	public void setTRANS_NO(String tRANS_NO) {
		TRANS_NO = tRANS_NO;
	}

	/**
     * @return the memberNumber
     */
    public String getMemberNumber() {
        return memberNumber;
    }

    /**
     * @param memberNumber the memberNumber to set
     */
    public void setMemberNumber(String memberNumber) {
        this.memberNumber = memberNumber;
    }

    /**
     * @return the FullName
     */
    public String getFullName() {
        return FullName;
    }

    /**
     * @param FullName the FullName to set
     */
    public void setFullName(String FullName) {
        this.FullName = FullName;
    }

    /**
     * @return the withdrawalAmount
     */
    public String getWithdrawalAmount() {
        return withdrawalAmount;
    }

    /**
     * @param withdrawalAmount the withdrawalAmount to set
     */
    public void setWithdrawalAmount(String withdrawalAmount) {
        this.withdrawalAmount = withdrawalAmount;
    }

    /**
     * @return the unitsSold
     */
    public String getUnitsSold() {
        return unitsSold;
    }

    /**
     * @param unitsSold the unitsSold to set
     */
    public void setUnitsSold(String unitsSold) {
        this.unitsSold = unitsSold;
    }

    /**
     * @return the DateOfWithdrawal
     */
    public LocalDate getDateOfWithdrawal() {
        return DateOfWithdrawal;
    }

    /**
     * @param DateOfWithdrawal the DateOfWithdrawal to set
     */
    public void setDateOfWithdrawal(LocalDate DateOfWithdrawal) {
        this.DateOfWithdrawal = DateOfWithdrawal;
    }

    /**
     * @return the ModeOfPaymment
     */
    public String getModeOfPaymment() {
        return ModeOfPaymment;
    }

    /**
     * @param ModeOfPaymment the ModeOfPaymment to set
     */
    public void setModeOfPaymment(String ModeOfPaymment) {
        this.ModeOfPaymment = ModeOfPaymment;
    }

    /**
     * @return the sellPrice
     */
    public String getSellPrice() {
        return sellPrice;
    }

    /**
     * @param sellPrice the sellPrice to set
     */
    public void setSellPrice(String sellPrice) {
        this.sellPrice = sellPrice;
    }

   
    /**
     * @return the SavedByUser
     */
    public String getSetByUser() {
        return SavedByUser;
    }

    /**
     * @param setByUser the SavedByUser to set
     */
    public void setSetByUser(String setByUser) {
        this.SavedByUser = setByUser;
    }

    
    
}

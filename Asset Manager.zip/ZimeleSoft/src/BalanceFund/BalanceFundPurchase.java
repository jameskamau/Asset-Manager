

package BalanceFund;

import DateConverter.LocalDatePersistenceConverter;
import java.io.Serializable;
import java.util.Date;
import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author james kamau
 */
@Entity
public class BalanceFundPurchase implements Serializable {
    
     
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="ID")
    private int id;
    private String memberNumber;
    private String FullName;
    private String purchaseAmount;
    private String unitsPurchased;
    @Convert(converter = LocalDatePersistenceConverter.class)
    private LocalDate DateOfPurchase;
    private String ModeOfPaymment;
    private String purchasePrice;
    private String PurchaseNumberBalanceFundPurchase;
    private String SavedByUser;
    

    /**
     * @return the memberNumber
     */
    public String getMemberNumber() {
        return memberNumber;
    }

    /**
     * @param memberNumber the memberNumber to set
     */
    public void setMemberNumber(String memberNumber) {
        this.memberNumber = memberNumber;
    }

    /**
     * @return the FullName
     */
    public String getFullName() {
        return FullName;
    }

    /**
     * @param FullName the FullName to set
     */
    public void setFullName(String FullName) {
        this.FullName = FullName;
    }

    /**
     * @return the purchaseAmount
     */
    public String getPurchaseAmount() {
        return purchaseAmount;
    }

    /**
     * @param purchaseAmount the purchaseAmount to set
     */
    public void setPurchaseAmount(String purchaseAmount) {
        this.purchaseAmount = purchaseAmount;
    }

    /**
     * @return the unitsPurchased
     */
    public String getUnitsPurchased() {
        return unitsPurchased;
    }

    /**
     * @param unitsPurchased the unitsPurchased to set
     */
    public void setUnitsPurchased(String unitsPurchased) {
        this.unitsPurchased = unitsPurchased;
    }

    /**
     * @return the DateOfPurchase
     */
    public LocalDate getDateOfPurchase() {
        return DateOfPurchase;
    }

    /**
     * @param DateOfPurchase the DateOfPurchase to set
     */
    public void setDateOfPurchase(LocalDate DateOfPurchase) {
        this.DateOfPurchase = DateOfPurchase;
    }

    /**
     * @return the ModeOfPaymment
     */
    public String getModeOfPaymment() {
        return ModeOfPaymment;
    }

    /**
     * @param ModeOfPaymment the ModeOfPaymment to set
     */
    public void setModeOfPaymment(String ModeOfPaymment) {
        this.ModeOfPaymment = ModeOfPaymment;
    }

    /**
     * @return the purchasePrice
     */
    public String getPurchasePrice() {
        return purchasePrice;
    }

    /**
     * @param purchasePrice the purchasePrice to set
     */
    public void setPurchasePrice(String purchasePrice) {
        this.purchasePrice = purchasePrice;
    }

    /**
     * @return the PurchaseNumberBalanceFundPurchase
     */
    public String getPurchaseNumberBalanceFundPurchase() {
        return PurchaseNumberBalanceFundPurchase;
    }

    /**
     * @param PurchaseNumberBalanceFundPurchase the PurchaseNumberBalanceFundPurchase to set
     */
    public void setPurchaseNumberBalanceFundPurchase(String PurchaseNumberBalanceFundPurchase) {
        this.PurchaseNumberBalanceFundPurchase = PurchaseNumberBalanceFundPurchase;
    }

    /**
     * @return the SavedByUser
     */
    public String getUserName() {
        return SavedByUser;
    }

    /**
     * @param userName the SavedByUser to set
     */
    public void setUserName(String userName) {
        this.SavedByUser = userName;
    }
    
    
}

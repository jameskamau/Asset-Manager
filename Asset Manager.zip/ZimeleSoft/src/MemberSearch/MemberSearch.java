package MemberSearch;


/**
 *
 * @author james kamau
 */
public class MemberSearch {
    
    private String fullNameSearchField;

    /**
     * @return the fullNameSearchField
     */
    public String getFullNameSearchField() {
        return fullNameSearchField;
    }

    /**
     * @param fullNameSearchField the fullNameSearchField to set
     */
    public void setFullNameSearchField(String fullNameSearchField) {
        this.fullNameSearchField = fullNameSearchField;
    }
    
}

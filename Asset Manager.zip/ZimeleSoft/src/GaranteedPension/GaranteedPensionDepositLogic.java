/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package GaranteedPension;

import DataBaseConnector.javaconnect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author james kamau
 */
public class GaranteedPensionDepositLogic {
    Connection connect;
    PreparedStatement statement;
    ResultSet result;
    
    private String memberNumber;
    private double deposit;
    private String FullName;

    /**
     * @return the memberNumber
     */
    public String getMemberNumber() {
        return memberNumber;
    }

    /**
     * @param memberNumber the memberNumber to set
     */
    public void setMemberNumber(String memberNumber) {
        this.memberNumber = memberNumber;
    }

    /**
     * @return the deposit
     */
    public double getDeposit() {
        return deposit;
    }

    /**
     * @param deposit the deposit to set
     */
    public void setDeposit(double deposit) {
        this.deposit = deposit;
    }

    /**
     * @return the FullName
     */
    public String getFullName() {
        return FullName;
    }

    /**
     * @param FullName the FullName to set
     */
    public void setFullName(String FullName) {
        this.FullName = FullName;
    }
    
     static int count=1;
    public void updateDatabaseValue() throws SQLException{
       connect=javaconnect.connectDb();
        String sql1="select * FROM `garanteedpensionaccounts`";
        
        statement = connect.prepareStatement(sql1);
        ResultSet rs1 = statement.executeQuery();
        
       count=1;
        while(rs1.next()){
         
            String membernumber=rs1.getString("MemberNumber");
            if(Integer.parseInt(membernumber)==Integer.parseInt(memberNumber)){
               
              break;
            }
        count++;
        }
       
        System.out.println(count);
        System.out.println(memberNumber);
        System.out.println(sql1);
        
        
        String sql2 ="select * from   garanteedpensionaccounts";
        statement = connect.prepareStatement(sql2,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
        ResultSet rs = statement.executeQuery();
        rs.absolute(count);
       
       double balance=rs.getDouble("AccountBalance");
       double finalBalance=balance+deposit;
      
        rs.updateDouble("AccountBalance",finalBalance);
       
        rs.updateRow();
        
    
    
    
    }
    
}

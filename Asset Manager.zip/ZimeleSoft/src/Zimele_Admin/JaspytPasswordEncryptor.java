
package Zimele_Admin;

/**
 *
 * @author james kamau
 */
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
public class JaspytPasswordEncryptor {
   String jaspytAlgorithm = "PBEWithMD5AndDES";
   String jaspytEncryptionKey = "javahonk_key";
    public  String getEncryptedString(String passwordToEncrypt){
		StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
		encryptor.setPassword(jaspytEncryptionKey);                     
		encryptor.setAlgorithm(jaspytAlgorithm);
		String encryptText = encryptor.encrypt(passwordToEncrypt);
		return encryptText;
	}
	
	public  String getDecryptedString(String passwordToDecrypt){
		
		StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
		encryptor.setPassword(jaspytEncryptionKey);                     
		encryptor.setAlgorithm(jaspytAlgorithm);
		String decryptText = encryptor.decrypt(passwordToDecrypt);
		return decryptText;
	}
}

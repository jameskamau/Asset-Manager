/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Zimele_Admin;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author james kamau
 */
@Entity
public class DeletedUsersTable implements Serializable {
    
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="ID")
    private int id;
    
    private String deletedUserName;
    private String deletedPassword;

    /**
     * @return the deletedUserName
     */
    public String getDeletedUserName() {
        return deletedUserName;
    }

    /**
     * @param deletedUserName the deletedUserName to set
     */
    public void setDeletedUserName(String deletedUserName) {
        this.deletedUserName = deletedUserName;
    }

    /**
     * @return the deletedPassword
     */
    public String getDeletedPassword() {
        return deletedPassword;
    }

    /**
     * @param deletedPassword the deletedPassword to set
     */
    public void setDeletedPassword(String deletedPassword) {
        this.deletedPassword = deletedPassword;
    }
    
   
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Zimele_Admin;

import DataBaseConnector.javaconnect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author james kamau
 */
public class DeleteUser {
    Connection connect;
    PreparedStatement statement;
    ResultSet result;
    
     public void deleteUserData(String userName) throws SQLException{
        connect=javaconnect.connectDb();
        String sql1="delete FROM  `userdatatable` where `UserName`='";
        sql1=sql1.concat(userName);
        sql1=sql1.concat("'");
        
        statement = connect.prepareStatement(sql1);
         statement.execute();
    
    
    }
}

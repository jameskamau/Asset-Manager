/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Zimele_Admin;

import DataBaseConnector.HibernateConnector;
import DataBaseConnector.javaconnect;
import EmailNotify.SendMail;
import EmailReports.SendStatementMail;
import SMSNotify.SendMonthlySmS;
import SMSNotify.SendSms;
import TableDisplays.EditableCell;
import TableDisplays.ResultsetTableDisplay;
import Zimele_Back_Office.Back_Office_ModuleController;
import Zimele_main.Zimele_LogInController;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.ProtocolException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import static javafx.application.Application.STYLESHEET_CASPIAN;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.MenuBar;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import net.sf.jasperreports.engine.JRException;
import org.controlsfx.control.textfield.AutoCompletionBinding;
import org.controlsfx.control.textfield.TextFields;
import zimele_information_management_system.FXMLDocumentController;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * FXML Controller class
 *
 * @author james kamau
 */
public class Zimele_AdminController implements Initializable {

	@FXML
	private Button sendSMS;
	@FXML
	private CheckBox SetBalancesTrue;

	/**
	 * @return the MemberNumber
	 */
	public String getMemberNumber() {
		return MemberNumber;
	}

	/**
	 * @param MemberNumber
	 *            the MemberNumber to set
	 */
	public void setMemberNumber(String MemberNumber) {
		this.MemberNumber = MemberNumber;
	}

	@FXML
	private Button createUserBtn;
	@FXML
	private TextField lastName;
	@FXML
	private TextField firstName;
	@FXML
	private TextField userName;
	@FXML
	private PasswordField password;
	@FXML
	private TextField DeleteUserName;
	@FXML
	private TextField DeletePassword;
	@FXML
	private Button DeleteUser;
	@FXML
	private TableView<ObservableList> UserTableView;
	@FXML
	private ChoiceBox<String> UserTypeChoice;
	@FXML
	private MenuBar myMenuBar = new MenuBar();
	PreparedStatement statement;
	ResultSet result;
	Connection conn;
	@FXML
	private TableView<ObservableList> AdminMainTableView;
	@FXML
	private ComboBox<String> ChooseTable;
	@FXML
	private CheckBox EditTable;
	@FXML
	private Button sendMails;

	ObservableList<String> possibleNames = FXCollections.observableArrayList();
	ObservableList<String> possibleMemberNumbers = FXCollections.observableArrayList();
	@FXML
	private TextField memberNumber;
	@FXML
	private Button ReInvestClient;
	@FXML
	private CheckBox ReInvest;

	private String MemberNumber;

	private static String UserName;
	private static String userType;

	public static String getUserName() {
		return UserName;
	}

	public static void setUserName(String userName) {
		UserName = userName;
	}

	public static String getUserType() {
		return userType;
	}

	public static void setUserType(String userType) {
		Zimele_AdminController.userType = userType;
	}

	public static String getPass() {
		return pass;
	}

	public static void setPass(String pass) {
		Zimele_AdminController.pass = pass;
	}

	private static String pass;

	/**
	 * Initializes the controller class.
	 */
	@Override
	public void initialize(URL url, ResourceBundle rb) {
		sendMails.setDisable(true);
		sendSMS.setDisable(true);
		conn = javaconnect.connectDb1();
		String sql = "select fullName,memberNumber from personalinformation ";
		PreparedStatement statement2;
		try {
			statement2 = conn.prepareStatement(sql);
			ResultSet result2 = statement2.executeQuery();
			while (result2.next()) {
				possibleNames.add(result2.getString("fullName"));
				possibleMemberNumbers.add(result2.getString("memberNumber") + " " + result2.getString("fullName"));
			}
		} catch (SQLException ex) {
			Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
		}

		AutoCompletionBinding<String> acb0 = TextFields.bindAutoCompletion(memberNumber, possibleMemberNumbers);
		acb0.setOnAutoCompleted(e -> memberNumber.setText(checkForNumbers(e.getCompletion())));

		ChooseTable.getItems().addAll("balancefundwithdrawal", "moneymarketdeposit", "moneymarketwithdrawal",
				"fundtransfer", "investmentapplication", "garanteedpensiondeposit", "garanteedpensionwithdrawals",
				"homeownershipdeposit", "homeownershipwithdrawal", "nextofkininformation", "personalinformation",
				"personalpensiondeposit", "balancefundpurchase", "personalpensionwithdrawal", "balacefundaccounts",
				"balancefundwithdrawalaccouts", "garanteedpensionaccounts", "homeownershipaccounts",
				"moneymarketaccounts", "personalpensionpurchase", "personalinformation");
		ChooseTable.setValue("personalinformation");

		UserTypeChoice.getItems().addAll("Admin", "BackOffice", "FrontOffice", "Temporary");
		UserTypeChoice.setValue("FrontOffice");
		ReInvestClient.setDisable(true);
		// TODO
	}

	public void fetchUserLoginData(UserDataTable user) {

		user.setFirstName(firstName.getText());
		user.setLastName(lastName.getText());
		user.setUserType(UserTypeChoice.getValue());
		user.setUserName(userName.getText());
		user.setPassword(password.getText());

	}

	public void fetchDeletedUserData(DeletedUsersTable user) {

		user.setDeletedUserName(DeleteUserName.getText());
		user.setDeletedPassword(DeletePassword.getText());
		try {
			DeleteUser delete = new DeleteUser();
			delete.deleteUserData(DeleteUserName.getText());
		} catch (SQLException ex) {
			Logger.getLogger(Zimele_AdminController.class.getName()).log(Level.SEVERE, null, ex);
		}

	}

	@FXML
	private void createUser(ActionEvent event) {
		// UserDataTable user = new UserDataTable();
		// fetchUserLoginData(user);
		// HibernateConnector connector= new HibernateConnector();
		// connector.MakeHibernateTransaction1(user);
		try {
			createUserLogin();
			Alert alert2 = new Alert(Alert.AlertType.INFORMATION);
			alert2.setContentText("User Created Successfully");
			alert2.showAndWait();
		} catch (Exception e) {
		}

	}

	@FXML
	private void deleteUser(ActionEvent event) {
		DeletedUsersTable user = new DeletedUsersTable();
		fetchDeletedUserData(user);
		HibernateConnector connector = new HibernateConnector();
		connector.MakeHibernateTransaction(user);
		Alert alert2 = new Alert(Alert.AlertType.INFORMATION);
		alert2.setContentText("User deleted Successfully");
		alert2.showAndWait();

	}

	@FXML
	private void moveToBackOffice(ActionEvent event) {
		try {

			Back_Office_ModuleController.setUserName(UserName);
			Back_Office_ModuleController.setUserType(userType);
			Back_Office_ModuleController.setPass(pass);
			Parent root = FXMLLoader.load(getClass().getResource("/Zimele_Back_Office/Back_Office_Module.fxml"));
			Scene scene = new Scene(root);
			scene.getStylesheets().add(STYLESHEET_CASPIAN);
			Stage stage = (Stage) myMenuBar.getScene().getWindow();
			/*
			 * Stage stage =
			 * (Stage)((Node)event.getSource()).getScene().getWindow();
			 */
			stage.setScene(scene);
			stage.show();

		} catch (IOException ex) {
			Logger.getLogger(Zimele_LogInController.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	@FXML
	private void moveToFrontOffice(ActionEvent event) {
		try {
			FXMLDocumentController.setUserName(UserName);
			FXMLDocumentController.setUserType(userType);
			FXMLDocumentController.setPassword(pass);
			Parent root;
			root = FXMLLoader
					.load(getClass().getResource("/zimele_information_management_system/Zimele_Front_Office.fxml"));
			Scene scene = new Scene(root);
			scene.getStylesheets().add(STYLESHEET_CASPIAN);
			Stage stage = (Stage) myMenuBar.getScene().getWindow();
			/*
			 * Stage stage =
			 * (Stage)((Node)event.getSource()).getScene().getWindow();
			 */
			stage.setScene(scene);
			stage.show();

		} catch (IOException ex) {
			Logger.getLogger(Zimele_LogInController.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	@FXML
	private void showUserLogInData(MouseEvent event) {

		conn = javaconnect.connectDb1();
		try {
			String sql = "select * from userdatatable";
			statement = conn.prepareStatement(sql);
			result = statement.executeQuery();
			ResultsetTableDisplay table = new ResultsetTableDisplay(UserTableView);
			table.displayToTable1(result);

		} catch (Exception e) {
			Alert alert2 = new Alert(Alert.AlertType.ERROR);
			alert2.setContentText(e.toString());
			alert2.showAndWait();

		}

	}

	@FXML
	private void LoadTables(ActionEvent event) {

		try {
			String selectedTable = ChooseTable.getValue();
			ResultsetTableDisplay display = new ResultsetTableDisplay(AdminMainTableView);
			String sql = "select * from ";
			sql = sql.concat(selectedTable);
			display.executeSqlStatement(sql);
			EditTable.setSelected(false);
			AdminMainTableView.setEditable(false);
			System.out.println(sql);
		} catch (Exception e) {
			Alert alert2 = new Alert(Alert.AlertType.ERROR);
			alert2.setContentText(e.toString());
			alert2.showAndWait();

		}
	}

	@FXML
	private void setTableEditable(ActionEvent event) {
		setMemberNumber(memberNumber.getText());
		EditableCell edit = new EditableCell();
		if (EditTable.isSelected()) {
			String selectedTable = ChooseTable.getValue();

			String sql = "select * from ";
			sql = sql.concat(selectedTable);

			edit.setTableEditable(AdminMainTableView, sql, selectedTable, memberNumber.getText());

		} else {
			edit.setTableEditableFalse(AdminMainTableView);

		}
	}

	@FXML
	private void sendClientMailStatements(ActionEvent event) {
		SendMail mail = new SendMail();
		// mail.sendMail("customerservice@zimele.net","kujeni@830","nateBollar100@gmail.com");
		mail.sendMail("customerservice@zimele.net", "kujeni@830", "nateBollar100@gmail.com",
				"./EmailReports/GuaranteedPensionStatement.pdf", "GuaranteedPensionStatement.pdf");

		// SendStatementMail send= new SendStatementMail();
		// try {
		// send.sendPdfGETDBData();
		// } catch (SQLException ex) {
		// Logger.getLogger(Zimele_AdminController.class.getName()).log(Level.SEVERE,
		// null, ex);
		// } catch (JRException ex) {
		// Logger.getLogger(Zimele_AdminController.class.getName()).log(Level.SEVERE,
		// null, ex);
		// }
		//
	}

	public String checkForNumbers(String input) {
		String str = input;
		str = str.replaceAll("[^0-9]", "");

		return str;
	}

	@FXML
	private void validateUserInfo(MouseEvent event) {
		createUserBtn.disableProperty().bind(firstName.textProperty().isEmpty().or(lastName.textProperty().isEmpty())
				.or(userName.textProperty().isEmpty()).or(password.textProperty().isEmpty()));

	}

	@FXML
	private void validateDeleteUser(MouseEvent event) {

		DeleteUser.disableProperty()
				.bind(DeleteUserName.textProperty().isEmpty().or(DeletePassword.textProperty().isEmpty()));
	}

	@FXML
	private void sendMonthlySms(ActionEvent event) {
		try {
			updateMarketValue();
		} catch (SQLException ex) {
			Logger.getLogger(Zimele_AdminController.class.getName()).log(Level.SEVERE, null, ex);
		}
		SendMonthlySmS sms = new SendMonthlySmS();
		sms.sendSMSBalance();

	}

	public void updateMarketValue() throws SQLException {
		conn = javaconnect.connectDb1();
		Double currentPricebp = 0.00;
		Double currentPricepp = 0.00;
		String sql0 = "SELECT * FROM `current price` ";
		PreparedStatement statement0;
		statement0 = conn.prepareStatement(sql0);
		ResultSet result0 = statement0.executeQuery();
		while (result0.next()) {
			currentPricebp = result0.getDouble("BalanceFundCurrentPrice");
			currentPricepp = result0.getDouble("personalPension Current Price");
		}
		String sql1 = "update moneymarketaccounts set MarketValue=AccountBalance+Interest";
		String sql2 = "update garanteedpensionaccounts set MarketValue=AccountBalance+Interest";
		String sql3 = "update balacefundaccounts set CurrentValue=TotalUnitBalance*";
		sql3 = sql3.concat(currentPricebp.toString());
		String sql4 = "update personalpensionpurchase set CurrentValue=TotalUnitBalance*";
		sql4 = sql4.concat(currentPricepp.toString());
		String sql5 = "update balacefundaccounts set `Gain/Loss`=CurrentValue-TotalPurchaseAmount";
		String sql6 = "update personalpensionpurchase set `Gain/Loss`=CurrentValue-TotalPurchaseAmount";

		PreparedStatement statement1;
		PreparedStatement statement2;
		PreparedStatement statement3;
		PreparedStatement statement4;
		PreparedStatement statement5;
		PreparedStatement statement6;
		System.out.println("sql1" + sql1);
		System.out.println("sql2" + sql2);
		System.out.println("sql3" + sql3);
		System.out.println("sql4" + sql4);
		System.out.println("sql5" + sql5);
		System.out.println("sql6" + sql6);
		try {

			statement1 = conn.prepareStatement(sql1);
			statement1.execute();
			statement2 = conn.prepareStatement(sql2);
			statement2.execute();
			statement3 = conn.prepareStatement(sql3);
			statement3.execute();
			statement4 = conn.prepareStatement(sql4);
			statement4.execute();
			statement5 = conn.prepareStatement(sql3);
			statement5.execute();
			statement6 = conn.prepareStatement(sql4);
			statement6.execute();
		} catch (SQLException ex) {
			Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	@FXML
	private void memberNumberSearch(ActionEvent event) {
		setMemberNumber(memberNumber.getText());
		// "balancefundwithdrawal","moneymarketdeposit","moneymarketwithdrawal",
		// "fundtransfer","investmentapplication","garanteedpensiondeposit","garanteedpensionwithdrawals",
		// "homeownershipdeposit","homeownershipwithdrawal","nextofkininformation","personalinformation",
		// "personalpensiondeposit","balancefundpurchase","personalpensionwithdrawal","balacefundaccounts","balancefundwithdrawalaccouts","garanteedpensionaccounts",
		// "homeownershipaccounts","moneymarketaccounts","personalpensionpurchase","personalinformation");
		//

		try {
			String selectedTable = ChooseTable.getValue();
			ResultsetTableDisplay display = new ResultsetTableDisplay(AdminMainTableView);
			if (ChooseTable.getValue() == "balancefundwithdrawal" || ChooseTable.getValue() == "balancefundpurchase"
					|| ChooseTable.getValue() == "personalinformation"
					|| ChooseTable.getValue() == "nextofkininformation") {
				String sql = "select * from ";
				sql = sql.concat(selectedTable);
				sql = sql.concat(" where memberNumber='");
				sql = sql.concat(memberNumber.getText());
				sql = sql.concat("'");
				display.executeSqlStatement(sql);
				EditTable.setSelected(false);
				AdminMainTableView.setEditable(false);
				System.out.println(sql);

			} else {
				String sql = "select * from ";
				sql = sql.concat(selectedTable);
				sql = sql.concat(" where MemberNumber='");
				sql = sql.concat(memberNumber.getText());
				sql = sql.concat("'");
				display.executeSqlStatement(sql);
				EditTable.setSelected(false);
				AdminMainTableView.setEditable(false);
				System.out.println(sql);

			}

		} catch (Exception e) {
			Alert alert2 = new Alert(Alert.AlertType.ERROR);
			alert2.setContentText(e.toString());
			alert2.showAndWait();

		}

	}

	public void createUserLogin() {
		JaspytPasswordEncryptor encryptor = new JaspytPasswordEncryptor();
		String passwod = encryptor.getEncryptedString(password.getText());
		System.out.println("raw password " + password.getText());
		System.out.println("encrypted password " + passwod);
		conn = javaconnect.connectDb1();
		String sql = "INSERT INTO `userdatatable`(`UserName`, `firstName`, `lastName`, `password`, `userType`) VALUES (?,?,?,?,?)";
		PreparedStatement statement2;
		try {
			statement2 = conn.prepareStatement(sql);
			statement2.setString(1, userName.getText());
			statement2.setString(2, firstName.getText());
			statement2.setString(3, lastName.getText());
			statement2.setString(4, passwod);
			statement2.setString(5, UserTypeChoice.getValue());
			//
			statement2.execute();

		} catch (SQLException ex) {
			Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
		}

	}

	@FXML
	private void specificClientReInvestment(ActionEvent event) throws SQLException {
		String selectedTable = ChooseTable.getValue();
		String sql = "select * from ";
		sql = sql.concat(selectedTable);
		sql = sql.concat(" where MemberNumber='");
		sql = sql.concat(memberNumber.getText());
		sql = sql.concat("'");
		if (ChooseTable.getValue() == "moneymarketaccounts") {

			statement = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			ResultSet rs = statement.executeQuery();

			while (rs.next()) {

				double acountBalance = rs.getDouble("AccountBalance");

				double Interest = rs.getDouble("Interest");
				double newAccountBalance = acountBalance + Interest;
				double newInterest = Interest - Interest;
				rs.updateDouble("AccountBalance", newAccountBalance);
				rs.updateDouble("Interest", newInterest);
				rs.updateRow();

			}
			Alert alert = new Alert(Alert.AlertType.INFORMATION);
			alert.setContentText("re-investing successful");
			alert.showAndWait();
		} else if (ChooseTable.getValue() == "garanteedpensionaccounts") {
			statement = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			ResultSet rs = statement.executeQuery();

			while (rs.next()) {

				double acountBalance = rs.getDouble("AccountBalance");

				double Interest = rs.getDouble("Interest");
				double newAccountBalance = acountBalance + Interest;
				double newInterest = Interest - Interest;
				rs.updateDouble("AccountBalance", newAccountBalance);
				rs.updateDouble("Interest", newInterest);
				rs.updateRow();

			}
			Alert alert = new Alert(Alert.AlertType.INFORMATION);
			alert.setContentText("re-investing successful");
			alert.showAndWait();
		}

	}

	@FXML
	private void activateReinvesting(ActionEvent event) {
		if (ReInvest.isSelected()) {
			ReInvestClient.setDisable(false);

		} else {
			ReInvestClient.setDisable(true);
		}

	}

	@FXML
	private void setMonthlyBalancesTrue(ActionEvent event) {

		if (SetBalancesTrue.isSelected()) {
			sendMails.setDisable(false);
			sendSMS.setDisable(false);

		} else {

			sendMails.setDisable(true);
			sendSMS.setDisable(true);
		}

	}

}

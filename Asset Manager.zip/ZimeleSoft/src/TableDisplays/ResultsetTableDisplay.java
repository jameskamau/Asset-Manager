package TableDisplays;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.*;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.util.Callback;
import DataBaseConnector.javaconnect;


/**
 *
 * @author james kamau
 */
public class ResultsetTableDisplay {
    
    PreparedStatement statement;
    ResultSet result;
    Connection connect;
    public ResultsetTableDisplay(){
    
       
    }
    
    TableView<ObservableList> TableView; 
    
    
    public ResultsetTableDisplay(TableView<ObservableList> TableView){
    
        this.TableView=TableView;
      }
    
    
    
     public void displayToTable1(ResultSet rs) throws SQLException {
        TableView.getColumns().clear();

        ObservableList<ObservableList> data = FXCollections.observableArrayList();

        for (int i = 0; i < rs.getMetaData().getColumnCount(); i++) {

            final int j = i;

            TableColumn column = new TableColumn(rs.getMetaData().getColumnName(i + 1));
            column.setMinWidth(60);
           


            column.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ObservableList, String>, ObservableValue<String>>() {


                @Override
                public ObservableValue<String> call(CellDataFeatures<ObservableList, String> param) {
                    return new SimpleStringProperty(param.getValue().get(j).toString());
                    //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                }

            });

            TableView.getColumns().addAll(column);
        }

        while (rs.next()) {
            ObservableList<String> row = FXCollections.observableArrayList();

            for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {

                row.add(rs.getString(i));
            }
            data.add(row);
        }

        TableView.setItems(data);

    }
   
  public void displayToTable(ResultSet rs) throws SQLException {
      String nill="NULL";
      String nill1="";
        TableView.getColumns().clear();

        ObservableList<ObservableList> data = FXCollections.observableArrayList();

        for (int i = 0; i < rs.getMetaData().getColumnCount(); i++) {
            final int j = i;

            TableColumn column = new TableColumn(rs.getMetaData().getColumnName(i + 1));
            column.setMinWidth(200);

            column.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ObservableList, String>, ObservableValue<String>>() {
               @Override
                public ObservableValue<String> call(CellDataFeatures<ObservableList, String> param) {
                   
                   try{
                     return new SimpleStringProperty(param.getValue().get(j).toString());
                   }catch(Exception e){
                     return new SimpleStringProperty(nill);
                   
                   }
                    
                    // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                }
          });
            TableView.getColumns().addAll(column);
        }
        while (rs.next()) {
           
            ObservableList<String> row = FXCollections.observableArrayList();

            for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
                row.add(rs.getString(i));
            }
            data.add(row);
        }
        TableView.setItems(data);
       
    }
   
   
    
    public void executeSqlStatement(String sql){
        
          connect = javaconnect.connectDb();
        
         try {

            statement = connect.prepareStatement(sql);
            result = statement.executeQuery();

            displayToTable(result);

        } catch (SQLException ex) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText(ex.toString());
            alert.showAndWait();

        }
    
    
    }
    
}

package TableDisplays;
import DataBaseConnector.javaconnect;
import Zimele_Admin.Zimele_AdminController;
import Zimele_Back_Office.Back_Office_ModuleController;

import com.sun.javafx.collections.ObservableListWrapper;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.control.Alert;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.util.Callback;
 




public class EditableCell {
    
     private TableView<ObservableList> tableView1 = new TableView<>();
    
     
   TableColumn column1;
   ResultSet resultset;
   PreparedStatement statement;
   Connection connect;
   private int row;
    int column;
   ResultSet result;
   String value;
    
    

 
 
   
    

   Callback<TableColumn, TableCell> cellFactory =
              new Callback<TableColumn, TableCell>() {
                  public TableCell call(TableColumn p) {
                      return new EditingCell();
                  }
              };
   
  
   public void  setTableEditable(TableView tableView,String sql,String selectedTable) {
       
       this.tableView1=tableView;
       
    tableView1.setEditable(true);
   
  //  ObservableList<TableColumn> columns = tableView.getColumns();
   tableView1.getSelectionModel().setCellSelectionEnabled(true);
    
        final ObservableList<TablePosition> selectedCells = tableView.getSelectionModel().getSelectedCells();
        selectedCells.addListener(new ListChangeListener<TablePosition>() {
        @Override
        public void onChanged(Change change) {
            for (TablePosition pos : selectedCells) {
                column=pos.getColumn();
                setTableCellEditable(pos.getTableColumn(),sql,selectedTable);
                System.out.println(pos.getColumn());
                setRow(pos.getRow());
               
               
           }
    };
});
   }
  
    public void  setTableEditable(TableView tableView,String sql,String selectedTable ,String memberNumber) {
       
       this.tableView1=tableView;
       
    tableView1.setEditable(true);
   
  //  ObservableList<TableColumn> columns = tableView.getColumns();
   tableView1.getSelectionModel().setCellSelectionEnabled(true);
    
        final ObservableList<TablePosition> selectedCells = tableView.getSelectionModel().getSelectedCells();
        selectedCells.addListener(new ListChangeListener<TablePosition>() {
        @Override
        public void onChanged(Change change) {
            for (TablePosition pos : selectedCells) {
                column=pos.getColumn();
                setTableCellEditable(pos.getTableColumn(),sql,selectedTable,memberNumber);
                System.out.println(pos.getColumn());
                setRow(pos.getRow());
               
               
           }
    };
});
   }
   public void setTableEditableFalse(TableView tableView){
         tableView.setEditable(false);
   
   }
   
   
   
    public void getResultSetInstance(String sql,String tableName,String MemberNumber){
       
      connect = javaconnect.connectDb();
     
      String row1=Integer.toString(row+1);
      System.out.println(column);
     
        if(tableName=="moneymarketaccounts"||tableName=="homeownershipaccounts"||tableName=="garanteedpensionaccounts"){
              try {

            statement = connect.prepareStatement(sql);
            resultset = statement.executeQuery();
            System.out.println("works");
            
           String columnName= resultset.getMetaData().getColumnName(column+1);
           System.out.println(columnName);
           System.out.println("works1");
         
          String sql1="UPDATE ";
           sql1=  sql1.concat("`");
          sql1=  sql1.concat(tableName);
           sql1=  sql1.concat("`");
            sql1=   sql1.concat(" SET ");
             sql1=  sql1.concat("`");
            sql1=  sql1.concat(columnName);
             sql1=  sql1.concat("`");
            sql1=  sql1.concat("=");
            sql1=  sql1.concat("'");
             sql1= sql1.concat(value);
              sql1=  sql1.concat("'");
            
             sql1= sql1.concat(" WHERE ");
            sql1=  sql1.concat("`MemberNumber` ");
            sql1=  sql1.concat( " = ");
            sql1= sql1.concat(MemberNumber);
            System.out.println(sql1);
            statement = connect.prepareStatement(sql1);
             boolean result1 =statement.execute();
             
             if(result1==false){
            	 Back_Office_ModuleController back= new Back_Office_ModuleController();
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("Update Successfull . Refresh Table ! unchecked box");
              alert.showAndWait();
              Platform.runLater(new Runnable() {
			        @Override
			        public void run() {
			       back.EditTableView.setSelected(false);
			        }
			    });
              
             }
        

      

        } catch (SQLException ex) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText(ex.toString());
            alert.showAndWait();

        } 
              }
          

      
    }
    
     public void getResultSetInstance(String sql,String tableName){
        Zimele_AdminController admin= new Zimele_AdminController();
      connect = javaconnect.connectDb();
     
      String row1=Integer.toString(row+1);
      System.out.println(column);
     
        if(tableName=="moneymarketaccounts"||tableName=="homeownershipaccounts"||tableName=="garanteedpensionaccounts"){
              try {

            statement = connect.prepareStatement(sql);
            resultset = statement.executeQuery();
            System.out.println("works");
            
           String columnName= resultset.getMetaData().getColumnName(column+1);
           System.out.println(columnName);
           System.out.println("works1");
         
          String sql1="UPDATE ";
           sql1=  sql1.concat("`");
          sql1=  sql1.concat(tableName);
           sql1=  sql1.concat("`");
            sql1=   sql1.concat(" SET ");
             sql1=  sql1.concat("`");
            sql1=  sql1.concat(columnName);
             sql1=  sql1.concat("`");
            sql1=  sql1.concat("=");
            sql1=  sql1.concat("'");
             sql1= sql1.concat(value);
              sql1=  sql1.concat("'");
            
             sql1= sql1.concat(" WHERE ");
            sql1=  sql1.concat("`MemberNumber` ");
            sql1=  sql1.concat( " = ");
            sql1= sql1.concat(admin.getMemberNumber());
            System.out.println(sql1);
            statement = connect.prepareStatement(sql1);
             boolean result1 =statement.execute();
             
             if(result1==false){
                 
            	 Back_Office_ModuleController back= new Back_Office_ModuleController();
                 Alert alert = new Alert(Alert.AlertType.INFORMATION);
                 alert.setContentText("Update Successfull . Refresh Table !unchecked box");
               alert.showAndWait();
               Platform.runLater(new Runnable() {
 			        @Override
 			        public void run() {
 			       back.EditTableView.setSelected(false);
 			        }
 			    });
             }
        

      

        } catch (SQLException ex) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText(ex.toString());
            alert.showAndWait();

        } 
              }
          

      
    }
     
  
   public void setTableCellEditable(TableColumn column,String sql,String tableName,String MemberNumber){
     
      
    
        column1=column;
         
        column1.setCellFactory(cellFactory);
             column1.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent>() {
                  @Override public void handle(TableColumn.CellEditEvent t) {
                      t.getTableView().getItems().get(
                              t.getTablePosition().getRow());
                      Object newValue=t.getNewValue();
                       value= newValue.toString();
                      System.out.println(value);
                     getResultSetInstance(sql,tableName,MemberNumber);
                    
                    
                  }
              });
     
    
   
   }
    public void setTableCellEditable(TableColumn column,String sql,String tableName){
     
      
    
        column1=column;
         
        column1.setCellFactory(cellFactory);
             column1.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent>() {
                  @Override public void handle(TableColumn.CellEditEvent t) {
                      t.getTableView().getItems().get(
                              t.getTablePosition().getRow());
                      Object newValue=t.getNewValue();
                       value= newValue.toString();
                      System.out.println(value);
                     getResultSetInstance(sql,tableName);
                    
                    
                  }
              });
     
    
   
   }

    /**
     * @return the row
     */
    public int getRow() {
        return row;
    }

    /**
     * @param row the row to set
     */
    public void setRow(int row) {
        this.row = row;
    }

    /**
     * @return the column
     */
    public int getColumn() {
        return column;
    }
    public int getColumn(int column) {
        return column;
    }

    /**
     * @param column the column to set
     */
    public void setColumn(int column) {
        this.column = column;
    }
   
   
 
  class EditingCell extends TableCell<ValueHolder, String>{
 
      private TextField textField;
     
      public EditingCell() {}
     
      @Override
      public void startEdit() {
          super.startEdit();
         
          if (textField == null) {
              createTextField();
          }
         
          setGraphic(textField);
          setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
          textField.selectAll();
      }
     
      @Override
      public void cancelEdit() {
          super.cancelEdit();
         
          setText(String.valueOf(getItem()));
          setContentDisplay(ContentDisplay.TEXT_ONLY);
      }
 
      @Override
      public void updateItem(String item, boolean empty) {
          super.updateItem(item, empty);
         
          if (empty) {
              setText(null);
              setGraphic(null);
          } else {
              if (isEditing()) {
                  if (textField != null) {
                      textField.setText(getString());
                  }
                  setGraphic(textField);
                  setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
              } else {
                  setText(getString());
                  setContentDisplay(ContentDisplay.TEXT_ONLY);
              }
          }
      }
 
      private void createTextField() {
          textField = new TextField(getString());
          textField.setMinWidth(this.getWidth() - this.getGraphicTextGap()*2);
          textField.setOnKeyPressed(new EventHandler<KeyEvent>() {
             
              @Override
              public void handle(KeyEvent t) {
                  if (t.getCode() == KeyCode.ENTER) {
                      commitEdit(textField.getText());
                  } else if (t.getCode() == KeyCode.ESCAPE) {
                      cancelEdit();
                  }
              }
          });
      }
     
      private String getString() {
          return getItem() == null ? "" : getItem().toString();
      }
  }
 
}

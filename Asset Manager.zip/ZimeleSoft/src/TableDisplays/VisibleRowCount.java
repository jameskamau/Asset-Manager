
package TableDisplays;

import com.sun.javafx.scene.control.skin.TableViewSkin;
import com.sun.javafx.scene.control.skin.VirtualFlow;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.util.Callback;

/**
 *
 * @author james kamau
 */
public class VisibleRowCount {
     TableView<ObservableList> TableView;
     PreparedStatement statement;
    ResultSet result;
    Connection connect;
     IntegerProperty intP = new SimpleIntegerProperty(5);
    AnchorPane anchor = new AnchorPane();
      ObservableList<ObservableList> data = FXCollections.observableArrayList();
      ResultSet rs;
       public int itemsPerPage()
    {
        return 1;
    }

    public int rowsPerPage()
    {
        return intP.get();
    }
     public VBox createPage(int pageIndex) throws SQLException{
        int lastIndex = 0;
        int displace = data.size() % rowsPerPage();
        if (displace > 0)
        {
            lastIndex = data.size() / rowsPerPage();
        }
        else
        {
            lastIndex = data.size() / rowsPerPage() - 1;
        }
        VBox box = new VBox();
        int page = pageIndex * itemsPerPage();
       
            TableView.getColumns().clear();

        ObservableList<ObservableList> data = FXCollections.observableArrayList();

        for (int i = 0; i < rs.getMetaData().getColumnCount(); i++) {

            final int j = i;

            TableColumn column = new TableColumn(rs.getMetaData().getColumnName(i + 1));
            column.setMinWidth(60);
           


            column.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ObservableList, String>, ObservableValue<String>>() {


                @Override
                public ObservableValue<String> call(TableColumn.CellDataFeatures<ObservableList, String> param) {
                    return new SimpleStringProperty(param.getValue().get(j).toString());
                    //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                }

            });

            TableView.getColumns().addAll(column);
        }

        while (rs.next()) {
            ObservableList<String> row = FXCollections.observableArrayList();

            for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {

                row.add(rs.getString(i));
            }
            data.add(row);
        }

        TableView.setItems(data);
            if (lastIndex == pageIndex)
            {
                TableView.setItems(FXCollections.observableArrayList(data.subList(pageIndex * rowsPerPage(), pageIndex * rowsPerPage() + displace)));
            }
            else
            {
                TableView.setItems(FXCollections.observableArrayList(data.subList(pageIndex * rowsPerPage(), pageIndex * rowsPerPage() + rowsPerPage())));
            }

            box.getChildren().addAll(TableView);

       
        return box;
    }
     
     public int[] getVisibleRange(TableView table) {
            TableViewSkin<?> skin = (TableViewSkin) table.getSkin();
            if (skin == null) {
               return new int[] {0, 0};
            }
            VirtualFlow<?> flow = (VirtualFlow) skin.getChildren().get(1);
            int indexFirst;
            int indexLast;
            if (flow != null && flow.getFirstVisibleCellWithinViewPort() != null 
                && flow.getLastVisibleCellWithinViewPort() != null) {
               indexFirst = flow.getFirstVisibleCellWithinViewPort().getIndex();
               if (indexFirst >= table.getItems().size()) 
                  indexFirst = table.getItems().size() - 1;
               indexLast = flow.getLastVisibleCellWithinViewPort().getIndex();
               if (indexLast >= table.getItems().size())
                  indexLast = table.getItems().size() - 1;
            } else {
               indexFirst = 0;
               indexLast = 0;
            }
            return new int[] {indexFirst, indexLast};
}

}

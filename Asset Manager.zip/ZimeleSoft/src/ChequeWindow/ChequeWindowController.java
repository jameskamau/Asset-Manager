/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ChequeWindow;

import DataBaseConnector.javaconnect;
import DateConverter.LocalDatePersistenceConverter;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;


/**
 * FXML Controller class
 *
 * @author james kamau
 */
public class ChequeWindowController implements Initializable {

    PreparedStatement statement;
    ResultSet result;
    Connection conn;
     private String memberNumber;
    private String transNo;
    @FXML
    private ChoiceBox<String> chooseBank;
    @FXML
    private TextField bankBranch;
    @FXML
    private TextField chequeNo;
    @FXML
    private TextField accountNo;
    @FXML
    private TextField drawerName;
    @FXML
    private DatePicker dateDrafted;
    @FXML
    private Button saveBankDetails;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        chooseBank.getItems().addAll("Co-operative Bank ","KCB","Barclays","Standard Chartered","National Bank","K-Rep","Ecobank","Equity","Family","NIC","Stanbic Bank Kenya","OTHERS");
        chooseBank.setValue("KCB");
        // TODO
    }    
    LocalDatePersistenceConverter date1= new LocalDatePersistenceConverter();

    @FXML
    private void saveBankDetails(ActionEvent event) {
          conn=javaconnect.connectDb();
                   String sql= "INSERT INTO bankdetails (MemberNumber,TransNo,chooseBank,bankBranch,chequeNo,accountNo,drawerName,dateDrafted) VALUES(?,?,?,?,?,?,?,?)";
                   PreparedStatement  statement2;
        try {
            statement2 = conn.prepareStatement(sql);
            statement2.setString(1, getMemberNumber());
            statement2.setString(2, getTransNo());
            statement2.setString(3, chooseBank.getValue());
            statement2.setString(4, bankBranch.getText());
            statement2.setString(5, chequeNo.getText());
            statement2.setString(6, accountNo.getText());
            statement2.setString(7, drawerName.getText());
            statement2.setDate(8, date1.convertToDatabaseColumn(dateDrafted.getValue()));
            statement2.execute();
            
            
            Alert alert2= new Alert(Alert.AlertType.INFORMATION);
            alert2.setContentText("Bank Details saved successfully");
            alert2.showAndWait();
             
        } catch (SQLException ex) {
            Logger.getLogger(ChequeWindowController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

    /**
     * @return the memberNumber
     */
    public String getMemberNumber() {
        return memberNumber;
    }

    /**
     * @param memberNumber the memberNumber to set
     */
    public void setMemberNumber(String memberNumber) {
        this.memberNumber = memberNumber;
    }

    /**
     * @return the transNo
     */
    public String getTransNo() {
        return transNo;
    }

    /**
     * @param transNo the transNo to set
     */
    public void setTransNo(String transNo) {
        this.transNo = transNo;
    }

    @FXML
    private void ValidateBankDetails(MouseEvent event) {
        saveBankDetails.disableProperty().bind(
                 dateDrafted.valueProperty().isNull()
              .or(chequeNo.textProperty().isEmpty() )
               .or(bankBranch.textProperty().isEmpty() )
               .or(accountNo.textProperty().isEmpty() )
              .or(drawerName.textProperty().isEmpty() )
      );
    }
    
}

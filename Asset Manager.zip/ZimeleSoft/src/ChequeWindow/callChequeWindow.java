/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ChequeWindow;

import com.mgrecol.jasper.jasperviewerfx.JRViewerFxController;
import java.io.InputStream;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author james kamau
 */
public class callChequeWindow extends Application {
    private String memberNumber;
    private String transNo;

    @Override
    public void start(Stage primaryStage) throws Exception {
        InputStream fxmlStream = null;
		try {
			fxmlStream = getClass().getResourceAsStream("chequeWindow.fxml");
			FXMLLoader loader = new FXMLLoader();
			Parent page = (Parent) loader.load(fxmlStream);
      Scene scene = new Scene(page);
            primaryStage.setScene(scene);
            primaryStage.setTitle("Cheque Details");
            primaryStage.show();
          Object o = loader.getController();
            if(o instanceof ChequeWindowController){

      ChequeWindowController window = (ChequeWindowController)o;
                    window.setMemberNumber(memberNumber);
                    window.setTransNo(transNo);
            	
            }
            
        } catch (Exception ex) {
          ex.printStackTrace();
        }
        
        
        
    }
     public callChequeWindow( Stage primaryStage,String memberNumber,String transNo ){
	this.memberNumber=memberNumber;
        this.transNo=transNo;
	try {
		start(primaryStage);
	} catch (Exception e) {
		e.printStackTrace();
	}
}
    
    public callChequeWindow( Stage primaryStage ){
	
	try {
		start(primaryStage);
	} catch (Exception e) {
		e.printStackTrace();
	}
}
    
}

package DataBaseConnector;


// truncate * tables  mysql -Nse :---  'show tables' DATABASE_NAME | while read table; do mysql -e "truncate table $table" DATABASE_NAME; done
/**
 *
 * @author james kamau
 */


import java.sql.*;
import javafx.scene.control.Alert;
public class JavaFirebirdconnect {
    PreparedStatement statement;
    ResultSet result;
    Connection conn=null;                           //"jdbc:firebirdsql://192.168.100.101:3050/e:\\Bulwark\\Database\\Bulwark.fdb", "sysdba", "a"
                                                    //"jdbc:firebirdsql://localhost:3050/C:\\Program Files\\Firebird\\BULWARK.FDB", "SYSDBA", "masterkey"
    public static  Connection connectDb1(){
    
	    try{
	    Class.forName("org.firebirdsql.jdbc.FBDriver");
	  //Connection conn = DriverManager.getConnection("jdbc:firebirdsql://192.168.100.101:3050/e:\\Bulwark\\Database\\Bulwark.fdb", "sysdba", "a");
	   Connection conn = DriverManager.getConnection("jdbc:firebirdsql://localhost:3050/C:\\Program Files\\Firebird\\NEWPENSION.FDB", "SYSDBA", "a");
	        Alert alert = new Alert(Alert.AlertType.INFORMATION);
	        alert.setContentText(" FIREBIRD  Connection Established");
	        alert.showAndWait();
	    return conn;
	    
	    }catch(Exception e) {
	
	   Alert alert2= new Alert(Alert.AlertType.ERROR);
	        alert2.setContentText(e.toString());
	        alert2.showAndWait();
	    }
    return null;
    }
    
    public static  Connection connectDb(){
    
    try{
    Class.forName("org.firebirdsql.jdbc.FBDriver");
    //Connection conn = DriverManager.getConnection("jdbc:firebirdsql://192.168.100.101:3050/e:\\Bulwark\\Database\\Bulwark.fdb", "sysdba", "a");
    Connection conn = DriverManager.getConnection("jdbc:firebirdsql://localhost:3050/C:\\Program Files\\Firebird\\BULWARK.FDB", "SYSDBA", "a");
      
    return conn;
    
    }catch(Exception e) {

   Alert alert2= new Alert(Alert.AlertType.ERROR);
        alert2.setContentText(e.toString());
        alert2.showAndWait();
    }
    return null;
    }
     public void executeSqlStatement(String sql,Connection connect){
        
          connect = JavaFirebirdconnect.connectDb();
        
         try {

            statement = connect.prepareStatement(sql);
            boolean result1 =statement.execute();
            
             
             if(result1==false){
                 
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("Update Successfull !");
              alert.showAndWait();
             }

           

        } catch (SQLException ex) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText(ex.toString());
            alert.showAndWait();

        }
     }
     
     
   
    }



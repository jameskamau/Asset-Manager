package DataBaseConnector;


// truncate * tables  mysql -Nse :---  'show tables' DATABASE_NAME | while read table; do mysql -e "truncate table $table" DATABASE_NAME; done
/**
 *
 * @author james kamau
 */


import java.sql.*;
import javafx.scene.control.Alert;
public class javaconnect {
    PreparedStatement statement;
    ResultSet result;                               //"jdbc:mysql://192.168.100.101:3306/zimeleassetmanagementdb", "Zimele_Soft_DB", "zimele45" 
    Connection conn=null;                           //"jdbc:mysql://192.168.100.101:3306/zimele_info_soft", "Zimele_Soft_DB", "zimele45"
                                                    //"jdbc:mysql://localhost:3306/zimeleassetmanagementdb", "root", "401229053" 
    public static  Connection connectDb(){
    
    try{
    Class.forName("com.mysql.jdbc.Driver");
    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/zimeleassetmanagementdb", "root", "401229053");
   // Connection conn = DriverManager.getConnection("jdbc:mysql://192.168.100.101:3306/zimeleassetmanagementdb", "Zimele_Soft_DB", "zimele45");
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setContentText("Connection Established");
        alert.showAndWait();
    return conn;
    
    }catch(Exception e) {

   Alert alert2= new Alert(Alert.AlertType.ERROR);
        alert2.setContentText(e.toString());
        alert2.showAndWait();
    }
    return null;
    }
    
    public static  Connection connectDb1(){
    
    try{
    Class.forName("com.mysql.jdbc.Driver");
    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/zimeleassetmanagementdb", "root", "401229053");
    //Connection conn = DriverManager.getConnection("jdbc:mysql://192.168.100.101:3306/zimeleassetmanagementdb", "Zimele_Soft_DB", "zimele45");
       
    return conn;
    
    }catch(Exception e) {

   Alert alert2= new Alert(Alert.AlertType.ERROR);
        alert2.setContentText(e.toString());
        alert2.showAndWait();
    }
    return null;
    }
    
    
   
     public void executeSqlStatement(String sql,Connection connect){
        
          connect = javaconnect.connectDb();
        
         try {

            statement = connect.prepareStatement(sql);
            boolean result1 =statement.execute();
            
             
             if(result1==false){
                 
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("Update Successfull !");
              alert.showAndWait();
             }

           

        } catch (SQLException ex) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText(ex.toString());
            alert.showAndWait();

        }
     }
     
     
   
    }





package DataBaseConnector;

/**
 *
 * @author james kamau
 */



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
public class HibernateConnector {
    
    
    
   
    public  void MakeHibernateTransaction(Object object){
		
		Session session= createSessionFactory().openSession();
                session.beginTransaction();
		session.save(object);
		session.getTransaction().commit();
		session.close();
		createSessionFactory().close();
		
	}
	public  void MakeHibernateTransaction1(Object object){
		
		Session session= createSessionFactory().openSession();
                session.beginTransaction();
		session.persist(object);
		session.getTransaction().commit();
		session.close();
		createSessionFactory().close();
		
	}

	public static SessionFactory createSessionFactory(){
		

		 SessionFactory sessionFactory;
		 StandardServiceRegistry standardServiceRegistry;
	
		Configuration configuration =new Configuration();
		configuration.configure();
		standardServiceRegistry = new StandardServiceRegistryBuilder().applySettings( configuration.getProperties()).build();
	    sessionFactory=configuration.buildSessionFactory(standardServiceRegistry);
		
	    return sessionFactory;
		
		
	}
    
}

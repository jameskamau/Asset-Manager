/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package PersonalPension;

import DataBaseConnector.javaconnect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.scene.control.Alert;

/**
 *
 * @author james kamau
 */
public class PersonalPensionWithdrawalLogic {
    Connection connect;
    PreparedStatement statement;
    ResultSet result;
    
    private String memberNumber;
    private String PurchaseNumber;
    private Double unitsSold;
    private Double WithdrawalAmount;
    private Double sellPrice;
    
    
    private String FullName;

    /**
     * @return the memberNumber
     */
    public String getMemberNumber() {
        return memberNumber;
    }

    /**
     * @param memberNumber the memberNumber to set
     */
    public void setMemberNumber(String memberNumber) {
        this.memberNumber = memberNumber;
    }

   
    

    /**
     * @return the FullName
     */
    public String getFullName() {
        return FullName;
    }

    /**
     * @param FullName the FullName to set
     */
    public void setFullName(String FullName) {
        this.FullName = FullName;
    }

      
       /**
     * @return the unitsSold
     */
    public Double getUnitsSold() {
        return unitsSold;
    }

    /**
     * @param unitsSold the unitsSold to set
     */
    public void setUnitsSold(Double unitsSold) {
        this.unitsSold = unitsSold;
    }

    /**
     * @return the WithdrawalAmount
     */
    public Double getWithdrawalAmount() {
        return WithdrawalAmount;
    }
    
     /**
     * @param WithdrawalAmount the WithdrawalAmount to set
     */
    public void setWithdrawalAmount(Double WithdrawalAmount) {
        this.WithdrawalAmount = WithdrawalAmount;
    }
    
    
    public void updateDatabaseValue() throws SQLException{
        
            
            
            
        connect=javaconnect.connectDb();
        String sql="INSERT INTO personalpesnionwithdrawalaccounts (MemberNumber,FullName,UnitsSold,WithdrawalAmount) VALUES(";    
         sql=sql.concat("'");
        sql = sql.concat(memberNumber);
         sql=sql.concat("'");
        sql= sql.concat(",");
        sql=sql.concat("'");
        sql= sql.concat(FullName);
        sql=sql.concat("'");
         sql= sql.concat(",");
        
        sql=sql.concat("'");
        sql= sql.concat(unitsSold.toString());
        sql=sql.concat("'");
         sql= sql.concat(",");
        sql=sql.concat("'");
        sql= sql.concat(WithdrawalAmount.toString());
        sql=sql.concat("'");
        sql=sql.concat(")");
        System.out.println(sql);
         System.out.println("this is the purchase number"+getPurchaseNumber()); 
     
       try {

            statement = connect.prepareStatement(sql);
            boolean result1 =statement.execute();
            
             
             if(result1==false){
                 
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("Update Successfull personalpesnionwithdrawalaccounts !");
              alert.showAndWait();
             }
       
       
          } catch (SQLException ex) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText(ex.toString());
            alert.showAndWait();

        }
    }
    static int count=1;
    static int count2=1;
    public void updateDatabaseValue1() throws SQLException{
       connect=javaconnect.connectDb();
//        String sql1="select * FROM `personalpesnionwithdrawalaccounts`";
//        
//        statement = connect.prepareStatement(sql1,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
//        ResultSet rs1 = statement.executeQuery();
//        
//        count=1;
//        while(rs1.next()){
//         
//            String purchaseNumber=rs1.getString("PurchaseNumber");
//                System.out.println(getPurchaseNumber());  
//              Integer purchase =Integer.parseInt(getPurchaseNumber());
//            if(purchase==Integer.parseInt(purchaseNumber)){
//               System.out.println("this is the selected number"+purchaseNumber);
//              break;
//            }
//        count++;
//        }
        
       String sql3 ="select * from  personalpensionpurchase";
        statement = connect.prepareStatement(sql3,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
        ResultSet rs3 = statement.executeQuery();
        count2=1;
        while(rs3.next()){
         
            String memberNumber1=rs3.getString("MemberNumber");
                System.out.println(PurchaseNumber);  
              Integer MemberNumber =Integer.parseInt(memberNumber);
            if(Integer.parseInt(memberNumber1)==MemberNumber){
               System.out.println("this is the selected number"+memberNumber1);
              break;
            }
        count2++;
        }
        rs3.absolute(count2);
        System.out.println("from the secont while loop :"+count2);
       Double totalUnitBalance=  rs3.getDouble("TotalUnitBalance");
        double gainloss=rs3.getDouble("Gain/Loss");
        double totalPurchaseAmount=rs3.getDouble("TotalPurchaseAmount");
        double currentValue;
       double unitBalance=totalUnitBalance-unitsSold;
       System.out.println("Total Unit"+totalUnitBalance);
       System.out.println("Units Sold"+unitsSold);
       System.out.println("Unit Balance"+unitBalance);
       System.out.println("sell pricePPW"+sellPrice);
       double unitsSoldAmount=unitsSold*totalPurchaseAmount/totalUnitBalance;
       double purchaseAmountBalance=totalPurchaseAmount-unitsSoldAmount;
       System.out.println("purchseAmount Balance"+purchaseAmountBalance);
       currentValue=unitBalance*sellPrice;
       double Gainloss=currentValue-purchaseAmountBalance;
        
       
       rs3.updateDouble("TotalUnitBalance", unitBalance);
       rs3.updateDouble("TotalPurchaseAmount", purchaseAmountBalance);
       rs3.updateDouble("CurrentValue", currentValue);
       rs3.updateDouble("Gain/Loss", Gainloss);
       rs3.updateRow();
       
       
    
    
    
    }
    public double getsellPriceFromDB() throws SQLException{
        
        connect=javaconnect.connectDb1();
        String sql1="select * FROM `personalpensionsetrates`";
        
        statement = connect.prepareStatement(sql1);
        ResultSet rs1 = statement.executeQuery();
        rs1.last();
        
        double price =rs1.getDouble("sellPrice");
        
       return price;
    
    }

    /**
     * @return the PurchaseNumber
     */
    public String getPurchaseNumber() {
        return PurchaseNumber;
    }

    /**
     * @param PurchaseNumber the PurchaseNumber to set
     */
    public void setPurchaseNumber(String PurchaseNumber) {
        this.PurchaseNumber = PurchaseNumber;
    }

    /**
     * @return the sellPrice
     */
    public Double getSellPrice() {
        return sellPrice;
    }

    /**
     * @param sellPrice the sellPrice to set
     */
    public void setSellPrice(Double sellPrice) {
        this.sellPrice = sellPrice;
    }

   

   
    
}

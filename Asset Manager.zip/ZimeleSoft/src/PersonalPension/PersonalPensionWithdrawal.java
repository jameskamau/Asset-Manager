/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package PersonalPension;

import DateConverter.LocalDatePersistenceConverter;
import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author james kamau
 */
@Entity
public class PersonalPensionWithdrawal implements Serializable {
    
    
     @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="ID")
    private int id;
    private String PurchaseNumber;
    private String MemberNumber;
    private String fullName;
    private String withdrawalAmount;
    private Double UnitsSold;
    private Double SellPrice;
    @Convert(converter = LocalDatePersistenceConverter.class)
    private LocalDate DateOfWithdrawal ;
    private String SavedByUser;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the MemberNumber
     */
    public String getMemberNumber() {
        return MemberNumber;
    }

    /**
     * @param MemberNumber the MemberNumber to set
     */
    public void setMemberNumber(String MemberNumber) {
        this.MemberNumber = MemberNumber;
    }

    /**
     * @return the fullName
     */
    public String getFullName() {
        return fullName;
    }

    /**
     * @param fullName the fullName to set
     */
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    
    /**
     * @return the DateOfWithdrawal
     */
    public LocalDate getDateOfWithdrawal() {
        return DateOfWithdrawal;
    }

    /**
     * @param DateOfWithdrawal the DateOfWithdrawal to set
     */
    public void setDateOfWithdrawal(LocalDate DateOfWithdrawal) {
        this.DateOfWithdrawal = DateOfWithdrawal;
    }

    /**
     * @return the SavedByUser
     */
    public String getSetByUser() {
        return SavedByUser;
    }

    /**
     * @param SetByUser the SavedByUser to set
     */
    public void setSetByUser(String SetByUser) {
        this.SavedByUser = SetByUser;
    }

   
    /**
     * @return the withdrawalAmount
     */
    public String getWithdrawalAmount() {
        return withdrawalAmount;
    }

    /**
     * @param withdrawalAmount the withdrawalAmount to set
     */
    public void setWithdrawalAmount(String withdrawalAmount) {
        this.withdrawalAmount = withdrawalAmount;
    }

    /**
     * @return the UnitsSold
     */
    public Double getUnitsSold() {
        return UnitsSold;
    }

    /**
     * @param UnitsSold the UnitsSold to set
     */
    public void setUnitsSold(Double UnitsSold) {
        this.UnitsSold = UnitsSold;
    }

    /**
     * @return the SellPrice
     */
    public Double getSellPrice() {
        return SellPrice;
    }

    /**
     * @param SellPrice the SellPrice to set
     */
    public void setSellPrice(Double SellPrice) {
        this.SellPrice = SellPrice;
    }
    public String getPurchaseNumber() {
		return PurchaseNumber;
	}

	public void setPurchaseNumber(String purchaseNumber) {
		PurchaseNumber = purchaseNumber;
	}
  
    
}

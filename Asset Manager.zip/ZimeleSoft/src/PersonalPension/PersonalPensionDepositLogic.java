/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package PersonalPension;

import DataBaseConnector.javaconnect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.scene.control.Alert;

/**
 *
 * @author james kamau
 */
public class PersonalPensionDepositLogic {
    Connection connect;
    PreparedStatement statement;
    ResultSet result;
    private String PurchaseNumber;
    private String memberNumber;
    
    private String FullName;
    private Double unitsPurchased;
    private Double PurchaseAmount;

    /**
     * @return the memberNumber
     */
    public String getMemberNumber() {
        return memberNumber;
    }

    /**
     * @param memberNumber the memberNumber to set
     */
    public void setMemberNumber(String memberNumber) {
        this.memberNumber = memberNumber;
    }

   
    /**
     * @return the FullName
     */
    public String getFullName() {
        return FullName;
    }

    /**
     * @param FullName the FullName to set
     */
    public void setFullName(String FullName) {
        this.FullName = FullName;
    }
    
   
    /**
     * @return the PurchaseNumber
     */
    public String getPurchaseNumber() {
        return PurchaseNumber;
    }

    /**
     * @param PurchaseNumber the PurchaseNumber to set
     */
    public void setPurchaseNumber(String PurchaseNumber) {
        this.PurchaseNumber = PurchaseNumber;
    }

    /**
     * @return the unitsPurchased
     */
    public Double getUnitsPurchased() {
        return unitsPurchased;
    }

    /**
     * @param unitsPurchased the unitsPurchased to set
     */
    public void setUnitsPurchased(Double unitsPurchased) {
        this.unitsPurchased = unitsPurchased;
    }

    /**
     * @return the PurchaseAmount
     */
    public Double getPurchaseAmount() {
        return PurchaseAmount;
    }

    /**
     * @param PurchaseAmount the PurchaseAmount to set
     */
    public void setPurchaseAmount(Double PurchaseAmount) {
        this.PurchaseAmount = PurchaseAmount;
    }
    static int count=1;
    public void updateDatabaseValue() throws SQLException{
         connect=javaconnect.connectDb();
        String sql="SELECT * FROM   personalpensionpurchase ";    
        statement = connect.prepareStatement(sql,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
          ResultSet rs1=statement.executeQuery();
        
             count=1;
        while(rs1.next()){
         
            String memberNumber1=rs1.getString("MemberNumber");
                System.out.println(PurchaseNumber);  
              Integer MemberNumber =Integer.parseInt(memberNumber);
            if(Integer.parseInt(memberNumber1)==MemberNumber){
               System.out.println("this is the selected number"+memberNumber1);
              break;
            }
        count++;
        }
      
        rs1.absolute(count);
      double  totalpurchases=rs1.getDouble("TotalPurchaseAmount");
      double  totalunitBalance=rs1.getDouble("TotalUnitBalance");  
      double totalPurchases=totalpurchases+PurchaseAmount;
      double totalUnitBalance=totalunitBalance+unitsPurchased;
      totalPurchases=Math.round(totalPurchases);
      
      rs1.updateDouble("TotalPurchaseAmount", totalPurchases);
      rs1.updateDouble("TotalUnitBalance", totalUnitBalance);
      rs1.updateRow();
 
       
         
       try {

            statement = connect.prepareStatement(sql);
            boolean result1 =statement.execute();
            
             
             if(result1==false){
                 
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("Update Successfull personalpensionpurchase !");
              alert.showAndWait();
             }
       
       
          } catch (SQLException ex) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText(ex.toString());
            alert.showAndWait();

        }
      
    }
    
     public double getBuyPriceFromDB() throws SQLException{
        
        connect=javaconnect.connectDb1();
        String sql1="select * FROM `personalpensionsetrates`";
        
        statement = connect.prepareStatement(sql1);
        ResultSet rs1 = statement.executeQuery();
        rs1.last();
        
        double price =rs1.getDouble("buyPrice");
        
       return price;
    
    }
    
}

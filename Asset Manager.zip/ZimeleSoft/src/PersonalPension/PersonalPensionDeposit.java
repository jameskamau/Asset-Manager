/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package PersonalPension;

import DateConverter.LocalDatePersistenceConverter;
import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author james kamau
 */
@Entity
public class PersonalPensionDeposit implements Serializable {
    
     @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="ID")
    private int id;
    private String PurchaseNumber;
    private String MemberNumber;
    private String fullName;
    private String PurchaseAmount;
    private String ModeOfPayment;
    @Convert(converter = LocalDatePersistenceConverter.class)
    private LocalDate DateOfDeposit ;
    private Double PurchasePrice;
    private Double UnitsPurchased;
    
    private String SavedByUser;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the MemberNumber
     */
    public String getMemberNumber() {
        return MemberNumber;
    }

    /**
     * @param MemberNumber the MemberNumber to set
     */
    public void setMemberNumber(String MemberNumber) {
        this.MemberNumber = MemberNumber;
    }

    /**
     * @return the fullName
     */
    public String getFullName() {
        return fullName;
    }

    /**
     * @param fullName the fullName to set
     */
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

   

    /**
     * @return the ModeOfPayment
     */
    public String getModeOfPayment() {
        return ModeOfPayment;
    }

    /**
     * @param ModeOfPayment the ModeOfPayment to set
     */
    public void setModeOfPayment(String ModeOfPayment) {
        this.ModeOfPayment = ModeOfPayment;
    }

    /**
     * @return the DateOfDeposit
     */
    public LocalDate getDateOfDeposit() {
        return DateOfDeposit;
    }

    /**
     * @param DateOfDeposit the DateOfDeposit to set
     */
    public void setDateOfDeposit(LocalDate DateOfDeposit) {
        this.DateOfDeposit = DateOfDeposit;
    }

    /**
     * @return the SavedByUser
     */
    public String getSetByUser() {
        return SavedByUser;
    }

    /**
     * @param setByUser the SavedByUser to set
     */
    public void setSetByUser(String setByUser) {
        this.SavedByUser = setByUser;
    }

    /**
     * @return the PurchaseNumber
     */
    public String getPurchaseNumber() {
        return PurchaseNumber;
    }

    /**
     * @param PurchaseNumber the PurchaseNumber to set
     */
    public void setPurchaseNumber(String PurchaseNumber) {
        this.PurchaseNumber = PurchaseNumber;
    }

    
    /**
     * @return the PurchaseAmount
     */
    public String getPurchaseAmount() {
        return PurchaseAmount;
    }

    /**
     * @param PurchaseAmount the PurchaseAmount to set
     */
    public void setPurchaseAmount(String PurchaseAmount) {
        this.PurchaseAmount = PurchaseAmount;
    }

    /**
     * @return the PurchasePrice
     */
    public Double getPurchasePrice() {
        return PurchasePrice;
    }

    /**
     * @param PurchasePrice the PurchasePrice to set
     */
    public void setPurchasePrice(Double PurchasePrice) {
        this.PurchasePrice = PurchasePrice;
    }

    /**
     * @return the UnitsPurchased
     */
    public Double getUnitsPurchased() {
        return UnitsPurchased;
    }

    /**
     * @param UnitsPurchased the UnitsPurchased to set
     */
    public void setUnitsPurchased(Double UnitsPurchased) {
        this.UnitsPurchased = UnitsPurchased;
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Zimele_Back_Office;

import static javafx.application.Application.STYLESHEET_CASPIAN;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.controlsfx.control.textfield.AutoCompletionBinding;
import org.controlsfx.control.textfield.TextFields;

import com.mgrecol.jasper.jasperviewerfx.JRViewerFx;
import com.mgrecol.jasper.jasperviewerfx.JRViewerFxMode;

import BackOficeModelClasses.BalanceFundSetPrices;
import BackOficeModelClasses.GaranteedPensionRates;
import BackOficeModelClasses.HomeOwnershipSetRates;
import BackOficeModelClasses.MoneyMarketSetRate;
import BackOficeModelClasses.PersonalPensionSetRates;
import DataBaseConnector.HibernateConnector;
import DataBaseConnector.JavaFirebirdconnect;
import DataBaseConnector.javaconnect;
import DateConverter.LocalDatePersistenceConverter;
import InterestCalculator.UpdateDataGaranteedPension;
import InterestCalculator.UpdateDataMoneyMarket;
import TableDisplays.EditableCell;
import TableDisplays.ResultsetTableDisplay;
import Zimele_Admin.JaspytPasswordEncryptor;
import Zimele_Admin.Zimele_AdminController;
import Zimele_main.Zimele_LogInController;
import changePassword.MainPassword;
import comppanyinfo.callAboutWindow;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.MenuBar;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;
import zimele_information_management_system.FXMLDocumentController;



/**
 * FXML Controller class
 *
 * @author james kamau
 */
public class Back_Office_ModuleController implements Initializable {
    PreparedStatement statement;
    ResultSet result;
    Connection connect;
    private static String userName;
    private static String userType;
    private static String pass;
    
   
//   String TotalDepositsMMpath="./Reports/MoneyMarketDeposits.jasper";
//    String TotalDepositsBFpath="./Zimele/Reports/BalanceFundPurchases.jrxml";
//    String TotalDepositsHOpath="./src/Reports/HomeOwnershipDeposit.jrxml";
//    String TotalDepositsGPpath="./src/Reports/GaranteeedPensionDeposit.jrxml";
//    String TotalDepositsPPpath="./src/Reports/PersonalPensionPurchases.jrxml";
//    String SortByDate="./src/Reports/DailyFundTotals.jrxml";
//    
//    String TotalWithdrawalsBFpath="./src/Reports/BalanceFundWithdrawal.jrxml";
//    String TotalWithdrawalsMMpath="./src/Reports/MoneyMarketWithdrawal.jrxml";
//    String TotalWithdrawalsHOpath="./src/Reports/HomeOwnershipWithdrawals.jrxml";
//    String TotalWithdrawalsGPpath="./src/Reports/GaranteedPensionWithdrawals.jrxml";
//    String TotalWithdrawalsPPpath="./src/Reports/PersonalPensionWithdrawal.jrxml";
//    
//    
//    String FundTotalGPpath="./src/Reports/GaranteedPensionAcount.jrxml";
//    String FundTotalMMpath="./src/Reports/MoneyMarketAccounts.jrxml";
//    String FundTotalBFpath="./src/Reports/BalanceFundAccounts.jrxml";
//    String FundTotalPPpath="./src/Reports/PersonalPensionAccounts.jrxml";
//    String FundTotalHOpath="./src/Reports/HomeOwnershipAccounts.jrxml";
//    
//    String MemberTransactionsPPpath="./src/Reports/PersonalPensionTransactionStatement.jrxml";
//    String MemberTransactionsMMpath="./src/Reports/MoneyMarketTransactionStatement.jrxml";
//    String MemberTransactionsHOpath="./src/Reports/HomeOwnershipTransactionStatement.jrxml";
//    String MemberTransactionsGPpath="./src/Reports/GersonalPensionTransactionStatement.jrxml";
//    String MemberTransactionsBFpath="./src/Reports/BalanceFundTransactionStatement.jrxml";
//    
//    String MemberAccountBalancesMMpath="./src/Reports/MoneyMarketAcountBalanceStatement.jrxml";
//    String MemberAccountBalancesBFpath="./src/Reports/BalanceFundAccountBalance.jrxml";
//    String MemberAccountBalancesHOpath="./src/Reports/HomeOwnershipAccoutBalanceStaatement.jrxml";
//    String MemberAccountBalancesPPpath="./src/Reports/PersonalPensionAccountBalanceStatement.jrxml";
//    String MemberAccountBalancesGPpath="./src/Reports/GaranteedPensionAccountBalanceStatement.jrxml";
//    
    
   
    
   
    
   
    
    
    
     
   
    
    
   
    public static String getPass() {
		return pass;
	}



	public static void setPass(String pass) {
		Back_Office_ModuleController.pass = pass;
	}

	Boolean modeOfPayment=false;
    Boolean modeOfPaymentTD=false;
    Boolean fullReport=true;
    
    @FXML
    private Button SetBF;
   @FXML
    private TextField buyPriceBF = new TextField();
    @FXML
    private TextField sellPriceBF = new TextField();
    @FXML
    private TextField AdminFeesBF = new TextField();
    @FXML
    private DatePicker DateBF= new DatePicker();
    @FXML
    private TextField setByUserNameBF = new TextField();
    
    @FXML
    private MenuBar myMenuBar= new MenuBar();
    
    @FXML
    private DatePicker DateMM= new DatePicker();
    @FXML
    private TextField GeneralRateMM = new TextField();
     @FXML
    private TextField setByUserNameMM = new TextField();
     
     
    @FXML
    private TextField GeneralRateHO = new TextField();
    @FXML
    private DatePicker DateHO= new DatePicker();
    @FXML
    private TextField setByUserNameHO = new TextField();
     
     
    @FXML
    private TextField GeneralRateGP = new TextField();
    @FXML
    private DatePicker DateGP= new DatePicker();
     @FXML
    private TextField setByUserNameGP = new TextField();
     
     
    private TextField GeneralRatePP = new TextField();
    @FXML
    private DatePicker DatePP= new DatePicker();
    @FXML
    private TextField setByUserNamePP = new TextField();
   
    @FXML
    private ComboBox<String> chooseTable= new ComboBox<>();
    @FXML
   public CheckBox EditTableView= new CheckBox();
    @FXML
    private Button RefreshTable= new Button();
    @FXML
    private TableView<ObservableList> MainTable= new TableView<>();
    @FXML
    private ComboBox<String> chooseReport= new ComboBox<>();
    EditableCell edit = new EditableCell();

    @FXML
    private TextField ByyPricePP = new TextField();
    @FXML
    private TextField SellPricePP = new TextField();
    @FXML
    private DatePicker FromDate;
    @FXML
    private DatePicker ToDate;
    @FXML
    private DatePicker SpecificDate;
    @FXML
    private ComboBox<String> ModeOfPayment;
    @FXML
    private TextField MemberNumberField;
    @FXML
    private ComboBox<String> selectReportTD;
    @FXML
    private DatePicker sppecificDateTD;
    @FXML
    private DatePicker fromDateTD;
    @FXML
    private DatePicker ToDateTD;
    @FXML
    private ComboBox<String> ModeOfPaymentTD;
    @FXML
    private ComboBox<String> selectFundCS;
    @FXML
    private ComboBox<String> selectFundFT;
    private ComboBox<String> selectFundCAS;
    private TextField MemberNumberCAS;
    @FXML
    private DatePicker specificDateFT;
    @FXML
    private TextField memberNumberSearch;
   
    
    
    ObservableList<String> possibleNames = FXCollections.observableArrayList();
    ObservableList<String> possibleMemberNumbers = FXCollections.observableArrayList();
    @FXML
    private Button setRateBtMM;
    @FXML
    private Button setRatebtHO;
    @FXML
    private Button setRateBTGP;
    @FXML
    private Button setPriceBTPP;
    @FXML
    private ComboBox<String> fundTransferSelection;
    
    @FXML
    private DatePicker toDateClientTransaction;
    
Stage newStage;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    	
    	newStage = new Stage();
         connect = javaconnect.connectDb1();
                   String sql= "select fullName,memberNumber from personalinformation ";
                   PreparedStatement  statement2;
        try {
            statement2 = connect.prepareStatement(sql);
             ResultSet result2=statement2.executeQuery();
             while(result2.next()){
             possibleNames.add(result2.getString("fullName"));
             possibleMemberNumbers.add(result2.getString("memberNumber")+" "+result2.getString("fullName"));
             }
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        setByUserNameBF.setDisable(true);
        setByUserNameBF.setText(userName);
        setByUserNameMM.setDisable(true);
        setByUserNameMM.setText(userName);
        setByUserNameHO.setDisable(true);
        setByUserNameHO.setText(userName);
        setByUserNameGP.setDisable(true);
        setByUserNameGP.setText(userName);
        setByUserNamePP.setDisable(true);
        setByUserNamePP.setText(userName);
        AutoCompletionBinding<String> acb0 = TextFields.bindAutoCompletion(memberNumberSearch, possibleMemberNumbers);
        acb0.setOnAutoCompleted(e ->  memberNumberSearch.setText(checkForNumbers(e.getCompletion())));
               
        
        AutoCompletionBinding<String> acb1 = TextFields.bindAutoCompletion(MemberNumberField, possibleMemberNumbers);
        acb1.setOnAutoCompleted(e ->  MemberNumberField.setText(checkForNumbers(e.getCompletion())));
         
        fundTransferSelection.getItems().addAll("UnitTrustTransfers","PensionFundsTransfers");
        fundTransferSelection.setValue("UnitTrustTransfers");
        
        chooseTable.getItems().addAll("balacefundaccounts","balancefundwithdrawalaccouts"
                ,"garanteedpensionaccounts","garanteedpensionrates","homeownershipaccounts","homeownershipsetrates"
                ,"moneymarketaccounts","moneymarketsetrate","balancefundsetprices","personalpensionpurchase","personalpensionsetrates");
        chooseTable.setValue("moneymarketaccounts");
        
         //ModeOfPayment.getItems().addAll("M-Pesa","None","Cheque","KCB","Barclays","Standard Chartered","National Bank","K-Rep");
        ModeOfPayment.setValue("None");
        
        ModeOfPaymentTD.getItems().addAll("M-PESA","None","KCB","Barclays","Standard Chartered","National Bank","K-Rep");
        ModeOfPaymentTD.setValue("None");
        
        chooseReport.getItems().addAll("balancefundwithdrawal","moneymarketwithdrawal",
                "garanteedpensionwithdrawals","homeownershipwithdrawal","personalpensionwithdrawal");
        chooseReport.setValue("balancefundwithdrawal");
        
        
        selectReportTD.getItems().addAll("moneymarketdeposit","garanteedpensiondeposit","homeownershipdeposit",
                "personalpensiondeposit","balancefundpurchase");
        selectReportTD.setValue("moneymarketdeposit");
        
        selectFundCS.getItems().addAll("balancefund","moneymarket","garanteedpension","homeownership",
                "personalpension");
        selectFundCS.setValue("balancefund");
        
        selectFundFT.getItems().addAll("balacefundaccounts","garanteedpensionaccounts","homeownershipaccounts",
               "moneymarketaccounts","personalpensionpurchase");
        selectFundFT.setValue("moneymarketaccounts");
       /* EditTableView.setDisable(true);*/
       buyPriceBF.setDisable(true);
       AdminFeesBF.setDisable(true);
       ByyPricePP.setDisable(true);
        
    }    
    
    
    public Integer getLastTransactionNumber(String FundType){
    		int transnumber=0;
    	if(FundType.equals("Balanced Fund")){
         
         connect=JavaFirebirdconnect.connectDb();
             try{
             String sql="SELECT NAV_ID FROM NAVS order by NAV_DATE DESC ";
             statement=connect.prepareStatement(sql,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
             result=statement.executeQuery();
             if(result.next()){
               
            	 transnumber=result.getInt("NAV_ID");
       
                 
             }

             }catch(Exception e){
                 Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, e);
             Alert alert2= new Alert(Alert.AlertType.ERROR);
             alert2.setContentText(e.toString());
             alert2.showAndWait();

             }
    	}else if(FundType.equals("Personal Pension")){
    		  connect=JavaFirebirdconnect.connectDb1();
              try{
              String sql="SELECT NAV_ID FROM NAVS order by NAV_DATE DESC ";
              statement=connect.prepareStatement(sql,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
              result=statement.executeQuery();
              if(result.next()){
                
             	 transnumber=result.getInt("NAV_ID");
        
                  
              }

              }catch(Exception e){
                  Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, e);
              Alert alert2= new Alert(Alert.AlertType.ERROR);
              alert2.setContentText(e.toString());
              alert2.showAndWait();

              }
    		
    	}
             System.out.println("Last transactionNumber :: "+ transnumber++);
 
 return transnumber++;
 
 }

    
    public void fetchBalanceFundData(BalanceFundSetPrices price){
        price.setBuyPrice(Double.parseDouble(buyPriceBF.getText()));
        price.setSellPrice(Double.parseDouble(sellPriceBF.getText()));
        price.setAdminFees(Double.parseDouble(AdminFeesBF.getText()));
        price.setSetOnDate(DateBF.getValue());
        price.setSetByUserName(userName);
        try {
            updatecurrentPriceBP(Double.parseDouble(sellPriceBF.getText()));
        } catch (SQLException ex) {
            Logger.getLogger(Back_Office_ModuleController.class.getName()).log(Level.SEVERE, null, ex);
        }
        LocalDatePersistenceConverter date12= new LocalDatePersistenceConverter();
        
        connect=JavaFirebirdconnect.connectDb();
        String sql1="INSERT INTO NAVS (NAV_DATE,SECURITY_CODE,AMOUNT,ADM_FEE,P_PRICE,STAFFNAME,NAV_ID) VALUES (?, ?, ?, ?, ?, ?, ?);";
      
        
        PreparedStatement preparedStatement;
    	try {
    		
		    	preparedStatement = connect.prepareStatement(sql1);
		    	preparedStatement.setTimestamp(1, date12.convertToTimestamp(date12.convertToDatabaseColumn(DateBF.getValue())));
     	        preparedStatement.setString(2, "001");
    		    preparedStatement.setDouble(3,Double.parseDouble(sellPriceBF.getText()));
     		    preparedStatement.setDouble(4,Double.parseDouble(AdminFeesBF.getText()));
    		    preparedStatement.setDouble(5,Double.parseDouble(buyPriceBF.getText()));
    		    preparedStatement.setString(6,  userName);
    		    preparedStatement.setInt(7,getLastTransactionNumber("Balanced Fund"));
    		    preparedStatement .executeUpdate();
    	} catch (SQLException e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	}
        
    
    }
    public void fetchMoneyMarketData(MoneyMarketSetRate rate){
    
        rate.setGeneralRate(Double.parseDouble(GeneralRateMM.getText()));
        rate.setSetOnDate(DateMM.getValue());
        rate.setSetByUserName(userName);
     
    }
    public void fetchHomeOwnershipData(HomeOwnershipSetRates rate){
        rate.setGeneralRate(Double.parseDouble(GeneralRateHO.getText()));
        rate.setSetOnDate(DateHO.getValue());
        rate.setSetByUserName(userName);
    }
    public void fetchGaranteedPensionData(GaranteedPensionRates rate){
        rate.setGeneralRate(Double.parseDouble(GeneralRateGP.getText()));
        rate.setSetOnDate(DateGP.getValue());
        rate.setSetByUserName(userName);
    
    }
    public void fetchPersonalPensionData(PersonalPensionSetRates rate){
        rate.setBuyPrice(Double.parseDouble(ByyPricePP.getText()));
        rate.setSellPrice(Double.parseDouble(SellPricePP.getText()));
        rate.setSetOnDate(DatePP.getValue());
        rate.setSetByUserName(userName);
        try {
            updatecurrentPricePP(Double.parseDouble(SellPricePP.getText()));
        } catch (SQLException ex) {
            Logger.getLogger(Back_Office_ModuleController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
LocalDatePersistenceConverter date12= new LocalDatePersistenceConverter();
        
        connect=JavaFirebirdconnect.connectDb1();
        String sql1="INSERT INTO NAVS (NAV_DATE,SECURITY_CODE,AMOUNT,ADM_FEE,P_PRICE,STAFFNAME,NAV_ID) VALUES (?, ?, ?, ?, ?, ?, ?);";
      
        
        PreparedStatement preparedStatement;
    	try {
    		
		    	preparedStatement = connect.prepareStatement(sql1);
		    	preparedStatement.setTimestamp(1, date12.convertToTimestamp(date12.convertToDatabaseColumn(DatePP.getValue())));
     	        preparedStatement.setString(2, "003");
    		    preparedStatement.setDouble(3,Double.parseDouble(SellPricePP.getText()));
     		    preparedStatement.setDouble(4,0.00);
    		    preparedStatement.setDouble(5,Double.parseDouble(ByyPricePP.getText()));
    		    preparedStatement.setString(6,  userName);
    		    preparedStatement.setInt(7,getLastTransactionNumber("Personal Pension"));
    		    preparedStatement .executeUpdate();
    	} catch (SQLException e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	}
        
    
    
    }
    
    
    

    @FXML
    private void setBalanceFundData(ActionEvent event) {
        BalanceFundSetPrices price = new BalanceFundSetPrices();
         HibernateConnector connector= new HibernateConnector();
        fetchBalanceFundData(price);
        connector.MakeHibernateTransaction(price);
         Alert alert2= new Alert(Alert.AlertType.INFORMATION);
         alert2.setContentText("Data Saved Successfully");
         alert2.showAndWait();
         sellPriceBF.setText(null);
    }

    @FXML
    private void SetMoneyMarketData(ActionEvent event) {
        MoneyMarketSetRate rate = new MoneyMarketSetRate();
        HibernateConnector connector= new HibernateConnector();
         fetchMoneyMarketData(rate);
         connector.MakeHibernateTransaction(rate);
         Alert alert2= new Alert(Alert.AlertType.INFORMATION);
         alert2.setContentText("Data Saved Successfully");
         alert2.showAndWait();
         GeneralRateMM.setText(null);
    }

    @FXML
    private void setHomeOwnershipData(ActionEvent event) {
        HomeOwnershipSetRates rates= new HomeOwnershipSetRates();
         HibernateConnector connector= new HibernateConnector();
        fetchHomeOwnershipData(rates);
        connector.MakeHibernateTransaction(rates);
        Alert alert2= new Alert(Alert.AlertType.INFORMATION);
        alert2.setContentText("Data Saved Successfully");
        alert2.showAndWait();
        GeneralRateHO.setText(null);
    }

    @FXML
    private void setGaranteedPensionData(ActionEvent event) {
        GaranteedPensionRates rates = new GaranteedPensionRates();
        HibernateConnector connector= new HibernateConnector();
        fetchGaranteedPensionData(rates);
        connector.MakeHibernateTransaction(rates);
        Alert alert2= new Alert(Alert.AlertType.INFORMATION);
        alert2.setContentText("Data Saved Successfully");
        alert2.showAndWait();
        GeneralRateGP.setText(null);
        
    }

    @FXML
    private void setPersonalPensionData(ActionEvent event) {
        PersonalPensionSetRates rate= new PersonalPensionSetRates();
         HibernateConnector connector= new HibernateConnector();
        fetchPersonalPensionData(rate);
        connector.MakeHibernateTransaction(rate);
        Alert alert2= new Alert(Alert.AlertType.INFORMATION);
        alert2.setContentText("Data Saved Successfully");
        alert2.showAndWait();
        SellPricePP.setText(null);
    }
    public void updatecurrentPriceBP(double price) throws SQLException{
      connect=javaconnect.connectDb();
        String sql="select * FROM `current price`";
        
        statement = connect.prepareStatement(sql,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
        ResultSet rs = statement.executeQuery();
        
        
        while(rs.next()){
            rs.updateDouble("BalanceFundCurrentPrice", price);
            rs.updateRow();
            
        }
        
         
    }
    
    public void updatecurrentPricePP(double price) throws SQLException{
      connect=javaconnect.connectDb();
        String sql="select * FROM `current price`";
        
        statement = connect.prepareStatement(sql,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
        ResultSet rs = statement.executeQuery();
        
        
        while(rs.next()){
            rs.updateDouble("personalPension Current Price", price);
            rs.updateRow();
            
        }
        
         
    }

    @FXML
    private void ChooseTableView(ActionEvent event) {
        
         String selectedTable = chooseTable.getValue();
          ResultsetTableDisplay display = new ResultsetTableDisplay(MainTable);
           String sql="select * from ";
           sql=sql.concat(selectedTable);
           display.executeSqlStatement(sql);
           EditTableView.setSelected(false);
           MainTable.setEditable(false);
    }

    @FXML
    private void EditTable(ActionEvent event) {
        Integer memberNumber;
         if(EditTableView.isSelected()){
          String selectedTable = chooseTable.getValue();
          
          String sql="select * from ";
           sql=sql.concat(selectedTable);
                   
            edit.setTableEditable(MainTable,sql,selectedTable,Integer.valueOf(memberNumberSearch.getText()).toString());
             
                 
             
        
        }else{
        edit.setTableEditableFalse(MainTable);
        
        }
    }

    
    @FXML
    private void refreshTable(ActionEvent event) {
        
        String selectedTable = chooseTable.getValue();
         ResultsetTableDisplay display= new ResultsetTableDisplay(MainTable);
           String sql="select * from ";
           sql=sql.concat(selectedTable);
           display.executeSqlStatement(sql);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("Table Refreshed  !");
              alert.showAndWait();
              
              Platform.runLater(new Runnable() {
			        @Override
			        public void run() {
			         EditTableView.setSelected(false);
			        }
			    });
             
    }

    @FXML
    private void moveToFrontOffice(ActionEvent event) {
    	
			System.out.println("password from back office: "+pass);
			 try {
				 FXMLDocumentController.setUserName(userName);
			     FXMLDocumentController.setUserType(userType); 
			     FXMLDocumentController.setPassword(pass);
			    Parent  root;
			     root = FXMLLoader.load(getClass().getResource("/zimele_information_management_system/Zimele_Front_Office.fxml"));
			    Scene scene = new Scene(root);
			     scene.getStylesheets().add(STYLESHEET_CASPIAN);
			     Stage stage =(Stage) myMenuBar.getScene().getWindow();
			  /* Stage stage =  (Stage)((Node)event.getSource()).getScene().getWindow();*/
			stage.setScene(scene);
			stage.show();
			
			
			
			} catch (IOException ex) {
			    Logger.getLogger(Back_Office_ModuleController.class.getName()).log(Level.SEVERE, null, ex);
			}
			
		
        
    }

  
    @FXML
    private void MoveToAdmin(ActionEvent event) {
		 try {
			  System.out.println("UserName : "+userName);
			   System.out.println("passwors : "+pass);
			   System.out.println("userType : "+userType);
			 if(Authenticate(userName,pass,userType)){
				 Zimele_AdminController.setUserName(userName);
	          		Zimele_AdminController.setUserType("Admin");
	          		Zimele_AdminController.setPass(pass);
	            Parent  root;
	             root = FXMLLoader.load(getClass().getResource("/Zimele_Admin/Zimele_Admin.fxml"));
	            Scene scene = new Scene(root);
	             scene.getStylesheets().add(STYLESHEET_CASPIAN);
	             Stage stage =(Stage) myMenuBar.getScene().getWindow();
	          /* Stage stage =  (Stage)((Node)event.getSource()).getScene().getWindow();*/
	        stage.setScene(scene);
	        stage.show();
	        

			 }else{
			       Alert alert2= new Alert(Alert.AlertType.INFORMATION);
			       alert2.setContentText("Access Denied .You cant access back office !");
			       alert2.showAndWait();
			       }
			
	        
	        } catch (IOException ex) {
	            Logger.getLogger(Back_Office_ModuleController.class.getName()).log(Level.SEVERE, null, ex);
	        } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        
		
		
	}
    @FXML
    private void totalWithdrawalReport(ActionEvent event) {
            InputStream TotalWithdrawalsBFpath=getClass().getResourceAsStream("/Reports/BalanceFundWithdrawal.jrxml");
            InputStream TotalWithdrawalsMMpath=getClass().getResourceAsStream("/Reports/MoneyMarketWithdrawal.jrxml");
            InputStream TotalWithdrawalsHOpath=getClass().getResourceAsStream("/Reports/HomeOwnershipWithdrawals.jrxml");
            InputStream TotalWithdrawalsGPpath=getClass().getResourceAsStream("/Reports/GaranteedPensionWithdrawals.jrxml");
            InputStream TotalWithdrawalsPPpath=getClass().getResourceAsStream("/Reports/PersonalPensionWithdrawal.jrxml");
             
       
             if("balancefundwithdrawal".equals(chooseReport.getValue())){
 
                     if(SpecificDate.getValue() != null){
                  String sortBySpecificDateBF="SELECT * FROM balancefundwithdrawal WHERE  DateOfWithdrawal='";
                    sortBySpecificDateBF=sortBySpecificDateBF.concat(SpecificDate.getValue().toString());sortBySpecificDateBF=sortBySpecificDateBF.concat("'");
                    runReport(TotalWithdrawalsBFpath,sortBySpecificDateBF);
                    
                 }else if(FromDate.getValue() !=null){
                     String sortByDateRangeBF="SELECT * FROM balancefundwithdrawal WHERE DateOfWithdrawal >= '"; 
                    sortByDateRangeBF=sortByDateRangeBF.concat(FromDate.getValue().toString());sortByDateRangeBF=sortByDateRangeBF.concat("'");
                    sortByDateRangeBF=sortByDateRangeBF.concat(" AND DateOfWithdrawal<='");sortByDateRangeBF=sortByDateRangeBF.concat(ToDate.getValue().toString());
                    sortByDateRangeBF=sortByDateRangeBF.concat("'");
                    System.out.println(sortByDateRangeBF);
                    runReport(TotalWithdrawalsBFpath,sortByDateRangeBF);
                     
                 }

             
             }else if("moneymarketwithdrawal".equals(chooseReport.getValue())){
                if(SpecificDate.getValue() != null){
                            String sortBySpecificDateMM="SELECT * FROM moneymarketwithdrawal WHERE  DateOfWithdrawal='";
                    sortBySpecificDateMM=sortBySpecificDateMM.concat(SpecificDate.getValue().toString());
                    sortBySpecificDateMM=sortBySpecificDateMM.concat("'");                    
                    runReport(TotalWithdrawalsMMpath,sortBySpecificDateMM);
                   
                 }else if(FromDate.getValue() !=null){
                      String sortByDateRangeMM="SELECT * FROM moneymarketwithdrawal WHERE  DateOfWithdrawal >='";
                        sortByDateRangeMM=sortByDateRangeMM.concat(FromDate.getValue().toString());sortByDateRangeMM=sortByDateRangeMM.concat("'");
                        sortByDateRangeMM=sortByDateRangeMM.concat(" AND DateOfWithdrawal<='");sortByDateRangeMM=sortByDateRangeMM.concat(ToDate.getValue().toString());
                        sortByDateRangeMM=sortByDateRangeMM.concat("'");
                        runReport(TotalWithdrawalsMMpath,sortByDateRangeMM);
                     
                 }

             
             }else if("garanteedpensionwithdrawals".equals(chooseReport.getValue())){

                     if(SpecificDate.getValue() != null){
                          String sortBySpecificDateGP="select * from garanteedpensionwithdrawals WHERE DateOfWithdrawal='";
                    sortBySpecificDateGP=sortBySpecificDateGP.concat(SpecificDate.getValue().toString());
                    sortBySpecificDateGP=sortBySpecificDateGP.concat("'");
                    runReport(TotalWithdrawalsGPpath,sortBySpecificDateGP);
                         
                 }else if(FromDate.getValue() !=null){
                     String sortByDateRangeGP="SELECT * FROM garanteedpensionwithdrawals WHERE  DateOfWithdrawal >='";
                    sortByDateRangeGP=sortByDateRangeGP.concat(FromDate.getValue().toString());sortByDateRangeGP=sortByDateRangeGP.concat("'");
                    sortByDateRangeGP=sortByDateRangeGP.concat(" AND DateOfWithdrawal<='");sortByDateRangeGP=sortByDateRangeGP.concat(ToDate.getValue().toString());
                    sortByDateRangeGP=sortByDateRangeGP.concat("'");
                    runReport(TotalWithdrawalsGPpath,sortByDateRangeGP);
                 }

             
             }else if("homeownershipwithdrawal".equals(chooseReport.getValue())){
 
                     if(SpecificDate.getValue() != null){
                    String sortBySpecificDateHO="select * from homeownershipwithdrawal where DateOfWithdrawal='";
                    sortBySpecificDateHO=sortBySpecificDateHO.concat(SpecificDate.getValue().toString());
                    sortBySpecificDateHO=sortBySpecificDateHO.concat("'");
                    runReport(TotalWithdrawalsHOpath,sortBySpecificDateHO);
                 }else if(FromDate.getValue() !=null){
                    String sortByDateRangeHO="SELECT * FROM homeownershipwithdrawal WHERE  DateOfWithdrawal >='";
                    sortByDateRangeHO=sortByDateRangeHO.concat(FromDate.getValue().toString());sortByDateRangeHO=sortByDateRangeHO.concat("'");
                    sortByDateRangeHO=sortByDateRangeHO.concat(" AND DateOfWithdrawal<='");sortByDateRangeHO=sortByDateRangeHO.concat(ToDate.getValue().toString());
                    sortByDateRangeHO=sortByDateRangeHO.concat("'");
                    runReport(TotalWithdrawalsHOpath,sortByDateRangeHO);
                 
                 }

             
             }else if("personalpensionwithdrawal".equals(chooseReport.getValue())){

                     if(SpecificDate.getValue() != null){
                    String sortBySpecificDatePP="select * from personalpensionwithdrawal WHERE DateOfWithdrawal='";
                    sortBySpecificDatePP=sortBySpecificDatePP.concat(SpecificDate.getValue().toString());
                    sortBySpecificDatePP=sortBySpecificDatePP.concat("'");
                    runReport(TotalWithdrawalsPPpath,sortBySpecificDatePP);
                 }else if(FromDate.getValue() !=null){
                    String sortByDateRangePP="SELECT * FROM personalpensionwithdrawal WHERE  DateOfWithdrawal >='";
                    sortByDateRangePP=sortByDateRangePP.concat(FromDate.getValue().toString());sortByDateRangePP=sortByDateRangePP.concat("'");
                    sortByDateRangePP=sortByDateRangePP.concat(" AND DateOfWithdrawal<='");sortByDateRangePP=sortByDateRangePP.concat(ToDate.getValue().toString());
                    sortByDateRangePP=sortByDateRangePP.concat("'");
                     System.out.println(sortByDateRangePP);
                    runReport(TotalWithdrawalsPPpath,sortByDateRangePP);
                 }

             
             }
           
    }

    @FXML
    private void totalDepositReport(ActionEvent event) {
    InputStream TotalDepositsMMpath=getClass().getResourceAsStream("/Reports/MoneyMarketDeposits.jrxml");
    InputStream TotalDepositsBFpath=getClass().getResourceAsStream("/Reports/BalanceFundPurchases.jrxml");
    InputStream TotalDepositsHOpath=getClass().getResourceAsStream("/Reports/HomeOwnershipDeposit.jrxml");
    InputStream TotalDepositsGPpath=getClass().getResourceAsStream("/Reports/GaranteeedPensionDeposit.jrxml");
    InputStream TotalDepositsPPpath=getClass().getResourceAsStream("/Reports/PersonalPensionPurchases.jrxml");
        
                if("moneymarketdeposit".equals(selectReportTD.getValue())){
                       if(sppecificDateTD.getValue() != null){
                        if(ModeOfPaymentTD.getValue()=="None"){
                    String sortBySpecificDateMM="SELECT * FROM moneymarketdeposit WHERE  DateOfDeposit='";
                    sortBySpecificDateMM=sortBySpecificDateMM.concat(sppecificDateTD.getValue().toString());
                    sortBySpecificDateMM=sortBySpecificDateMM.concat("'");
                     runReport(TotalDepositsMMpath,sortBySpecificDateMM);
                        }else{
                         String sortBySpecificDateMM="SELECT * FROM moneymarketdeposit WHERE  DateOfDeposit='";
                    sortBySpecificDateMM=sortBySpecificDateMM.concat(sppecificDateTD.getValue().toString());
                    sortBySpecificDateMM=sortBySpecificDateMM.concat("' AND modeOfPayment='"); sortBySpecificDateMM=sortBySpecificDateMM.concat(ModeOfPaymentTD.getValue()); sortBySpecificDateMM=sortBySpecificDateMM.concat("'");
                     runReport(TotalDepositsMMpath,sortBySpecificDateMM);
                        }
                 }else if(fromDateTD.getValue() !=null){
                     if(ModeOfPaymentTD.getValue()=="None"){ 
                    String sortByDateRangeMM="SELECT * FROM moneymarketdeposit WHERE  DateOfDeposit >='";
                    sortByDateRangeMM=sortByDateRangeMM.concat(fromDateTD.getValue().toString());sortByDateRangeMM=sortByDateRangeMM.concat("'");
                    sortByDateRangeMM=sortByDateRangeMM.concat(" AND DateOfDeposit<='");sortByDateRangeMM=sortByDateRangeMM.concat(ToDateTD.getValue().toString());
                    sortByDateRangeMM=sortByDateRangeMM.concat("'");
                    runReport(TotalDepositsMMpath,sortByDateRangeMM);
                     }else{
                     String sortByDateRangeMM="SELECT * FROM moneymarketdeposit WHERE  DateOfDeposit >='";
                    sortByDateRangeMM=sortByDateRangeMM.concat(fromDateTD.getValue().toString());sortByDateRangeMM=sortByDateRangeMM.concat("'");
                    sortByDateRangeMM=sortByDateRangeMM.concat(" AND DateOfDeposit<='");sortByDateRangeMM=sortByDateRangeMM.concat(ToDateTD.getValue().toString());
                    sortByDateRangeMM=sortByDateRangeMM.concat("' AND modeOfPayment='");  sortByDateRangeMM=sortByDateRangeMM.concat(ModeOfPaymentTD.getValue());  sortByDateRangeMM=sortByDateRangeMM.concat("'");
                    runReport(TotalDepositsMMpath,sortByDateRangeMM);
                     }
                 }

              }else if("garanteedpensiondeposit".equals(selectReportTD.getValue())){

                      if(sppecificDateTD.getValue() != null){
                          if(ModeOfPaymentTD.getValue()=="None"){
                      String sortBySpecificDateGP="SELECT * FROM garanteedpensiondeposit WHERE  DateOfDeposit ='";
                      sortBySpecificDateGP=sortBySpecificDateGP.concat(sppecificDateTD.getValue().toString());
                      sortBySpecificDateGP=sortBySpecificDateGP.concat("'");
                        runReport(TotalDepositsGPpath,sortBySpecificDateGP);
                          }else{
                          String sortBySpecificDateGP="SELECT * FROM garanteedpensiondeposit WHERE  DateOfDeposit ='";
                      sortBySpecificDateGP=sortBySpecificDateGP.concat(sppecificDateTD.getValue().toString());
                      sortBySpecificDateGP=sortBySpecificDateGP.concat("' AND ModeOfPayment='"); sortBySpecificDateGP=sortBySpecificDateGP.concat(ModeOfPaymentTD.getValue()); sortBySpecificDateGP=sortBySpecificDateGP.concat("'");
                        runReport(TotalDepositsGPpath,sortBySpecificDateGP);
                          
                          }
                 }else if(fromDateTD.getValue() !=null){
                      if(ModeOfPaymentTD.getValue()=="None"){
                        String sortByDateRangeGP="SELECT * FROM garanteedpensiondeposit WHERE  DateOfDeposit >='";
                        sortByDateRangeGP=sortByDateRangeGP.concat(fromDateTD.getValue().toString());sortByDateRangeGP=sortByDateRangeGP.concat("'");
                        sortByDateRangeGP=sortByDateRangeGP.concat(" AND DateOfDeposit<='");sortByDateRangeGP=sortByDateRangeGP.concat(ToDateTD.getValue().toString());
                        sortByDateRangeGP=sortByDateRangeGP.concat("'");
                        runReport(TotalDepositsGPpath,sortByDateRangeGP);
                      }else{
                       String sortByDateRangeGP="SELECT * FROM garanteedpensiondeposit WHERE  DateOfDeposit >='";
                        sortByDateRangeGP=sortByDateRangeGP.concat(fromDateTD.getValue().toString());sortByDateRangeGP=sortByDateRangeGP.concat("'");
                        sortByDateRangeGP=sortByDateRangeGP.concat(" AND DateOfDeposit<='");sortByDateRangeGP=sortByDateRangeGP.concat(ToDateTD.getValue().toString());
                        sortByDateRangeGP=sortByDateRangeGP.concat("' AND ModeOfPayment='");sortByDateRangeGP=sortByDateRangeGP.concat(ModeOfPaymentTD.getValue());sortByDateRangeGP=sortByDateRangeGP.concat("'");
                        runReport(TotalDepositsGPpath,sortByDateRangeGP);
                      }
                 }

              
              }else if("homeownershipdeposit".equals(selectReportTD.getValue())){
                 
                      if(sppecificDateTD.getValue() != null){
                          if(ModeOfPaymentTD.getValue()=="None"){
                    String sortBySpecificDateHO="SELECT * FROM homeownershipdeposit WHERE  DateOfDeposit ='";
                    sortBySpecificDateHO=sortBySpecificDateHO.concat(sppecificDateTD.getValue().toString());
                    sortBySpecificDateHO=sortBySpecificDateHO.concat("'");
                    runReport(TotalDepositsHOpath,sortBySpecificDateHO);
                          }else{
                          String sortBySpecificDateHO="SELECT * FROM homeownershipdeposit WHERE  DateOfDeposit ='";
                    sortBySpecificDateHO=sortBySpecificDateHO.concat(sppecificDateTD.getValue().toString());
                    sortBySpecificDateHO=sortBySpecificDateHO.concat("' AND ModeOfPayment='"); sortBySpecificDateHO=sortBySpecificDateHO.concat(ModeOfPaymentTD.getValue()); sortBySpecificDateHO=sortBySpecificDateHO.concat("'");
                    runReport(TotalDepositsHOpath,sortBySpecificDateHO);
                          }
                 }else if(fromDateTD.getValue() !=null){
                      if(ModeOfPaymentTD.getValue()=="None"){
                    String sortByDateRangeHO="SELECT * FROM homeownershipdeposit WHERE  DateOfDeposit >='";
                    sortByDateRangeHO=sortByDateRangeHO.concat(fromDateTD.getValue().toString());sortByDateRangeHO=sortByDateRangeHO.concat("'");
                    sortByDateRangeHO=sortByDateRangeHO.concat(" AND DateOfDeposit<='");sortByDateRangeHO=sortByDateRangeHO.concat(ToDateTD.getValue().toString());
                    sortByDateRangeHO=sortByDateRangeHO.concat("'");
                    runReport(TotalDepositsHOpath,sortByDateRangeHO);
                      }else{
                     String sortByDateRangeHO="SELECT * FROM homeownershipdeposit WHERE  DateOfDeposit >='";
                    sortByDateRangeHO=sortByDateRangeHO.concat(fromDateTD.getValue().toString());sortByDateRangeHO=sortByDateRangeHO.concat("'");
                    sortByDateRangeHO=sortByDateRangeHO.concat(" AND DateOfDeposit<='");sortByDateRangeHO=sortByDateRangeHO.concat(ToDateTD.getValue().toString());
                    sortByDateRangeHO=sortByDateRangeHO.concat("' AND ModeOfPayment='"); sortByDateRangeHO=sortByDateRangeHO.concat(ModeOfPaymentTD.getValue()); sortByDateRangeHO=sortByDateRangeHO.concat("'");
                    runReport(TotalDepositsHOpath,sortByDateRangeHO);
                      }
                 }

          
              }else if("personalpensiondeposit".equals(selectReportTD.getValue())){

                      if(sppecificDateTD.getValue() != null){
                           if(ModeOfPaymentTD.getValue()=="None"){
                    String sortBySpecificDatePP="SELECT * FROM personalpensiondeposit WHERE  DateOfDeposit ='";
                    sortBySpecificDatePP=sortBySpecificDatePP.concat(sppecificDateTD.getValue().toString());
                    sortBySpecificDatePP=sortBySpecificDatePP.concat("'");  
                    runReport(TotalDepositsPPpath,sortBySpecificDatePP);
                           }else{
                    String sortBySpecificDatePP="SELECT * FROM personalpensiondeposit WHERE  DateOfDeposit ='";
                    sortBySpecificDatePP=sortBySpecificDatePP.concat(sppecificDateTD.getValue().toString());
                    sortBySpecificDatePP=sortBySpecificDatePP.concat("' AND ModeOfPayment='");  sortBySpecificDatePP=sortBySpecificDatePP.concat(ModeOfPaymentTD.getValue());sortBySpecificDatePP=sortBySpecificDatePP.concat("'");   
                    runReport(TotalDepositsPPpath,sortBySpecificDatePP);
                           }
                 }else if(fromDateTD.getValue() !=null){
                     if(ModeOfPaymentTD.getValue()=="None"){
                    String sortByDateRangePP="SELECT * FROM personalpensiondeposit WHERE  DateOfDeposit >='";
                    sortByDateRangePP=sortByDateRangePP.concat(fromDateTD.getValue().toString());sortByDateRangePP=sortByDateRangePP.concat("'");
                    sortByDateRangePP=sortByDateRangePP.concat(" AND DateOfDeposit<='");sortByDateRangePP=sortByDateRangePP.concat(ToDateTD.getValue().toString());
                    sortByDateRangePP=sortByDateRangePP.concat("'");
                    runReport(TotalDepositsPPpath,sortByDateRangePP);
                     }else{
                      String sortByDateRangePP="SELECT * FROM personalpensiondeposit WHERE  DateOfDeposit >='";
                    sortByDateRangePP=sortByDateRangePP.concat(fromDateTD.getValue().toString());sortByDateRangePP=sortByDateRangePP.concat("'");
                    sortByDateRangePP=sortByDateRangePP.concat(" AND DateOfDeposit<='");sortByDateRangePP=sortByDateRangePP.concat(ToDateTD.getValue().toString());
                    sortByDateRangePP=sortByDateRangePP.concat("' AND ModeOfPayment='"); sortByDateRangePP=sortByDateRangePP.concat(ModeOfPaymentTD.getValue()); sortByDateRangePP=sortByDateRangePP.concat("'");
                    runReport(TotalDepositsPPpath,sortByDateRangePP);
                     }
                 }

              
              }else if("balancefundpurchase".equals(selectReportTD.getValue())){

                   if(sppecificDateTD.getValue() != null){
                         if(ModeOfPaymentTD.getValue()=="None"){
                    String sortBySpecificDateBF="SELECT * FROM balancefundpurchase WHERE  DateOfPurchase ='";
                    sortBySpecificDateBF=sortBySpecificDateBF.concat(sppecificDateTD.getValue().toString());
                    sortBySpecificDateBF=sortBySpecificDateBF.concat("'");  
                    runReport(TotalDepositsBFpath,sortBySpecificDateBF);
                         }else{
                         String sortBySpecificDateBF="SELECT * FROM balancefundpurchase WHERE  DateOfPurchase ='";
                    sortBySpecificDateBF=sortBySpecificDateBF.concat(sppecificDateTD.getValue().toString());
                    sortBySpecificDateBF=sortBySpecificDateBF.concat("' ModeOfPaymment='");sortBySpecificDateBF=sortBySpecificDateBF.concat(ModeOfPaymentTD.getValue());sortBySpecificDateBF=sortBySpecificDateBF.concat("'");  
                    runReport(TotalDepositsBFpath,sortBySpecificDateBF);
                         
                         }
                 }else if(fromDateTD.getValue() !=null){
                      if(ModeOfPaymentTD.getValue()=="None"){
                    String sortByDateRangeBF="SELECT * FROM balancefundpurchase WHERE  DateOfPurchase >='";
                    sortByDateRangeBF=sortByDateRangeBF.concat(fromDateTD.getValue().toString());sortByDateRangeBF=sortByDateRangeBF.concat("'");
                    sortByDateRangeBF=sortByDateRangeBF.concat(" AND DateOfPurchase<='");sortByDateRangeBF=sortByDateRangeBF.concat(ToDateTD.getValue().toString());
                    sortByDateRangeBF=sortByDateRangeBF.concat("'");
                    runReport(TotalDepositsBFpath,sortByDateRangeBF);
                      }else{
                      String sortByDateRangeBF="SELECT * FROM balancefundpurchase WHERE  DateOfPurchase >='";
                    sortByDateRangeBF=sortByDateRangeBF.concat(fromDateTD.getValue().toString());sortByDateRangeBF=sortByDateRangeBF.concat("'");
                    sortByDateRangeBF=sortByDateRangeBF.concat(" AND DateOfPurchase<='");sortByDateRangeBF=sortByDateRangeBF.concat(ToDateTD.getValue().toString());
                    sortByDateRangeBF=sortByDateRangeBF.concat("' ModeOfPaymment='"); sortByDateRangeBF=sortByDateRangeBF.concat(ModeOfPaymentTD.getValue()); sortByDateRangeBF=sortByDateRangeBF.concat("'");
                    runReport(TotalDepositsBFpath,sortByDateRangeBF);
                      }
                 }

              }
     
    }

    @FXML
    private void viewClientStatement(ActionEvent event) {
    	/*
      	LocalDatePersistenceConverter date12= new LocalDatePersistenceConverter();
   	 java.sql.Date dbSqlCurrentDate22 = null;
   	 UpdateDataMoneyMarket mk = new  UpdateDataMoneyMarket();
   	 UpdateDataGaranteedPension gp= new UpdateDataGaranteedPension();
     connect=javaconnect.connectDb();
   
        
   

     try {
		
	    	  if("moneymarket".equals(selectFundCS.getValue())){
	    		   String sql1="SELECT * FROM `moneymarketaccounts` WHERE `MemberNumber`='";
	    	        sql1=sql1.concat(MemberNumberField.getText());
	    	        sql1=sql1.concat("'");
	    		  statement = connect.prepareStatement(sql1);
	    			ResultSet rs1 = statement.executeQuery();
	    		      if(rs1.next()){
	    		      dbSqlCurrentDate22 = rs1.getDate("Date & Time");
	    		      if(dbSqlCurrentDate22.compareTo(date12.convertToDatabaseColumn(LocalDate.now()))<0){
	    		    	    mk.makeInterestUpdate(MemberNumberField.getText());
	    		    	  
	    		      }
	    		  
	    		
	           }else if("garanteedpension".equals(selectFundCS.getValue())){
	        	     String sql11="SELECT * FROM `garanteedpensionaccounts` WHERE `MemberNumber`='";
	        	     sql11=sql11.concat(MemberNumberField.getText());
	        	     sql11=sql11.concat("'");
	        	   statement = connect.prepareStatement(sql1);
	       		ResultSet rs = statement.executeQuery();
	       	      if(rs.next()){
	       	      dbSqlCurrentDate22 = rs.getDate("Date & Time");
	       	      if(dbSqlCurrentDate22.compareTo(date12.convertToDatabaseColumn(LocalDate.now()))<0){
	       	    	  
	       	        gp.makeInterestUpdate(MemberNumberField.getText());
	       	      }
	       	      }
	        	   
	             
	           }
	    	  
	    	  
	    	  
	      }
	     
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    	
    	*/
    	
    	LocalDatePersistenceConverter date12= new LocalDatePersistenceConverter();
   	 java.sql.Date dbSqlCurrentDate22 = null;
   	 UpdateDataMoneyMarket mk = new  UpdateDataMoneyMarket();
   	 UpdateDataGaranteedPension gp= new UpdateDataGaranteedPension();
     connect=javaconnect.connectDb();
     try {
 		
   	  if("moneymarket".equals(selectFundCS.getValue())){
   		  String sql1="SELECT * FROM `money_market_transaction_new` WHERE MEMBER_NO ='";
   	        sql1=sql1.concat(MemberNumberField.getText());
   	        sql1=sql1.concat("' AND `TRANS_TYPE` LIKE 'INTEREST' ORDER BY `TRANS_DATE1` DESC");
   	     statement = connect.prepareStatement(sql1);
   	     ResultSet rs1 = statement.executeQuery(); 
   		  
   		 
   		      if(rs1.isBeforeFirst()){
   		    	  rs1.next();
   		    	  dbSqlCurrentDate22 = rs1.getDate("TRANS_DATE1");
   		    	     
   		      System.out.println("Trying to work out"); 
   		      if(dbSqlCurrentDate22.compareTo(date12.convertToDatabaseColumn(LocalDate.now()))<0){
   		    	  System.out.println("Trying to work out222222222"); 
   		    	  mk.makeInterestUpdate(MemberNumberField.getText());
   		      }   
   		    	  
   		      }else{
   		    	  
   		    	 System.out.println("STATEMENT NEVER UPDATED");
   		    	  String sql11="SELECT * FROM `money_market_transaction_new` WHERE MEMBER_NO ='";
   	    	        sql11=sql11.concat(MemberNumberField.getText());
   	    	        sql11=sql11.concat("' ORDER BY `TRANS_DATE1` ASC");
   	    	     statement = connect.prepareStatement(sql11);
   	    	     ResultSet rs11 = statement.executeQuery(); 
   	    	     System.out.println("query works");
   	    	     if(rs11.next()){
   	    	    	 System.out.println("resultset Not EMPTY"); 
      		    	  dbSqlCurrentDate22 = rs11.getDate("TRANS_DATE1");
      		    	     
      		      System.out.println("Trying to work out"); 
      		      if(dbSqlCurrentDate22.compareTo(date12.convertToDatabaseColumn(LocalDate.now()))<0){
      		    	  System.out.println("Trying to work out NO INTEREST"); 
      		    	  mk.makeInterestUpdate(MemberNumberField.getText());
      		    	    
      		    	  
      		      }
   	    	     
   		      }
   		      }
   		
          }else if("garanteedpension".equals(selectFundCS.getValue())){
       	   String sql11="SELECT * FROM `garanteedpensiontrans` WHERE MEMBER_NO ='";
  	        sql11=sql11.concat(MemberNumberField.getText());
  	        sql11=sql11.concat("' AND `TRANS_TYPE` LIKE 'INTEREST' ORDER BY `TRANS_DATE1` DESC");
       	   statement = connect.prepareStatement(sql11);
      		ResultSet rs = statement.executeQuery();
      	      if(rs.isBeforeFirst()){
      	    	  rs.next();
      	      dbSqlCurrentDate22 = rs.getDate("TRANS_DATE1");
      	      if(dbSqlCurrentDate22.compareTo(date12.convertToDatabaseColumn(LocalDate.now()))<0){
      	    	  
      	        gp.makeInterestUpdate(MemberNumberField.getText());
      	      }
      	      }else {
      	    	  
      	    	String sql111="SELECT * FROM `garanteedpensiontrans` WHERE MEMBER_NO ='";
      	    	sql111=sql111.concat(MemberNumberField.getText());
      	    	sql111=sql111.concat("'  ORDER BY `TRANS_DATE1` ASC");
           	   statement = connect.prepareStatement(sql111);
          		ResultSet rs11 = statement.executeQuery();
          	      if(rs11.next()){
          	      dbSqlCurrentDate22 = rs11.getDate("TRANS_DATE1");
          	      if(dbSqlCurrentDate22.compareTo(date12.convertToDatabaseColumn(LocalDate.now()))<0){
          	    	  
          	        gp.makeInterestUpdate(MemberNumberField.getText());
          	      }
          	      }
      	    	  
      	      }
       	   
            
          }
   	  
   
    
   
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    	
    	
    	
          InputStream MemberTransactionsPPpath1=getClass().getResourceAsStream("/Reports/OneTransReports/Personal_Pension_Statement.jrxml");
    InputStream MemberTransactionsMMpath1=getClass().getResourceAsStream("/Reports/OneTransReports/MoneyMarketAccountBalanceStatement.jrxml");
    InputStream MemberTransactionsHOpath1=getClass().getResourceAsStream("/Reports/OneTransReports/HomeOwnershipTransactionStatement.jrxml");
    InputStream MemberTransactionsGPpath1=getClass().getResourceAsStream("/Reports/OneTransReports/GaranteedPensionAccountBalanceStatement.jrxml");
    InputStream MemberTransactionsBFpath1=getClass().getResourceAsStream("/Reports/OneTransReports/BalanceFundStatement.jrxml");
    
        /*String balancedFund="SELECT p.PurchaseNumberBalanceFundPurchase,p.DateOfPurchase,p.ModeOfPaymment,p.purchaseAmount,p.purchasePrice,p.unitsPurchased,w.sellPrice=null, w.withdrawalAmount=null,w.unitsSold=null,p.memberNumber,p.FullName,c.BalanceFundCurrentPrice,b.TotalUnitBalance FROM balancefundpurchase p,balancefundwithdrawal w,`Current Price` c,balacefundaccounts b WHERE p.memberNumber='"; 
        balancedFund=balancedFund.concat(MemberNumberField.getText());balancedFund=balancedFund.concat("' and w.memberNumber='");
        balancedFund=balancedFund.concat(MemberNumberField.getText());balancedFund=balancedFund.concat("' and b.memberNumber='");balancedFund=balancedFund.concat(MemberNumberField.getText()); balancedFund=balancedFund.concat("' UNION SELECT w.TRANS_NO,w.DateOfWithdrawal,w.ModeOfPaymment,p.purchaseAmount=null,p.purchasePrice=null,p.unitsPurchased=null, w.sellPrice,w.withdrawalAmount,w.unitsSold,p.memberNumber,p.FullName,c.BalanceFundCurrentPrice,b.TotalUnitBalance FROM balancefundpurchase p,balancefundwithdrawal w,`Current Price` c,balacefundaccounts b WHERE w.memberNumber='");
        balancedFund=balancedFund.concat(MemberNumberField.getText()); balancedFund=balancedFund.concat("' and p.memberNumber='");balancedFund=balancedFund.concat(MemberNumberField.getText());balancedFund=balancedFund.concat("' and b.memberNumber='");balancedFund=balancedFund.concat(MemberNumberField.getText());
        balancedFund=balancedFund.concat("' ORDER BY `DateOfPurchase` DESC");
        
        
        String moneyMarket="SELECT p.transactionNumber, p.DateOfDeposit,p.DepositAmount,w.withdrawalAmount = null,w.WithdrawalFromInterest= null,b.AccountBalance,b.Interest,p.MemberNumber,p.FullName  FROM moneymarketdeposit p, moneymarketwithdrawal w,moneymarketaccounts b WHERE p.MemberNumber='";moneyMarket=moneyMarket.concat(MemberNumberField.getText());	moneyMarket=moneyMarket.concat("' AND w.MemberNumber='");moneyMarket=moneyMarket.concat(MemberNumberField.getText());  moneyMarket=moneyMarket.concat("' AND b.MemberNumber='"); moneyMarket=moneyMarket.concat(MemberNumberField.getText());
   moneyMarket=moneyMarket.concat( "' UNION  SELECT w.transactionNumber, w.DateOfWithdrawal,p.DepositAmount= null,w.withdrawalAmount,w.WithdrawalFromInterest,b.AccountBalance,b.Interest,w.MemberNumber,w.FullName FROM moneymarketdeposit p, moneymarketwithdrawal w,moneymarketaccounts b WHERE p.MemberNumber='");moneyMarket=moneyMarket.concat(MemberNumberField.getText());moneyMarket=moneyMarket.concat( "' AND w.MemberNumber='");moneyMarket=moneyMarket.concat(MemberNumberField.getText());moneyMarket=moneyMarket.concat("' AND b.MemberNumber='"); moneyMarket=moneyMarket.concat(MemberNumberField.getText()); moneyMarket=moneyMarket.concat("' ORDER BY DateOfDeposit  ASC");
    
   String guarantedPension="SELECT DISTINCT(p.transactionNumber), p.DateOfDeposit,p.DepositAmount,w.withdrawFromPrincipal = null,w.withdrawFromInterest= null,AccountBalance,b.Interest,p.MemberNumber,p.FullName  FROM garanteedpensiondeposit p, garanteedpensionwithdrawals w,garanteedpensionaccounts b WHERE p.MemberNumber='";guarantedPension=guarantedPension.concat(MemberNumberField.getText()); guarantedPension=guarantedPension.concat("' AND w.MemberNumber='");guarantedPension=guarantedPension.concat(MemberNumberField.getText());guarantedPension=guarantedPension.concat("' AND b.MemberNumber='");guarantedPension=guarantedPension.concat(MemberNumberField.getText());
guarantedPension=guarantedPension.concat("' UNION SELECT w.transactionNumber, w.DateOfWithdrawal,p.DepositAmount=null,w.withdrawFromPrincipal,w.withdrawFromInterest,b.AccountBalance,b.Interest,w.MemberNumber,w.FullName FROM garanteedpensiondeposit p, garanteedpensionwithdrawals w,garanteedpensionaccounts b WHERE p.MemberNumber='");guarantedPension=guarantedPension.concat(MemberNumberField.getText());guarantedPension=guarantedPension.concat("' AND w.MemberNumber='");guarantedPension=guarantedPension.concat(MemberNumberField.getText()); guarantedPension=guarantedPension.concat("' AND b.MemberNumber='");guarantedPension=guarantedPension.concat(MemberNumberField.getText());guarantedPension=guarantedPension.concat("' AND w.transactionNumber NOT IN(SELECT transactionNumber from  garanteedpensiondeposit)  ORDER BY DateOfDeposit  ASC");
   

    String personalpension="SELECT p.PurchaseNumber,p.DateOfDeposit,p.purchaseAmount,p.purchasePrice,p.unitsPurchased,w.sellPrice=null, w.withdrawalAmount=null,w.unitsSold=null,p.memberNumber,p.FullName,c.`personalPension Current Price`,b.TotalUnitBalance FROM personalpensiondeposit p,personalpensionwithdrawal w,`Current Price` c,personalpensionpurchase b WHERE p.memberNumber='";personalpension=personalpension.concat(MemberNumberField.getText()); personalpension=personalpension.concat("' and w.memberNumber='");
    personalpension=personalpension.concat(MemberNumberField.getText());personalpension=personalpension.concat("' and b.memberNumber='");personalpension=personalpension.concat(MemberNumberField.getText()); personalpension=personalpension.concat("' UNION SELECT w.PurchaseNumber, w.DateOfWithdrawal,p.purchaseAmount=null,p.purchasePrice=null,p.unitsPurchased=null, w.sellPrice,w.withdrawalAmount,w.unitsSold,p.memberNumber,p.FullName,c.`personalPension Current Price`,b.TotalUnitBalance FROM personalpensiondeposit p,personalpensionwithdrawal w,`Current Price` c,personalpensionpurchase b WHERE w.memberNumber='");
    personalpension=personalpension.concat(MemberNumberField.getText()); personalpension=personalpension.concat("' and p.memberNumber='");
    personalpension=personalpension.concat(MemberNumberField.getText());personalpension=personalpension.concat("' and b.memberNumber='");personalpension=personalpension.concat(MemberNumberField.getText());personalpension=personalpension.concat("' ORDER BY `DateOfDeposit` DESC");
*/
   InputStream MemberTransactionsPPpath=getClass().getResourceAsStream("/Reports/FullStatements/Personal_Pension_Statement2.jrxml");
    InputStream MemberTransactionsMMpath=getClass().getResourceAsStream("/Reports/FullStatements/MoneyMarketAccountBalanceStatement2.jrxml");
    InputStream MemberTransactionsHOpath=getClass().getResourceAsStream("/Reports/HomeOwnershipTransactionStatement.jrxml");
    InputStream MemberTransactionsGPpath=getClass().getResourceAsStream("/Reports/FullStatements/GaranteedPensionAccountBalanceStatement2.jrxml");
    InputStream MemberTransactionsBFpath=getClass().getResourceAsStream("/Reports/FullStatements/BalanceFundStatement2.jrxml");
    if("balancefund".equals(selectFundCS.getValue())){
        runReportStatementByDate1(MemberTransactionsBFpath,MemberTransactionsBFpath1);
        }else if("moneymarket".equals(selectFundCS.getValue())){
           runReportStatementByDate1(MemberTransactionsMMpath,MemberTransactionsMMpath1);
      }else if("garanteedpension".equals(selectFundCS.getValue())){
           runReportStatementByDate1(MemberTransactionsGPpath,MemberTransactionsGPpath1);
      }else if("homeownership".equals(selectFundCS.getValue())){
         runReportStatementByDate1(MemberTransactionsHOpath,MemberTransactionsHOpath1);
      }else if("personalpension".equals(selectFundCS.getValue())){
         runReportStatementByDate1(MemberTransactionsPPpath,MemberTransactionsPPpath1);
      }
            
          /* if("balancefund".equals(selectFundCS.getValue())){
             runReportParam(MemberTransactionsBFpath,balancedFund,MemberTransactionsBFpath1);
             }else if("moneymarket".equals(selectFundCS.getValue())){
               runReportParam(MemberTransactionsMMpath,moneyMarket,MemberTransactionsMMpath1);
           }else if("garanteedpension".equals(selectFundCS.getValue())){
                runReportParam(MemberTransactionsGPpath,guarantedPension,MemberTransactionsGPpath1);
           }else if("homeownership".equals(selectFundCS.getValue())){
              runReportParam(MemberTransactionsHOpath);
           }else if("personalpension".equals(selectFundCS.getValue())){
            runReportParam(MemberTransactionsPPpath,personalpension,MemberTransactionsPPpath1);
           }*/
       
    }

    @FXML
    private void fundTotalsReport(ActionEvent event) {
//    InputStream FundTotalGPpath=getClass().getResourceAsStream("/Reports/GaranteedPensionAcount.jrxml");
//    InputStream FundTotalMMpath=getClass().getResourceAsStream("/Reports/MoneyMarketAccounts.jrxml");
//    InputStream FundTotalBFpath=getClass().getResourceAsStream("/Reports/BalanceFundAccounts.jrxml");
//    InputStream FundTotalPPpath=getClass().getResourceAsStream("/Reports/PersonalPensionAccounts.jrxml");
//    InputStream FundTotalHOpath=getClass().getResourceAsStream("/Reports/HomeOwnershipAccounts.jrxml");
    InputStream SortByDate=getClass().getResourceAsStream("/Reports/DailyFundTotals.jrxml");
     runReportParam2(SortByDate);

             
           
           
            
        
    }

    private void clientAccoutBalanceReport(ActionEvent event) {
        
        
    InputStream MemberAccountBalancesMMpath=getClass().getResourceAsStream("/Reports/MoneyMarketAcountBalanceStatement.jrxml");
    InputStream MemberAccountBalancesBFpath=getClass().getResourceAsStream("/Reports/BalanceFundAccountBalance.jrxml");
    InputStream MemberAccountBalancesHOpath=getClass().getResourceAsStream("/Reports/HomeOwnershipAccoutBalanceStaatement.jrxml");
    InputStream MemberAccountBalancesPPpath=getClass().getResourceAsStream("/Reports/PersonalPensionAccountBalanceStatement.jrxml");
    InputStream MemberAccountBalancesGPpath=getClass().getResourceAsStream("/Reports/GaranteedPensionAccountBalanceStatement.jrxml");
            String MMsql = "SELECT * from `moneymarketaccounts` WHERE `MemberNumber`=";
            MMsql=MMsql.concat("'"); MMsql=MMsql.concat(MemberNumberCAS.getText());
            MMsql=MMsql.concat("'");MMsql=MMsql.concat(";");
            
            String BFsql ="SELECT * from `balacefundaccounts` WHERE `MemberNumber`=";
            BFsql=BFsql.concat("'"); BFsql=BFsql.concat(MemberNumberCAS.getText());
            BFsql=BFsql.concat("'");BFsql=BFsql.concat(";");
           
            String GPsql ="SELECT * from `garanteedpensionaccounts` WHERE `MemberNumber`=";
            GPsql=GPsql.concat("'"); GPsql=GPsql.concat(MemberNumberCAS.getText());
            GPsql=GPsql.concat("'");GPsql=GPsql.concat(";");
            
            String PPsql ="SELECT * from `personalpensionpurchase` WHERE `MemberNumber`=";
            PPsql=PPsql.concat("'"); PPsql=PPsql.concat(MemberNumberCAS.getText());
            PPsql=PPsql.concat("'");PPsql=PPsql.concat(";");
            
            String HOsql ="SELECT * from `homeownershipaccounts` WHERE `MemberNumber`=";
            HOsql=HOsql.concat("'"); HOsql=HOsql.concat(MemberNumberCAS.getText());
            HOsql=HOsql.concat("'");HOsql=HOsql.concat(";");
            
            if("balacefundaccounts".equals(selectFundCAS.getValue())){
             runReport(MemberAccountBalancesBFpath, BFsql);
           }else if("garanteedpensionaccounts".equals(selectFundCAS.getValue())){
            runReport(MemberAccountBalancesGPpath, GPsql);
           }else if("homeownershipaccounts".equals(selectFundCAS.getValue())){
            runReport(MemberAccountBalancesHOpath, HOsql);
           }else if("moneymarketaccounts".equals(selectFundCAS.getValue())){
            runReport(MemberAccountBalancesMMpath, MMsql);
           }else if("personalpensionpurchase".equals(selectFundCAS.getValue())){
            runReport(MemberAccountBalancesPPpath, PPsql);
           }
            
             
            
           
             
        
    }
    
    
    public void runReport11(InputStream path){
        
        try{
          
      JasperDesign jd = JRXmlLoader.load(path);

            
            JasperReport jr = JasperCompileManager.compileReport(jd);
             
            JasperPrint jp = JasperFillManager.fillReport(jr, null, connect);
//            JasperViewer.viewReport(jp, false);
//            Stage newStage = new Stage();
            JRViewerFx view = new JRViewerFx(jp, JRViewerFxMode.REPORT_VIEW, newStage);
            view.start(newStage);


        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText(e.toString());
            alert.showAndWait();
             System.out.println(e.toString());

        }
    
    
    }
   
    public void runReport11(InputStream path,ActionEvent event){
        
        try{
           Stage stage =  (Stage)((Node)event.getSource()).getScene().getWindow();
      JasperDesign jd = JRXmlLoader.load(path);

            
            JasperReport jr = JasperCompileManager.compileReport(jd);
             
            JasperPrint jp = JasperFillManager.fillReport(jr, null, connect);
            //JasperViewer.viewReport(jp, false);
            Stage newStage = new Stage();
            JRViewerFx view = new JRViewerFx(jp, JRViewerFxMode.REPORT_VIEW, stage);
            view.start(stage);


        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText(e.toString());
            alert.showAndWait();
             System.out.println(e.toString());

        }
    
    
    }
   
    
    public void runReport(String path,String sql){
        try{
        
        Map parameter= new HashMap();
        parameter.put("query", sql);

        JasperPrint jp = JasperFillManager.fillReport(path, parameter, connect);
        Stage newStage = new Stage();
        JRViewerFx view = new JRViewerFx(jp, JRViewerFxMode.REPORT_VIEW, newStage);
          

        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText(e.toString());
            alert.showAndWait();
            System.out.println(e.toString());

        }
    
//        try{
//             File directory = new File("./");
//             System.out.println("Relative"+directory.getAbsolutePath());
//            
//          System.out.println("Before :"+path);  
//         JasperDesign jd = JRXmlLoader.load(path);
//         System.out.println("After "+path);
//            JRDesignQuery newQuery = new JRDesignQuery();
//            newQuery.setText(sql);
//            jd.setQuery(newQuery);
//            
//            JasperReport jr = JasperCompileManager.compileReport(jd);
//                
//            JasperPrint jp = JasperFillManager.fillReport(jr, null, connect);
//            
//            Stage newStage = new Stage();
//
//
//            JRViewerFx view = new JRViewerFx(jp, JRViewerFxMode.REPORT_VIEW, newStage);
//            
//
//
//        } catch (Exception e) {
//            Alert alert = new Alert(Alert.AlertType.INFORMATION);
//            alert.setContentText(e.toString());
//            alert.showAndWait();
//             System.out.println(e.toString());
//
//        }
    
    
    }
    
     public void runReportParam(InputStream path, String sql,InputStream path1){
        
        try{
       
        Map parameter= new HashMap();
             parameter.put("memberNumber", MemberNumberField.getText());
             
             
             
            JasperDesign jd = JRXmlLoader.load(path);
              JRDesignQuery newQuery = new JRDesignQuery();
            newQuery.setText(sql);
            jd.setQuery(newQuery);
            JasperReport jr = JasperCompileManager.compileReport(jd);

            JasperPrint jp = JasperFillManager.fillReport(jr, null, connect);
            
            
            if(jp.getPages().isEmpty()){
                
            System.out.println("Empty report ....");
            System.out.println("Building new  report ....");
             JasperDesign jd1 = JRXmlLoader.load(path1);
              
            JasperReport jr1 = JasperCompileManager.compileReport(jd1);
            
            JasperPrint jp1 = JasperFillManager.fillReport(jr1, parameter, connect);
            JasperViewer.viewReport(jp1, false);
            }else{
             JasperViewer.viewReport(jp, false);
            
            }
           
           
//            JRViewerFx view = new JRViewerFx(jp, JRViewerFxMode.REPORT_VIEW, newStage);
//            view.start(newStage);
            


        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText(e.toString());
            alert.showAndWait();
            System.out.println(e.toString());

        }
    
    
    }
    
    
     public void runReportParam(InputStream path){
        
        try{
        
        Map parameter= new HashMap();
             parameter.put("memberNumber", MemberNumberField.getText());
             
             
            
            JasperReport report = (JasperReport) JRLoader.loadObject(path);
//            JasperDesign jd = JRXmlLoader.load(path);
//             
//            JasperReport jr = JasperCompileManager.compileReport(jd);

            JasperPrint jp = JasperFillManager.fillReport(report, parameter, connect);
            JasperViewer.viewReport(jp, false);
//            Stage newStage = new Stage();
//            JRViewerFx view = new JRViewerFx(jp, JRViewerFxMode.REPORT_VIEW, newStage);
//            view.start(newStage);
            


        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText(e.toString());
            alert.showAndWait();
            System.out.println(e.toString());

        }
    
    
    }
    public void runReportParam(InputStream path, String sql){
        
        try{
       
        Map parameter= new HashMap();
             parameter.put("memberNumber", MemberNumberField.getText());
             
             
             
            JasperDesign jd = JRXmlLoader.load(path);
              JRDesignQuery newQuery = new JRDesignQuery();
            newQuery.setText(sql);
            jd.setQuery(newQuery);
            JasperReport jr = JasperCompileManager.compileReport(jd);

            JasperPrint jp = JasperFillManager.fillReport(jr, null, connect);
            JasperViewer.viewReport(jp, false);
           
//            JRViewerFx view = new JRViewerFx(jp, JRViewerFxMode.REPORT_VIEW, newStage);
//            view.start(newStage);
            


        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText(e.toString());
            alert.showAndWait();
            System.out.println(e.toString());

        }
    
    
    }
    
   public void runReport(InputStream path, String sql){
        System.out.println("fast report method");
        try{
        
        Map parameter= new HashMap();
        parameter.put("query", sql);
       
        JasperDesign jd = JRXmlLoader.load(path);
         JRDesignQuery newQuery = new JRDesignQuery();
            newQuery.setText(sql);
            jd.setQuery(newQuery);
        JasperReport jr =JasperCompileManager.compileReport(jd);
        JasperPrint jp = JasperFillManager.fillReport(jr, null, connect);
    JasperViewer.viewReport(jp, false);
//            Stage newStage = new Stage();
//            JRViewerFx view = new JRViewerFx(jp, JRViewerFxMode.REPORT_VIEW, newStage);
//            view.start(newStage);
       
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText(e.toString());
            alert.showAndWait();
            System.out.println(e.toString());

        }
    
    
    }
    
    
     public void runReportParam(String path){
        
        try{
        
        Map parameter= new HashMap();
             parameter.put("memberNumber", MemberNumberField.getText());
             
             
             
            JasperDesign jd = JRXmlLoader.load(path);

            JasperReport jr = JasperCompileManager.compileReport(jd);

            JasperPrint jp = JasperFillManager.fillReport(jr, parameter, connect);
            
//           JasperViewer.viewReport(jp, false);
//            Stage newStage = new Stage();
            JRViewerFx view = new JRViewerFx(jp, JRViewerFxMode.REPORT_VIEW, newStage);
            view.start(newStage);
            


        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText(e.toString());
            alert.showAndWait();
            System.out.println(e.toString());

        }
    
    
    }
     public void runReportParam2(String path){
        
        try{
        LocalDate ldate=specificDateFT.getValue();
            
            Date date = java.sql.Date.valueOf(ldate);
            Map parameter= new HashMap();
             parameter.put("Date",date );
           
             JasperDesign jd = JRXmlLoader.load(path);
            JasperReport jr = JasperCompileManager.compileReport(jd);

            JasperPrint jp = JasperFillManager.fillReport(jr, parameter, connect);
            
//          JasperViewer.viewReport(jp, false);
//            Stage newStage = new Stage();
            JRViewerFx view = new JRViewerFx(jp, JRViewerFxMode.REPORT_VIEW, newStage);
            view.start(newStage);
          
            


        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText(e.toString());
            alert.showAndWait();
        System.out.println(e.toString());  
        }
    
    
    }
    // 
      public void runReportParam2(InputStream path){
        
        try{
            
        LocalDate ldate=specificDateFT.getValue();
           
            Date date = java.sql.Date.valueOf(ldate);
            Map parameter= new HashMap();
             parameter.put("Date",date );
           
            JasperDesign jd = JRXmlLoader.load(path);
            JasperReport jr = JasperCompileManager.compileReport(jd);

            JasperPrint jp = JasperFillManager.fillReport(jr, null, connect);
            
//            JasperViewer.viewReport(jp, false);
//            Stage newStage = new Stage();
            JRViewerFx view = new JRViewerFx(jp, JRViewerFxMode.REPORT_VIEW, newStage);
            view.start(newStage);
            


        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText(e.toString());
            alert.showAndWait();
        System.out.println(e.toString());  
        }
    
    
    }
            public void runReportParam2(InputStream path,ActionEvent event){
        
        try{
           Stage stage =  (Stage)((Node)event.getSource()).getScene().getWindow(); 
        LocalDate ldate=specificDateFT.getValue();
           
            Date date = java.sql.Date.valueOf(ldate);
            Map parameter= new HashMap();
             parameter.put("Date",date );
           
            JasperDesign jd = JRXmlLoader.load(path);
            JasperReport jr = JasperCompileManager.compileReport(jd);

            JasperPrint jp = JasperFillManager.fillReport(jr, parameter, connect);
            
//            JasperViewer.viewReport(jp, false);
            
            JRViewerFx view = new JRViewerFx(jp, JRViewerFxMode.REPORT_VIEW, stage);
            view.start(stage);
            


        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText(e.toString());
            alert.showAndWait();
        System.out.println(e.toString());  
        }
    
    
    }
      public void runReportStatementByDate(InputStream path){
       
        try{
        
//           LocalDate fromdate=fromDateClientTransaction.getValue();
//            LocalDate todate=toDateClientTransaction.getValue();
//            Date date = java.sql.Date.valueOf(fromdate);
//            Date date1 = java.sql.Date.valueOf(todate);
            Map parameter= new HashMap();
             parameter.put("memberNumber", MemberNumberField.getText());
            /* parameter.put("fromDate",fromDateClientTransaction.getValue().toString());*/
             parameter.put("toDate",toDateClientTransaction.getValue().toString());
           
            JasperDesign jd = JRXmlLoader.load(path);
            JasperReport jr = JasperCompileManager.compileReport(jd);

            JasperPrint jp = JasperFillManager.fillReport(jr, parameter, connect);
            
//      JasperViewer.viewReport(jp, false);
//            Stage newStage = new Stage();
            JRViewerFx view = new JRViewerFx(jp, JRViewerFxMode.REPORT_VIEW, newStage);
            view.start(newStage);
          
            


        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText(e.toString());
            alert.showAndWait();
        System.out.println(e.toString());  
        }
    
    
    }
      
     
      public void runReportStatementByDate1(InputStream path, InputStream path1){
          
          try{
          
//             LocalDate fromdate=fromDateClientTransaction.getValue();
//              LocalDate todate=toDateClientTransaction.getValue();
//              Date date = java.sql.Date.valueOf(fromdate);
//              Date date1 = java.sql.Date.valueOf(todate);
              Map parameter= new HashMap();
               parameter.put("memberNumber", MemberNumberField.getText());
              /* parameter.put("fromDate",fromDateClientTransaction.getValue().toString());*/
               
             
              JasperDesign jd = JRXmlLoader.load(path);
              JasperReport jr = JasperCompileManager.compileReport(jd);

              JasperPrint jp = JasperFillManager.fillReport(jr, parameter, connect);
                if(jp.getPages().isEmpty()){
                  
                  System.out.println("Empty report ....");
                  System.out.println("Building new  report ....");
                   JasperDesign jd1 = JRXmlLoader.load(path1);
                    
                  JasperReport jr1 = JasperCompileManager.compileReport(jd1);
                  
                  JasperPrint jp1 = JasperFillManager.fillReport(jr1, parameter, connect);
                  JasperViewer.viewReport(jp1, false);
                  }else{
                   JasperViewer.viewReport(jp, false);
                  
                  }
            
              


          } catch (Exception e) {
              Alert alert = new Alert(Alert.AlertType.INFORMATION);
              alert.setContentText(e.toString());
              alert.showAndWait();
          System.out.println(e.toString());  
          }
      
      
      }
     public void runReportStatementByDate(InputStream path,ActionEvent event){
       
        try{
        
//           LocalDate fromdate=fromDateClientTransaction.getValue();
//            LocalDate todate=toDateClientTransaction.getValue();
//            Date date = java.sql.Date.valueOf(fromdate);
//            Date date1 = java.sql.Date.valueOf(todate);
            Map parameter= new HashMap();
             parameter.put("memberNumber", MemberNumberField.getText());
             
             parameter.put("toDate",toDateClientTransaction.getValue().toString());
           
            JasperDesign jd = JRXmlLoader.load(path);
            JasperReport jr = JasperCompileManager.compileReport(jd);

            JasperPrint jp = JasperFillManager.fillReport(jr, parameter, connect);
            
      JasperViewer.viewReport(jp, false);
//            Stage newStage = new Stage();
//            JRViewerFx view = new JRViewerFx(jp, JRViewerFxMode.REPORT_VIEW, newStage);
//            view.start(newStage);
          
            


        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText(e.toString());
            alert.showAndWait();
        System.out.println(e.toString());  
        }
    
    
    }
    @FXML
    private void totalWithdrawalFD(ActionEvent event) {
       SpecificDate.setValue(null);
//         modeOfPayment=false;
       
    }

    @FXML
    private void totalWithdrawalSD(ActionEvent event) {
        FromDate.setValue(null);
        ToDate.setValue(null);
//        modeOfPayment=false;
    }

    @FXML
    private void totalWithdrawalMOP(ActionEvent event) {
//        modeOfPayment=true;
//        FromDate.setValue(null);
//        ToDate.setValue(null);
//        SpecificDate.setValue(null);
    }

    @FXML
    private void totalDepositsSD(ActionEvent event) {
        fromDateTD.setValue(null);
        ToDateTD.setValue(null);
//        modeOfPaymentTD= false;
    }

    @FXML
    private void totalDepositFD(ActionEvent event) {
        sppecificDateTD.setValue(null);
//         modeOfPaymentTD= false;
    }

    @FXML
    private void totalDepositMOP(ActionEvent event) {
//         modeOfPaymentTD= true;
//        fromDateTD.setValue(null);
//        ToDateTD.setValue(null);
//        sppecificDateTD.setValue(null);
    }

    @FXML
    private void setFalseTD(ActionEvent event) {
          modeOfPaymentTD= false;
    }
    
    @FXML
    private void chooseReport(ActionEvent event) {
          modeOfPayment= false;
    }

    @FXML
    private void fullReport(ActionEvent event) {
        fullReport=true;
        specificDateFT.setValue(null);
    }

    private void fundTotalsSD(ActionEvent event) {
        fullReport= false;
    }

    @FXML
    private void searchClient(ActionEvent event) throws SQLException {
         connect=javaconnect.connectDb();
         String account=chooseTable.getValue();
          String number =memberNumberSearch.getText();
          if(!account.equals("moneymarketsetrate")&&!account.equals("homeownershipsetrates")&&!account.equals("garanteedpensionrates")&&!account.equals("balancefundsetprices")&&!account.equals("personalpensionsetrates")){
        String sql ="select * from ";
                sql=sql.concat("`");
                sql=sql.concat(account);
                sql=sql.concat("`");
                sql=sql.concat("where `MemberNumber` ='");
                sql=sql.concat(number);
                sql=sql.concat("'");
                
                statement=connect.prepareStatement(sql);
                result=statement.executeQuery();
                ResultsetTableDisplay table = new ResultsetTableDisplay(MainTable);
                table.displayToTable1(result);
                System.out.println(sql);
    }
          EditTableView.setSelected(false);
    }
     public String checkForNumbers(String input){
         String str = input;
         str = str.replaceAll("[^0-9]", "");
        
    return str;
    }

    @FXML
    private void validatepricesetBF(MouseEvent event) {
                 SetBF.disableProperty().bind(
                 DateBF.valueProperty().isNull()
               .or(buyPriceBF.textProperty().isEmpty() )
               .or(sellPriceBF.textProperty().isEmpty() )
               .or(AdminFeesBF.textProperty().isEmpty() )
               .or(setByUserNameBF.textProperty().isEmpty() )
                );
        
    }

    @FXML
    private void validateRateSetMM(MouseEvent event) {
         setRateBtMM.disableProperty().bind(
                 DateMM.valueProperty().isNull()
               .or(GeneralRateMM.textProperty().isEmpty() )
               .or(setByUserNameMM.textProperty().isEmpty() ));
    }

    @FXML
    private void validateRateSetHO(MouseEvent event) {
         setRatebtHO.disableProperty().bind(
                 DateHO.valueProperty().isNull()
               .or(GeneralRateHO.textProperty().isEmpty() )
               .or(setByUserNameHO.textProperty().isEmpty() ));
        
    }

    @FXML
    private void validateRateSetGP(MouseEvent event) {
        
        setRateBTGP.disableProperty().bind(
                 DateGP.valueProperty().isNull()
               .or(GeneralRateGP.textProperty().isEmpty() )
               .or(setByUserNameGP.textProperty().isEmpty() ));
    }

    @FXML
    private void validatePriceSetPP(MouseEvent event) {
         setPriceBTPP.disableProperty().bind(
                 DatePP.valueProperty().isNull()
               .or(ByyPricePP.textProperty().isEmpty() )
               .or(setByUserNamePP.textProperty().isEmpty() )
               .or(SellPricePP.textProperty().isEmpty() ));
    }

    @FXML
    private void fundTransferReport(ActionEvent event) {
    InputStream UnitTrustFundTransfers=getClass().getResourceAsStream("/Reports/UnitTrustFundTransfers.jrxml");
    InputStream PensionFundTransfers=getClass().getResourceAsStream("/Reports/PensionFundTransfers.jrxml");
    if(fundTransferSelection.getValue()=="UnitTrustTransfers"){
        runReport11(UnitTrustFundTransfers);
    }else{
    runReport11(PensionFundTransfers);
    }
    }

    @FXML
    private void partialReportClientStatement(ActionEvent event) {
  /*  InputStream MemberTransactionsPPpath=getClass().getResourceAsStream("/Reports/Personal_Pension_Statement1.jrxml");
    InputStream MemberTransactionsMMpath=getClass().getResourceAsStream("/Reports/MoneyMarketAccountBalanceStatement1.jrxml");
    InputStream MemberTransactionsHOpath=getClass().getResourceAsStream("/Reports/HomeOwnershipTransactionStatement.jrxml");
    InputStream MemberTransactionsGPpath=getClass().getResourceAsStream("/Reports/GaranteedPensionAccountBalanceStatement1.jrxml");
    InputStream MemberTransactionsBFpath=getClass().getResourceAsStream("/Reports/BalanceFundStatement1.jrxml");*/
       	InputStream MemberTransactionsPPpath=getClass().getResourceAsStream("/Reports/AsDateStatements/Personal_Pension_Statement1.jrxml");
        InputStream MemberTransactionsMMpath=getClass().getResourceAsStream("/Reports/AsDateStatements/MoneyMarketAccountBalanceStatement1.jrxml");
        InputStream MemberTransactionsHOpath=getClass().getResourceAsStream("/Reports/HomeOwnershipTransactionStatement.jrxml");
        InputStream MemberTransactionsGPpath=getClass().getResourceAsStream("/Reports/AsDateStatements/GaranteedPensionAccountBalanceStatement1.jrxml");
        InputStream MemberTransactionsBFpath=getClass().getResourceAsStream("/Reports/AsDateStatements/BalanceFundStatement1.jrxml");
          if("balancefund".equals(selectFundCS.getValue())){
             runReportStatementByDate(MemberTransactionsBFpath);
             }else if("moneymarket".equals(selectFundCS.getValue())){
                runReportStatementByDate(MemberTransactionsMMpath);
           }else if("garanteedpension".equals(selectFundCS.getValue())){
                runReportStatementByDate(MemberTransactionsGPpath);
           }else if("homeownership".equals(selectFundCS.getValue())){
              runReportStatementByDate(MemberTransactionsHOpath);
           }else if("personalpension".equals(selectFundCS.getValue())){
              runReportStatementByDate(MemberTransactionsPPpath);
           }
    }



    @FXML
    private void setBuyPrice(KeyEvent event) {
    Double currentPrice=Double.parseDouble(sellPriceBF.getText());
        Double adminFee=currentPrice*0.03;
        Double buyPrice=currentPrice+adminFee;
        DecimalFormat f = new DecimalFormat("##.0000");
        String adminFee1=f.format(adminFee);
        String buyPrice1=f.format(buyPrice);
        buyPriceBF.setText(buyPrice1);
        AdminFeesBF.setText(adminFee1);
        
 
    }
     
    @FXML
    private void setBuyPricePP(KeyEvent event) {
    
    Double currentPrice1=Double.parseDouble(SellPricePP.getText());;
    
        DecimalFormat f = new DecimalFormat("##.0000");
        
        String number=f.format(currentPrice1);
        ByyPricePP.setText(number);
        
      
        
 
    }
    
    
    

	public static String getUserName() {
		return userName;
	}



	public static void setUserName(String userName) {
		Back_Office_ModuleController.userName = userName;
	}



	public static String getUserType() {
		return userType;
	}



	public static void setUserType(String userType) {
		Back_Office_ModuleController.userType = userType;
	}
	
    @FXML
    private void changePasswordMenu(ActionEvent event){
    	Stage primaryStage= new Stage();
    	MainPassword pass = new MainPassword(primaryStage, userName, userType);
    	System.out.println("userName: "+userName+" userType: "+userType);
    	
    	
    }
    @FXML
    public void showAboutMenu(ActionEvent event){
    	Stage primaryStage= new Stage();
        callAboutWindow window= new callAboutWindow(primaryStage);
          
    	
    }

    static int count=1;
    public boolean Authenticate(String userName,String password1,String userType) throws SQLException{
        JaspytPasswordEncryptor encryptor= new JaspytPasswordEncryptor();
      
        connect=javaconnect.connectDb1();
        String sql1="select * FROM  `userdatatable` where `UserName`='";
        sql1=sql1.concat(userName);
        sql1=sql1.concat("'");
        
        statement = connect.prepareStatement(sql1);
         ResultSet rs=statement.executeQuery();
        count=1;
        while(rs.next()){
         
            String userName1=rs.getString("UserName");
            if(userName.equals(userName1)){
               
              break;
            }
        count++;
        }
        rs.absolute(count);
        Back_Office_ModuleController.pass=rs.getString("password");
        String pass=encryptor.getDecryptedString(rs.getString("password"));
        String usertype=rs.getString("userType");
          
        return (pass.equals(encryptor.getDecryptedString(password1))&userType.equals("Admin"));
       
    
      
    }

	

   
    
}


package InterestCalculator;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Random;

import org.apache.commons.lang3.time.DateUtils;

import DataBaseConnector.javaconnect;
import DateConverter.LocalDatePersistenceConverter;
import javafx.scene.control.TextArea;
import zimele_information_management_system.FXMLDocumentController;

/**
 *
 * @author james kamau
 */
public class UpdateDataMoneyMarket1 {

	Connection connect;
	PreparedStatement statement;
	ResultSet result;
	static double accountBalance = 0.00;
	static double depositAmount = 0.00;
	static double interest = 0.00;
	static double interestBalance=0.00;
	static double totalInterest = 0.00;
	FXMLDocumentController cont;
	static String memberNumber = "";
	static String FullName = "";
	static double nodRate = 0.00;
	static double nodRateLoop = 0.00;
	static double changedRate = 0.00;
	static double repeatRate = 0.00;
	static java.sql.Date dbSqlCurrentDate33 = null;
	static boolean checkForRate = false;
	static boolean checkForRateLOOP = false;
	static boolean checkForRepeatRateLOOP = false;
	static boolean RepeatRateLOOP = false;
	static boolean checkCompound = false;
	static boolean check = false;
	static double interestCompound = 0.00;
	static double Rate = 0.00;
	static double interestGetRate=0.00;
	static java.sql.Date NextInterestSetOn = null;
	static Boolean checkInterestBalance=false;
	LocalDatePersistenceConverter date = new LocalDatePersistenceConverter();
	List<Map> list = new ArrayList<Map>();
	Map<java.sql.Date, Double> maplist = new HashMap<>();
	Map<java.sql.Date, Double> map = new HashMap<>();
	static boolean checklasttrans =false;

	public double getInterest() {
		return interest;
	}

	public double getAccountBalance() {
		return accountBalance;
	}
	static	boolean checkEpmtyReport=false;
	public void makeInterestUpdate(String MemberNumber) throws SQLException {
		memberNumber = MemberNumber;
		java.sql.Date dbSqlCurrentDate22 = null;
		String fullName = "";
		

		connect = javaconnect.connectDb();
		String sql1 = "SELECT * FROM `money_market_transaction_new` WHERE MEMBER_NO ='";
		sql1 = sql1.concat(MemberNumber);
		sql1 = sql1.concat("' AND `TRANS_TYPE` LIKE 'INTEREST' AND AMOUNT > 0  ORDER BY `TRANS_DATE1` DESC");
		statement = connect.prepareStatement(sql1);
		ResultSet rs1 = statement.executeQuery();
		if (rs1.isBeforeFirst()) {
			rs1.next();
			dbSqlCurrentDate22 = rs1.getDate("TRANS_DATE1");
			dbSqlCurrentDate33 = rs1.getDate("TRANS_DATE1");
			fullName = rs1.getString("FULL_NAME");
			FullName = rs1.getString("FULL_NAME");
			makebalanceUpdate(MemberNumber, dbSqlCurrentDate22);
			interestBalance( returnEndYear(dbSqlCurrentDate22),MemberNumber);
			
			System.out.println("Last interest date : "+dbSqlCurrentDate22.toString());
			

		} else {
			System.out.println("STATEMENT HAS NEVER BEEN UPDATED 22222222");
			String sql11 = "SELECT * FROM `money_market_transaction_new` WHERE MEMBER_NO ='";
			sql11 = sql11.concat(MemberNumber);
			sql11 = sql11.concat("' ORDER BY `TRANS_DATE1` ASC");
			statement = connect.prepareStatement(sql11);
			ResultSet rs11 = statement.executeQuery();
			if (rs11.next()) {
				checkEpmtyReport=true;
				dbSqlCurrentDate22 = rs11.getDate("TRANS_DATE1");
				dbSqlCurrentDate33 = rs11.getDate("TRANS_DATE1");
				fullName = rs11.getString("FULL_NAME");
				FullName = rs11.getString("FULL_NAME");
				
				System.out.println("date before transactions : " + dbSqlCurrentDate22.toString());
			}

		}

		String sql = "SELECT * FROM money_market_transaction_new WHERE MEMBER_NO='";
		sql = sql.concat(MemberNumber);
		sql = sql.concat("'  AND `money_market_transaction_new`.`TRANS_DATE1`>='");
		sql = sql.concat(dbSqlCurrentDate22.toString());
		sql = sql.concat("'  ORDER BY `money_market_transaction_new`.`TRANS_DATE1` ASC;");
		statement = connect.prepareStatement(sql);
		ResultSet rs = statement.executeQuery();

		String transType = "";
		String endtransType = "";

		java.sql.Date dbSqlCurrentDate = null;
		java.sql.Date EndLoopDate = null;
		
		while (rs.next()) {
			check=false;

			try {
				System.out.println("--------------------New iteration----------------------");
				System.out.println("Initial Interest: " + interest);

				String Transtype = rs.getString("TRANS_TYPE");

				java.sql.Date dbSqlCurrentDate1 = rs.getDate("TRANS_DATE1");
				double depositAmount = rs.getDouble("AMOUNT");

				System.out.println("Initial DepositAmount: " + depositAmount);
				UpdateDataMoneyMarket.depositAmount = depositAmount;
				System.out.println("Initial AccountBalance: " + accountBalance);
				if (dbSqlCurrentDate1.compareTo(dbSqlCurrentDate22) == 0 && !Transtype.equals("INTEREST") && !checkEpmtyReport) {
					System.out.println("Interest date and deposit date same ");
					System.out.println("deposit date same " + dbSqlCurrentDate1.toString());
					System.out.println("Interest date same " + dbSqlCurrentDate22.toString());
					if( Transtype.equals("PURCHASE")){
					accountBalance -= depositAmount;
					}else if( Transtype.equals("WITHDRAWAL") ){
						accountBalance += depositAmount;
						
					}

				}
			
				if (!Transtype.equals("INTEREST")) {
					dbSqlCurrentDate = rs.getDate("TRANS_DATE1");
					EndLoopDate = dbSqlCurrentDate;
					System.out.println("Original Transaction Date: " + dbSqlCurrentDate.toString());
					transType = rs.getString("TRANS_TYPE");
					endtransType = transType;
				} else if (Transtype.equals("INTEREST") && rs.getDouble("AMOUNT") > 0) {
				
					
					dbSqlCurrentDate = changeInterestDate(rs.getDate("TRANS_DATE1"));
					EndLoopDate = dbSqlCurrentDate;
					System.out.println("Original Transaction Date: " + dbSqlCurrentDate.toString());
					transType = rs.getString("TRANS_TYPE");
					endtransType = transType;
				}

				// variable declarations

				java.sql.Date dbSqlNextDate = null;

				// NextTransactionDate Code
				int rowNumber = 0;
				/*System.out.println("Current row number Before Next Transaction: " + rowNumber);*/
				if (rs.next()) {
					String transType11 = rs.getString("TRANS_TYPE");
					double depositAmount1 = rs.getDouble("AMOUNT");
					

					if (!transType11.equals("INTEREST")) {
						dbSqlNextDate = rs.getDate("TRANS_DATE1");
						endtransType = transType11;
						EndLoopDate = dbSqlNextDate;
						/*System.out.println("Next Transaction Date: " + dbSqlNextDate.toString());*/

						rs.previous();

						check = CompoundInterest(dbSqlCurrentDate, dbSqlNextDate, transType11, depositAmount);
					} else {
						rs.previous();
					}
					
					// GetRate for interest Calculation
						if (!check) {
						
					
						if (transType.equals("PURCHASE")) {
						
							System.out.println("Purchase transaction" + dbSqlCurrentDate22.toString());
                              accountBalance += depositAmount;
                          	java.sql.Date lastInterestDate = getRate(dbSqlCurrentDate, dbSqlNextDate, accountBalance);

    						nodRate = DifferenceInDays(lastInterestDate, dbSqlNextDate);
    						/*System.out.println("NUMBER OF DAYS"+nodRate);
    						System.out.println("RATE ON MAIN LOOP"+Rate);
    						System.out.println("ACCOUNT BALANCE IN MAIN LOOP"+accountBalance);*/
    						System.out.println("From date :: "+lastInterestDate +" To date ::  "+dbSqlNextDate);
    						interestCompound = UpdateInterest(accountBalance, Rate, nodRate);
    						interestCompound+=interestGetRate;
							interest=interest+interestCompound;
							System.out.println(
									"Purchase Calculation:   interest: " + interest + " AccountBalance: " + accountBalance);
							saveInterestValues(dbSqlNextDate);
							UpdateInterestAccount(MemberNumber, interest, accountBalance);
							// cont.showInterest(interest, accountBalance);

						} else if (transType.equals("WITHDRAWAL")) {
							System.out.println("Withdrawal transaction" + dbSqlCurrentDate22.toString());
							accountBalance -= depositAmount;
							java.sql.Date lastInterestDate = getRate(dbSqlCurrentDate, dbSqlNextDate, accountBalance);

							nodRate = DifferenceInDays(lastInterestDate, dbSqlNextDate);
						/*	System.out.println("NUMBER OF DAYS"+nodRate);
							System.out.println("RATE ON MAIN LOOP"+Rate);
							System.out.println("ACCOUNT BALANCE IN MAIN LOOP"+accountBalance);*/
							System.out.println("From date :: "+lastInterestDate +" To date ::  "+dbSqlNextDate);
							interestCompound= UpdateInterest(accountBalance, Rate, nodRate);
							interestCompound+=interestGetRate;
							interest=interest+interestCompound;
							System.out.println(
									"Withdrawal Calculation: interest: " + interest + " AccountBalance: " + accountBalance);
							saveInterestValues(dbSqlNextDate);
							UpdateInterestAccount(MemberNumber, interest, accountBalance);
							// cont.showInterest(interest, accountBalance);
						} else if (transType.equals("INTEREST")) {

							java.sql.Date lastInterestDate = getRate(dbSqlCurrentDate, dbSqlNextDate, accountBalance);

							nodRate = DifferenceInDays(lastInterestDate, dbSqlNextDate);
						/*	System.out.println("NUMBER OF DAYS"+nodRate);
							System.out.println("RATE ON MAIN LOOP"+Rate);
							System.out.println("ACCOUNT BALANCE IN MAIN LOOP"+accountBalance);*/
							System.out.println("From date :: "+lastInterestDate +" To date ::  "+dbSqlNextDate);
							interestCompound= UpdateInterest(accountBalance, Rate, nodRate);
							interestCompound+=interestGetRate;
							interest=interest+interestCompound;
							System.out.println(
									"Withdrawal Calculation: interest: " + interest + " AccountBalance: " + accountBalance);
							saveInterestValues(dbSqlNextDate);
							UpdateInterestAccount(MemberNumber, interest, accountBalance);
							// cont.showInterest(interest, accountBalance);
						}
					}
					
				}

				

				// Interest Calculation Code
				System.out.println("transaction type: " + transType);

			} catch (Exception e) {
			}

		}
		if (EndLoopDate.compareTo(dbSqlCurrentDate22) == 0 && !checkEpmtyReport) {
			System.out.println("Interest date and deposit date same ");
			System.out.println("deposit date same " + EndLoopDate.toString());
			System.out.println("Interest date same " + dbSqlCurrentDate22.toString());
			 if (!endtransType.equals("INTEREST")) {
					accountBalance -= depositAmount;
				}
			

		}
		
		double rate = 0;
		
		if (EndLoopDate.compareTo(date.convertToDatabaseColumn(LocalDate.now())) < 0) {

			if (endtransType.equals("PURCHASE")) {
				accountBalance += depositAmount;
			} else if (endtransType.equals("WITHDRAWAL")) {
				accountBalance -= depositAmount;
			}
				checklasttrans=true;
			checkCompound = CompoundInterest(EndLoopDate, date.convertToDatabaseColumn(LocalDate.now()),
					accountBalance);
			
			if (!checkCompound) {
				java.sql.Date lastInterestDate = getRate(EndLoopDate, date.convertToDatabaseColumn(LocalDate.now()), accountBalance);
				double noOfDays = 0.00;
				noOfDays += DifferenceInDays(lastInterestDate, date.convertToDatabaseColumn(LocalDate.now()));
			/*	System.out.println("Total Number Of Days: OneRate 111111 " + noOfDays);
				System.out.println("ONE rate  change" + Rate);
				System.out.println("PRINCIPAL AMOUNT" + accountBalance);*/
				System.out.println("From date :: "+lastInterestDate +" To date ::  "+date.convertToDatabaseColumn(LocalDate.now()));
				interestCompound= UpdateInterest(accountBalance, Rate, noOfDays);
				interestCompound+=interestGetRate;
				interest=interest+interestCompound;
				UpdateInterestAccount(MemberNumber, interest, accountBalance);

			}

		}

		if (!checkCompound) {
			Random rand = new Random();
			Integer value = rand.nextInt(1000000000);
			LocalDatePersistenceConverter date12 = new LocalDatePersistenceConverter();
			connect = javaconnect.connectDb();
			String PostInterest = "INSERT INTO `money_market_transaction_new` (`TRANS_NO`, `TRANS_ID`, `TRANS_TYPE`, `TRANS_DATE`, `TRANS_DATE1`, `MEMBER_NO`, `FULL_NAME`, `ACCOUNT_NO`, `PORTFOLIO`, `MOP`, `AMOUNT`, `INTEREST_AMOUNT`, `U_NAME`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";

			PreparedStatement preparedStatement;
			try {
				preparedStatement = connect.prepareStatement(PostInterest);
				preparedStatement.setString(1, value.toString());
				preparedStatement.setInt(2, value);
				preparedStatement.setString(3, "INTEREST");
				preparedStatement.setString(4, LocalDate.now().toString());
				preparedStatement.setDate(5, date12.convertToDatabaseColumn(LocalDate.now()));
				preparedStatement.setString(6, MemberNumber);
				preparedStatement.setString(7, fullName);
				preparedStatement.setString(8, MemberNumber);
				preparedStatement.setString(9, "Money Market");
				preparedStatement.setString(10, "INTERES_POST");
				preparedStatement.setDouble(11, 0.00);
				preparedStatement.setDouble(12, interestCompound);
				preparedStatement.setString(13, "SYSTEM");

				preparedStatement.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		checkCompound=false;
		accountBalance = 0.00;
		interest = 0.00;

	}

	public double makebalanceUpdate(String MemberNumber, java.sql.Date date) throws SQLException {

		connect = javaconnect.connectDb();
		String sql = "SELECT * FROM money_market_transaction_new WHERE MEMBER_NO='";
		sql = sql.concat(MemberNumber);
		sql = sql.concat("' AND `money_market_transaction_new`.`TRANS_DATE1` <='");
		sql = sql.concat(date.toString());
		sql = sql.concat("'  ORDER BY `money_market_transaction_new`.`TRANS_DATE1` ASC;");

		statement = connect.prepareStatement(sql);
		ResultSet rs = statement.executeQuery();

		while (rs.next()) {
			try {
				String Transtype = rs.getString("TRANS_TYPE");
				double depositAmount = rs.getDouble("AMOUNT");
				// System.out.println("Deposit Amount: "+depositAmount);

				if (Transtype.equals("INTEREST") && depositAmount < 0) {
					totalInterest += depositAmount;
					System.out.println("InterestWithdrawn Amount: " + depositAmount);
					System.out.println("Interest balance Amount: " + totalInterest);
				} else if (Transtype.equals("INTEREST") && depositAmount > 0) {

					totalInterest += depositAmount;
					System.out.println("Interest Posting Amount: " + depositAmount);
					System.out.println("Interest balance Amount: " + totalInterest);
				} else if (Transtype.equals("WITHDRAWAL")) {
					accountBalance -= depositAmount;
					System.out.println("Withdrawn Amount: " + depositAmount);
					System.out.println("Account balance Amount: " + accountBalance);
				} else if (Transtype.equals("PURCHASE") || Transtype.equals("Re investing")
						|| Transtype.equals("Fund Transfer") || Transtype.equals("RE-INVESTING")
						|| Transtype.equals("Deposit") && depositAmount > 0) {
					accountBalance += depositAmount;
					System.out.println("Deposit Amount: " + depositAmount);
					System.out.println("Account balance Amount: " + accountBalance);
				}
			} catch (Exception e) {

			}
		}
		return accountBalance;
	}

	public java.sql.Date getRate(java.sql.Date TransDate, java.sql.Date nextTransDate, double accountBalance)
			throws SQLException {
		System.out.println("BEGINING OF GET RATE METHOD ::");
		interestGetRate=0.00;
		interestCompound=0.00;
		Integer num1=Integer.parseInt(memberNumber);
		java.sql.Date lastDate=null;
		connect=javaconnect.connectDb();
	        String sql="select * FROM `moneymarketaccounts` WHERE `CustomRate`!='0' AND `AccountBalance`!='0' AND MemberNumber='";
	        sql=sql.concat(num1.toString()+"'");
	        System.out.println(sql);
	        statement = connect.prepareStatement(sql);
	        ResultSet rsac = statement.executeQuery();
	      
	        if(rsac.isBeforeFirst()){
	        while(rsac.next()){
	         try{
	           System.out.println("prefferential rate member :"+num1.toString()+" Rate : "+Rate);
	           Rate = rsac.getDouble("CustomRate");
	           
	          lastDate=TransDate;
	         }catch(Exception e){}
	        }
	        }else{
		Double Days = 0.00;

		java.sql.Date CurrentDate1 = null;
		java.sql.Date NextDate1 = null;

		connect = javaconnect.connectDb();
		String sql1 = "SELECT * FROM `moneymarketsetrate` ";
		statement = connect.prepareStatement(sql1);
		ResultSet set = statement.executeQuery();
		double rate = 0;
		set.absolute(1);
		java.sql.Date FirstDate = set.getDate("setOnDate");
		double firstrate = set.getDouble("generalRate");
		set.absolute(-1);
		lastDate = set.getDate("setOnDate");
		double lastrate = set.getDouble("generalRate");
		set.absolute(-2);
		java.sql.Date beforelastDate = set.getDate("setOnDate");

		set.absolute(1);
		set.previous();

		if (TransDate.compareTo(lastDate) < 0 && nextTransDate.compareTo(lastDate) > 0) {
			/*System.out.println("INTEREST UPDATED FROM THE GET RATE METHOD:::FROM DATE :: " + TransDate.toString());
			System.out.println("Last RateChange Interest table:" + lastDate.toString());*/

			try {
				while (set.next()) {
					java.sql.Date CurrentDate = set.getDate("setOnDate");
					/*System.out.println("Current Date InterestRate Table: " + CurrentDate);*/
					java.sql.Date NextDate = null;
					if (set.next()) {
						NextDate = set.getDate("setOnDate");
					/*	System.out.println("Next Date InterestRate Table: " + NextDate);*/

					}
					set.previous();
					/*System.out.println("date befor change date : " + TransDate);*/

					if ((TransDate.compareTo(FirstDate) == 0 || TransDate.compareTo(FirstDate) < 0)) {
						System.out.println("days from : "+TransDate+"  To ::  "+CurrentDate);
						interestGetRate += UpdateInterest(accountBalance, set.getDouble("generalRate"),
								DifferenceInDays(TransDate, CurrentDate));
						
						/*System.out.println("Rate selected  before loop is on date : " + CurrentDate);
						System.out.println("Rate selected before loop : " + changedRate);*/
						while (set.next()) {
							set.previous();
							CurrentDate1 = set.getDate("setOnDate");
							/*System.out.println("Rate selected inside loop is on date : " + CurrentDate1);*/
						
							changedRate = set.getDouble("generalRate");
							System.out.println("Rate selected inside loop : " + changedRate);
							if (set.next()) {
								NextDate1 = set.getDate("setOnDate");
								System.out.println("days from : "+CurrentDate1+"  To ::  "+NextDate1);
								interestGetRate += UpdateInterest(accountBalance, set.getDouble("generalRate"),
									DifferenceInDays(CurrentDate1, NextDate1));
         
							}
							

						}
						
						break;
					} else if ((TransDate.compareTo(CurrentDate) == 0 || TransDate.compareTo(CurrentDate) > 0)
							&& (TransDate.compareTo(NextDate) == 0 || TransDate.compareTo(NextDate) < 0)) {
						
				
						set.next();
						CurrentDate=set.getDate("setOnDate");
						/*System.out.println("Rate selected  before loop is on date : " + CurrentDate);
						System.out.println("Number of days before loop : " + DifferenceInDays(TransDate, CurrentDate));
						*/
						set.previous();
						/*System.out.println("Rate selected before loop : " + set.getDouble("generalRate"));*/
						System.out.println("days from : "+TransDate+"  To ::  "+CurrentDate);
						interestGetRate += UpdateInterest(accountBalance, set.getDouble("generalRate"),
								DifferenceInDays(TransDate, CurrentDate));
						
						
						set.next();
						while (set.next()) {
							set.previous();
							CurrentDate1 = set.getDate("setOnDate");
							/*System.out.println("Rate selected inside loop is on currentdate1 date : " + CurrentDate1);*/
							changedRate = set.getDouble("generalRate");
							/*System.out.println("Rate selected inside loop : " + changedRate);*/
							if (set.next()) {
								NextDate1 = set.getDate("setOnDate");
								System.out.println("days from : "+CurrentDate1+"  To ::  "+NextDate1);
								interestGetRate += UpdateInterest(accountBalance, set.getDouble("generalRate"),
															DifferenceInDays(CurrentDate1, NextDate1));
						
						/*System.out.println("Rate selected inside loop is on currentdate1 date :: " +NextDate1);
						System.out.println("Number of days before loop : " + DifferenceInDays(CurrentDate1, NextDate1));*/
							}
							

						}
						
						break;

					}

				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			Rate = lastrate;

		} else if (TransDate.compareTo(lastDate) > 0 && nextTransDate.compareTo(lastDate) > 0) {
			Rate = lastrate; 
			lastDate = TransDate;

		}else if(TransDate.compareTo(lastDate) < 0 && nextTransDate.compareTo(lastDate)< 0){
			
	  if(returnNextDateRate(TransDate).compareTo(returnNextDateRate(nextTransDate))!=0){
			String sql11 = "SELECT * FROM `moneymarketsetrate` where setOnDate>='";
			sql11=sql11.concat(returnNextDateRate(TransDate).toString()+"' AND setOnDate<='");
			sql11=sql11.concat(returnNextDateRate(nextTransDate).toString()+"'");
			
			statement = connect.prepareStatement(sql11);
			ResultSet set1 = statement.executeQuery();
			while (set1.next()) {
				
				
					set1.next();
					java.sql.Date NextDate11=set1.getDate("setOnDate");
					set1.previous();
					System.out.println("days from : "+TransDate+"  To ::  "+NextDate11);
					interestGetRate += UpdateInterest(accountBalance, set1.getDouble("generalRate"),
							DifferenceInDays(TransDate, NextDate11));
					
					innerLoop:
					while(set1.next()){
						
						java.sql.Date currentDate111=set1.getDate("setOnDate");
						double rate1111= set1.getDouble("generalRate");
						
						if(set1.isLast()){
							
							System.out.println("days from : "+currentDate111+"  To ::  "+nextTransDate);			
							interestGetRate += UpdateInterest(accountBalance, rate1111,
										DifferenceInDays(currentDate111, nextTransDate));
								
								break innerLoop;
						}else{
							set1.next();
							java.sql.Date NextDate111=set1.getDate("setOnDate");
							System.out.println("days from : "+currentDate111+"  To ::  "+NextDate111);
							interestGetRate += UpdateInterest(accountBalance, rate1111,
							DifferenceInDays(currentDate111, NextDate111));
							if(set1.isLast()){
								
								System.out.println("days from : "+NextDate111+"  To ::  "+nextTransDate);			
								interestGetRate += UpdateInterest(accountBalance, rate1111,
											DifferenceInDays(NextDate111, nextTransDate));
									
									
							}
							
							
						}
						
					}
					
				
				
				
			}
		
			lastDate = TransDate;
			Rate=0.00;
			}else{
				try {
				while (set.next()) {
					java.sql.Date CurrentDate = set.getDate("setOnDate");
					/*System.out.println("Current Date InterestRate Table: " + CurrentDate);*/
					java.sql.Date NextDate = null;
					if (set.next()) {
						NextDate = set.getDate("setOnDate");
						/*System.out.println("Next Date InterestRate Table: " + NextDate);*/

					}
					set.previous();
					/*System.out.println("date befor change date : " + TransDate);*/

					if ((TransDate.compareTo(FirstDate) == 0 || TransDate.compareTo(FirstDate) < 0)) {
					
						Rate=set.getDouble("generalRate");
						 lastDate = TransDate;
						break;
					} else if ((TransDate.compareTo(CurrentDate) == 0 || TransDate.compareTo(CurrentDate) > 0)
							&& (TransDate.compareTo(NextDate) == 0 || TransDate.compareTo(NextDate) < 0)) {
						set.getDate("setOnDate");
						 set.getDouble("generalRate");
						 Rate=set.getDouble("generalRate");
						/* System.out.println("rate before all last "+Rate);*/
						 
						 lastDate = TransDate;
						/* System.out.println("Date before all last "+lastDate);*/
						 break;

					}

				}
			} catch (Exception e) {
				e.printStackTrace();
			}
				
			}
			
		
			
			
		}}
		System.out.println("END OF GET RATE METHOD ::"+lastDate);
		return lastDate;
	}
	
	public java.sql.Date returnNextDateRate(java.sql.Date TransDate) throws SQLException{
		java.sql.Date RateDate=null;	
		connect = javaconnect.connectDb();
		String sql1 = "SELECT * FROM `moneymarketsetrate` ";
		statement = connect.prepareStatement(sql1);
		ResultSet set = statement.executeQuery();
		 set.absolute(1);
		  java.sql.Date FirstDate=set.getDate("setOnDate");
		  double firstrate=set.getDouble("generalRate");
		  set.absolute(-1);
		  java.sql.Date lastDate=set.getDate("setOnDate");
		  double lastrate=set.getDouble("generalRate");
		  set.absolute(1);
		  set.previous();
		
		try{
	  	       while(set.next()){
	  	     	 java.sql.Date CurrentDate = set.getDate("setOnDate");
	  	         /*  System.out.println("Current Date InterestRate Table: "+CurrentDate);*/
	  	           java.sql.Date NextDate=null;
	  	          if(set.next()) {
	  	           NextDate = set.getDate("setOnDate");
	  	           /*System.out.println("Next Date InterestRate Table: "+NextDate);*/
	  	           
	  	        
	  	          }
	  	          set.previous();
	  	     	/*  System.out.println("date befor change date : "+TransDate);*/
	  	     	  
	  	     	  if((TransDate.compareTo(FirstDate)==0||TransDate.compareTo(FirstDate)<0)){
	  	     		RateDate=set.getDate("setOnDate");
	  	     		/*System.out.println(" selected NextDATE SELECTION Dates : "+set.getDate("setOnDate"));*/
	  	     		
	  	     		 break;
	  	     	  }else if((TransDate.compareTo(CurrentDate)==0||TransDate.compareTo(CurrentDate)>0)&&(TransDate.compareTo(NextDate)==0||TransDate.compareTo(NextDate)<0)){
	  	     		  
	  	     		RateDate=set.getDate("setOnDate");
	  	     		
	  	     	    /*    System.out.println(" selected NextDATE SELECTION Dates : "+set.getDate("setOnDate"));
	  	     	    */    
	  	     	        break;   
	  	     		  
	  	     	  }else if((TransDate.compareTo(lastDate)==0||TransDate.compareTo(lastDate)>0)){
	  	     		 RateDate=set.getDate("setOnDate");
	  	     		/*System.out.println(" selected NextDATE SELECTION Dates : "+set.getDate("setOnDate"));*/
	  	     		  break;
	  	     		  
	  	     	  }
	  	        
	  	     	
	  	       }
	  	       }catch(Exception e){
	  	           e.printStackTrace();
	  	           }
		
		
		return RateDate;
	}

	public java.sql.Date addDays(java.sql.Date CurrentTransDate, int days) {

		java.util.Date returndate1 = DateUtils.addDays(CurrentTransDate, days);
		java.sql.Date returndate = new java.sql.Date(returndate1.getTime());

		return returndate;
	}

	static Double difference = 0.00;
	static int countYear = 0;
	public boolean CompoundInterest(java.sql.Date CurrentTransDate, java.sql.Date NextTransDate,
			double depositAmount) throws SQLException {
		countYear=0;
		
		
		java.sql.Date lastInterestDate = null;
		System.out.println("Running compound interest Method");
		boolean check = false;
		Calendar c1 = Calendar.getInstance();
		Calendar c2 = Calendar.getInstance();
		c1.setTime(CurrentTransDate);
		c2.setTime(NextTransDate);
		int monthDiff = c1.get(Calendar.MONTH) - c2.get(Calendar.MONTH);
		int dayDiff = c1.get(Calendar.DAY_OF_MONTH) - c2.get(Calendar.DAY_OF_MONTH);
		int yearDiff = c1.get(Calendar.YEAR) - c2.get(Calendar.YEAR);
		Integer CurrentTransDateyear = c1.get(Calendar.YEAR);
		Integer NextTransDateYear = c2.get(Calendar.YEAR);

		if (Objects.equals(CurrentTransDateyear, NextTransDateYear)) {
			check = false;
			System.out.println("Compound interest Method returns false");
		} else if (CurrentTransDateyear < NextTransDateYear ) {
			if(!checkInterestBalance){
			interest+=interestBalance;
			checkInterestBalance=true;
			}
			System.out.println("Compound interest method returns true");
			Double days1 = DifferenceInDays(CurrentTransDate, NextTransDate);
			System.out.println("Total number Of days difference: " + days1);

		
			
			
			if (days1 <= 365) {
				System.out.println("Compound Interest Method No of days <= 365: " + days1);
				java.sql.Date endYearDate = createSqlDate(CurrentTransDateyear, 12, 31);

				if (addDays(CurrentTransDate, days1.intValue()).compareTo(endYearDate) > 0) {
					System.out.println("Compounding where number of days is less than 365");
					lastInterestDate = getRate(CurrentTransDate, endYearDate, accountBalance);
					Double days2 = DifferenceInDays(lastInterestDate, endYearDate);
					/*System.out.println("number of days till end of year : "+days2);*/
					System.out.println("days from : "+lastInterestDate+"  To ::  "+endYearDate);
					interestCompound= UpdateInterest(accountBalance, Rate, days2);
					interestCompound+=interestGetRate;
					interest=interest+interestCompound;

			/*		System.out.println("AccountBalance before compounding Interest: " + accountBalance);
			*/		
					if(checkCompoundingYear(endYearDate)){
					
					saveCompoundedValues(endYearDate);
					accountBalance += interest;
					interest = 0.00;
					
					}else{
						
						saveInterestValues(endYearDate);
						
					}
					/*System.out.println("AccountBalance after compounding Interest: " + accountBalance);
					*/
					java.sql.Date BeginYearDate = createSqlDate(CurrentTransDateyear + 1, 01, 01);
					/*System.out.println("compound interest new date created 1 " + BeginYearDate.toString());
					*/ 
					lastInterestDate = getRate(endYearDate, NextTransDate, accountBalance);
					double days3 = DifferenceInDays(lastInterestDate, NextTransDate);
					/*System.out.println("number of days after begining of year: " + days3);*/
					System.out.println("days from : "+lastInterestDate+"  To ::  "+NextTransDate);
					interestCompound= UpdateInterest(accountBalance, Rate, days3);
					interestCompound+=interestGetRate;
					interest=interest+interestCompound;
					if(checklasttrans){
						LocalDatePersistenceConverter date12 = new LocalDatePersistenceConverter();
						saveInterestValues(date12.convertToDatabaseColumn(LocalDate.now()));
					
						checklasttrans=false;
					}
					
				} else {
					lastInterestDate = getRate(CurrentTransDate, addDays(CurrentTransDate, days1.intValue()),
							accountBalance);
					Double days2 = DifferenceInDays(lastInterestDate, addDays(CurrentTransDate, days1.intValue()));
					System.out.println("days from : "+lastInterestDate+"  To ::  "+addDays(CurrentTransDate, days1.intValue()));
					interestCompound= UpdateInterest(accountBalance, Rate, days2);
					interestCompound+=interestGetRate;
					interest=interest+interestCompound;
					if(checklasttrans){
						LocalDatePersistenceConverter date12 = new LocalDatePersistenceConverter();
						saveInterestValues(date12.convertToDatabaseColumn(LocalDate.now()));
						checklasttrans=false;
					}

				}

			} else if (days1 > 365) {
				
				System.out.println("Compound Interest Method No of days > 365: " + days1);
				java.sql.Date endYearDate = createSqlDate(CurrentTransDateyear, 12, 31);
         if (addDays(CurrentTransDate, days1.intValue()).compareTo(endYearDate) > 0) {
				lastInterestDate = getRate(CurrentTransDate, endYearDate, accountBalance);
				double days2 = DifferenceInDays(lastInterestDate, endYearDate);
				System.out.println("days from : "+lastInterestDate+"  To ::  "+endYearDate);
				interestCompound = UpdateInterest(accountBalance, Rate, days2);
				interestCompound+=interestGetRate;
				interest=interest+interestCompound;
				difference = days1 - days2;
         }else{
        	 
        	 
         }
				if (difference <= 365 ) {
					System.out.println("Compound Interest Method No of days difference <= 365: " + difference);
					if(checkCompoundingYear(endYearDate)){
						
						saveCompoundedValues(endYearDate);
						accountBalance += interest;
						
						interest = 0.00;
						}else{
							
							saveInterestValues(endYearDate);
						}
					if(difference != 0){
					java.sql.Date BeginYearDate = createSqlDate(CurrentTransDateyear + 1, 01, 01);
					/*System.out.println("compound interest new date created 1 " + BeginYearDate.toString());*/
					lastInterestDate = getRate(BeginYearDate, addDays(BeginYearDate, difference.intValue()),
							accountBalance);
					System.out.println("days from : "+lastInterestDate+"  To ::  "+addDays(BeginYearDate, difference.intValue()));
					interestCompound =  UpdateInterest(accountBalance, Rate,
							DifferenceInDays(lastInterestDate, addDays(BeginYearDate, difference.intValue())));
					interestCompound+=interestGetRate;
					interest=interest+interestCompound;
					saveInterestValues(addDays(BeginYearDate, difference.intValue()));
					
					}
				} else if (difference > 365 ) {
					java.sql.Date counterEndYearDate=endYearDate;
					if(checkCompoundingYear(endYearDate)){
						
						saveCompoundedValues(endYearDate);
						accountBalance += interest;
						
						interest = 0.00;
						}else{
							
							saveInterestValues(counterEndYearDate);
						}
					while (difference > 365) {
						countYear++;
						/*System.out.println("Compound Interest Method No of days difference > 365: " + difference);*/
					
						java.sql.Date BeginYearDate = createSqlDate(CurrentTransDateyear + countYear, 01, 01);
						
						
						if(checkLeapYear(addDays(BeginYearDate, 364))){
							
							lastInterestDate = getRate(BeginYearDate, addDays(BeginYearDate, 366), accountBalance);
							System.out.println("days from : "+lastInterestDate+"  To ::  "+ addDays(BeginYearDate, 366));
							interestCompound = UpdateInterest(accountBalance, Rate, DifferenceInDays(lastInterestDate, addDays(BeginYearDate, 365)));
							interestCompound+=interestGetRate;
							interest=interest+interestCompound;
							counterEndYearDate=addDays(BeginYearDate, 365);
						}else{
							
							lastInterestDate = getRate(BeginYearDate, addDays(BeginYearDate, 365), accountBalance);
							System.out.println("days from : "+lastInterestDate+"  To ::  "+ addDays(BeginYearDate, 365));
							interestCompound = UpdateInterest(accountBalance, Rate, DifferenceInDays(lastInterestDate, addDays(BeginYearDate, 365)));
							interestCompound+=interestGetRate;
							interest=interest+interestCompound;
							counterEndYearDate=addDays(BeginYearDate, 364);
							
						}
						difference = difference - 365;
						/*System.out.println("Compound Interest Method No of days difference 2 > 365: " + difference);*/
						if(checkCompoundingYear(counterEndYearDate)&&checkIfEndYear(counterEndYearDate)){
							
							saveCompoundedValues(counterEndYearDate);
							accountBalance += interest;
							
							interest = 0.00;
							}else{
								
								saveInterestValues(counterEndYearDate);
							}
						if (difference < 365) {
							counterEndYearDate=addDays(BeginYearDate, 365);
							countYear++;
							break;
						}
					}
					if (difference <= 365 ) {
						/*System.out.println("DAY DIFFERECE FROM COMPOUND INTEREST:::  "+difference);*/
					java.sql.Date BeginYearDate = createSqlDate(CurrentTransDateyear + countYear, 01, 01);
					java.sql.Date endYearCheckDate = createSqlDate(CurrentTransDateyear + countYear, 12, 31);
						if( difference != 0){
							
							if (addDays(BeginYearDate, difference.intValue()).compareTo(endYearCheckDate) > 0) {
								/*System.out.println("LAST DAY DIFFERECE FROM COMPOUND METHOD:::  "+addDays(BeginYearDate, difference.intValue()).toString());
								*/
								System.out.println("DAY DIFFERECE GREATER LESS THAN END YEAR  ");
						lastInterestDate = getRate(BeginYearDate, addDays(BeginYearDate, difference.intValue()),
								accountBalance);
						System.out.println("days from : "+lastInterestDate+"  To ::  "+ addDays(BeginYearDate, difference.intValue()));
						interestCompound = UpdateInterest(accountBalance, Rate,
								DifferenceInDays(lastInterestDate, addDays(BeginYearDate, difference.intValue())));
						interestCompound+=interestGetRate;
						interest=interest+interestCompound;
							
						
						
						counterEndYearDate=addDays(BeginYearDate, difference.intValue());
						//interestCompound = interest;
						saveInterestValues(counterEndYearDate);
						
							
							}else{
								/*System.out.println("LAST DAY DIFFERECE FROM COMPOUND METHOD:::  "+addDays(BeginYearDate, difference.intValue()).toString());*/
								/*System.out.println("DAY DIFFERECE GREATER GREATER THAN END YEAR  "+difference);*/
								difference-=1;
								endYearCheckDate=addDays(BeginYearDate, difference.intValue());
								lastInterestDate = getRate(BeginYearDate, endYearCheckDate,
										accountBalance);
								
								/*System.out.println("END YEAR  DATE :: "+endYearCheckDate);
								System.out.println("LAST INTEREST DATE :: "+lastInterestDate);*/
							if(checkCompoundingYear(endYearCheckDate)&&checkIfEndYear(endYearCheckDate)){
									
									interestCompound = interest;
									saveCompoundedValues(endYearCheckDate);
									accountBalance += interest;
									
									interest = 0.00;
									}
								
							System.out.println("days from : "+lastInterestDate+"  To ::  "+ addDays(BeginYearDate, difference.intValue()));
							interestCompound = UpdateInterest(accountBalance, Rate,
										DifferenceInDays(lastInterestDate, addDays(BeginYearDate, difference.intValue())));
								counterEndYearDate=addDays(BeginYearDate, difference.intValue());
								
								interestCompound+=interestGetRate;
								interest=interest+interestCompound;
								System.out.println("END trans  DATE :: "+counterEndYearDate);
								System.out.println("LAST INTEREST DATE :: "+lastInterestDate);
								saveInterestValues(counterEndYearDate);
							
							}
						}
				
					}

				}

			}

			
			UpdateInterestAccount(memberNumber, interest, accountBalance);
			check = true;
		} 
		return check;

	
	}

/*	public boolean CompoundInterest(java.sql.Date CurrentTransDate, java.sql.Date NextTransDate,
			double depositAmount) throws SQLException {
		
		
		java.sql.Date lastInterestDate = null;
		System.out.println("Running compound interest Method");
		boolean check = false;
		Calendar c1 = Calendar.getInstance();
		Calendar c2 = Calendar.getInstance();
		c1.setTime(CurrentTransDate);
		c2.setTime(NextTransDate);
		int monthDiff = c1.get(Calendar.MONTH) - c2.get(Calendar.MONTH);
		int dayDiff = c1.get(Calendar.DAY_OF_MONTH) - c2.get(Calendar.DAY_OF_MONTH);
		int yearDiff = c1.get(Calendar.YEAR) - c2.get(Calendar.YEAR);
		Integer CurrentTransDateyear = c1.get(Calendar.YEAR);
		Integer NextTransDateYear = c2.get(Calendar.YEAR);

		if (Objects.equals(CurrentTransDateyear, NextTransDateYear)) {
			check = false;
			System.out.println("Compound interest Method returns false");
		} else if (CurrentTransDateyear < NextTransDateYear && !checkIfEndYear(CurrentTransDate)) {
			System.out.println("Compound interest method returns true");
			Double days1 = DifferenceInDays(CurrentTransDate, NextTransDate);
			System.out.println("Total number Of days difference: " + days1);

			
			
			
			if (days1 <= 365) {
				System.out.println("Compound Interest Method No of days <= 365: " + days1);
				java.sql.Date endYearDate = createSqlDate(CurrentTransDateyear, 12, 31);

				if (addDays(CurrentTransDate, days1.intValue()).compareTo(endYearDate) > 0) {
					System.out.println("Compounding where number of days is less than 365");
					lastInterestDate = getRate(CurrentTransDate, endYearDate, accountBalance);
					Double days2 = DifferenceInDays(lastInterestDate, endYearDate);
					System.out.println("number of days till end of year : "+days2);
					System.out.println("days from : "+lastInterestDate+"  To ::  "+endYearDate);
					interestCompound= UpdateInterest(accountBalance, Rate, days2);
					interestCompound+=interestGetRate;
					interest=interest+interestCompound;

					System.out.println("AccountBalance before compounding Interest: " + accountBalance);
					
					if(checkCompoundingYear(endYearDate)){
					
					saveCompoundedValues(endYearDate);
					accountBalance += interest;
					interest = 0.00;
					
					}else{
						
						saveInterestValues(endYearDate);
						
					}
					System.out.println("AccountBalance after compounding Interest: " + accountBalance);
					
					java.sql.Date BeginYearDate = createSqlDate(CurrentTransDateyear + 1, 01, 01);
					System.out.println("compound interest new date created 1 " + BeginYearDate.toString());
					 
					lastInterestDate = getRate(endYearDate, NextTransDate, accountBalance);
					double days3 = DifferenceInDays(lastInterestDate, NextTransDate);
					System.out.println("number of days after begining of year: " + days3);
					System.out.println("days from : "+lastInterestDate+"  To ::  "+NextTransDate);
					interestCompound= UpdateInterest(accountBalance, Rate, days3);
					interestCompound+=interestGetRate;
					interest=interest+interestCompound;
					if(checklasttrans){
						Random rand = new Random();
						Integer value = rand.nextInt(1000000000);
						LocalDatePersistenceConverter date12 = new LocalDatePersistenceConverter();
						connect = javaconnect.connectDb();
						String PostInterest = "INSERT INTO `money_market_transaction_new` (`TRANS_NO`, `TRANS_ID`, `TRANS_TYPE`, `TRANS_DATE`, `TRANS_DATE1`, `MEMBER_NO`, `FULL_NAME`, `ACCOUNT_NO`, `PORTFOLIO`, `MOP`, `AMOUNT`, `INTEREST_AMOUNT`, `U_NAME`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";

						PreparedStatement preparedStatement;
						try {
							preparedStatement = connect.prepareStatement(PostInterest);
							preparedStatement.setString(1, value.toString());
							preparedStatement.setInt(2, value);
							preparedStatement.setString(3, "INTEREST");
							preparedStatement.setString(4, LocalDate.now().toString());
							preparedStatement.setDate(5, date12.convertToDatabaseColumn(LocalDate.now()));
							preparedStatement.setString(6, memberNumber);
							preparedStatement.setString(7, FullName);
							preparedStatement.setString(8, memberNumber);
							preparedStatement.setString(9, "Money Market");
							preparedStatement.setString(10, "INTERES_POST");
							preparedStatement.setDouble(11, 0.00);
							preparedStatement.setDouble(12, interest);
							preparedStatement.setString(13, "SYSTEM");

							preparedStatement.executeUpdate();
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					
						checklasttrans=false;
					}
					
				} else {
					lastInterestDate = getRate(CurrentTransDate, addDays(CurrentTransDate, days1.intValue()),
							accountBalance);
					Double days2 = DifferenceInDays(lastInterestDate, addDays(CurrentTransDate, days1.intValue()));
					System.out.println("days from : "+lastInterestDate+"  To ::  "+addDays(CurrentTransDate, days1.intValue()));
					interestCompound= UpdateInterest(accountBalance, Rate, days2);
					interestCompound+=interestGetRate;
					interest=interest+interestCompound;
					if(checklasttrans){
						Random rand = new Random();
						Integer value = rand.nextInt(1000000000);
						LocalDatePersistenceConverter date12 = new LocalDatePersistenceConverter();
						connect = javaconnect.connectDb();
						String PostInterest = "INSERT INTO `money_market_transaction_new` (`TRANS_NO`, `TRANS_ID`, `TRANS_TYPE`, `TRANS_DATE`, `TRANS_DATE1`, `MEMBER_NO`, `FULL_NAME`, `ACCOUNT_NO`, `PORTFOLIO`, `MOP`, `AMOUNT`, `INTEREST_AMOUNT`, `U_NAME`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";

						PreparedStatement preparedStatement;
						try {
							preparedStatement = connect.prepareStatement(PostInterest);
							preparedStatement.setString(1, value.toString());
							preparedStatement.setInt(2, value);
							preparedStatement.setString(3, "INTEREST");
							preparedStatement.setString(4, LocalDate.now().toString());
							preparedStatement.setDate(5, date12.convertToDatabaseColumn(LocalDate.now()));
							preparedStatement.setString(6, memberNumber);
							preparedStatement.setString(7, FullName);
							preparedStatement.setString(8, memberNumber);
							preparedStatement.setString(9, "Money Market");
							preparedStatement.setString(10, "INTERES_POST");
							preparedStatement.setDouble(11, 0.00);
							preparedStatement.setDouble(12, interest);
							preparedStatement.setString(13, "SYSTEM");

							preparedStatement.executeUpdate();
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					
						checklasttrans=false;
					}

				}

			} else if (days1 > 365) {
				
				System.out.println("Compound Interest Method No of days > 365: " + days1);
				java.sql.Date endYearDate = createSqlDate(CurrentTransDateyear, 12, 31);
         if (addDays(CurrentTransDate, days1.intValue()).compareTo(endYearDate) > 0) {
				lastInterestDate = getRate(CurrentTransDate, endYearDate, accountBalance);
				double days2 = DifferenceInDays(lastInterestDate, endYearDate);
				System.out.println("days from : "+lastInterestDate+"  To ::  "+endYearDate);
				interestCompound = UpdateInterest(accountBalance, Rate, days2);
				interestCompound+=interestGetRate;
				interest=interest+interestCompound;
				difference = days1 - days2;
				}
				if (difference <= 365 ) {
					System.out.println("Compound Interest Method No of days difference <= 365: " + difference);
					if(checkCompoundingYear(endYearDate)){
						interestCompound = interest;
						saveCompoundedValues(endYearDate);
						accountBalance += interest;
						
						interest = 0.00;
						}else{
							interestCompound = interest;
							saveInterestValues(endYearDate);
						}
					if(difference != 0){
					java.sql.Date BeginYearDate = createSqlDate(CurrentTransDateyear + 1, 01, 01);
					System.out.println("compound interest new date created 1 " + BeginYearDate.toString());
					lastInterestDate = getRate(BeginYearDate, addDays(BeginYearDate, difference.intValue()),
							accountBalance);
					System.out.println("days from : "+lastInterestDate+"  To ::  "+addDays(BeginYearDate, difference.intValue()));
					interest += UpdateInterest(accountBalance, Rate,
							DifferenceInDays(lastInterestDate, addDays(BeginYearDate, difference.intValue())));
					}
				} else if (difference > 365 ) {
					java.sql.Date counterEndYearDate=endYearDate;
					if(checkCompoundingYear(endYearDate)){
						interestCompound = interest;
						saveCompoundedValues(endYearDate);
						accountBalance += interest;
						
						interest = 0.00;
						}else{
							interestCompound = interest;
							saveInterestValues(counterEndYearDate);
						}
					while (difference > 365) {
						countYear++;
						System.out.println("Compound Interest Method No of days difference > 365: " + difference);
					
						java.sql.Date BeginYearDate = createSqlDate(CurrentTransDateyear + countYear, 01, 01);
						
						
						if(checkLeapYear(addDays(BeginYearDate, 364))){
							
							lastInterestDate = getRate(BeginYearDate, addDays(BeginYearDate, 366), accountBalance);
							System.out.println("days from : "+lastInterestDate+"  To ::  "+ addDays(BeginYearDate, 366));
							interestCompound = UpdateInterest(accountBalance, Rate, DifferenceInDays(lastInterestDate, addDays(BeginYearDate, 365)));
							interestCompound+=interestGetRate;
							interest=interest+interestCompound;
							counterEndYearDate=addDays(BeginYearDate, 365);
						}else{
							
							lastInterestDate = getRate(BeginYearDate, addDays(BeginYearDate, 365), accountBalance);
							System.out.println("days from : "+lastInterestDate+"  To ::  "+ addDays(BeginYearDate, 365));
							interestCompound = UpdateInterest(accountBalance, Rate, DifferenceInDays(lastInterestDate, addDays(BeginYearDate, 365)));
							interestCompound+=interestGetRate;
							interest=interest+interestCompound;
							counterEndYearDate=addDays(BeginYearDate, 364);
							
						}
						difference = difference - 365;
						System.out.println("Compound Interest Method No of days difference 2 > 365: " + difference);
						if(checkCompoundingYear(counterEndYearDate)&&checkIfEndYear(counterEndYearDate)){
							
							saveCompoundedValues1(counterEndYearDate);
							accountBalance += interest;
							
							interest = 0.00;
							}else{
								
								saveInterestValues1(counterEndYearDate);
							}
						if (difference < 365) {
							counterEndYearDate=addDays(BeginYearDate, 365);
							countYear++;
							break;
						}
					}
					if (difference <= 365 ) {
						System.out.println("DAY DIFFERECE FROM COMPOUND INTEREST:::  "+difference);
					java.sql.Date BeginYearDate = createSqlDate(CurrentTransDateyear + countYear, 01, 01);
					java.sql.Date endYearCheckDate = createSqlDate(CurrentTransDateyear + countYear, 12, 31);
						if( difference != 0){
							
							if (addDays(BeginYearDate, difference.intValue()).compareTo(endYearCheckDate) > 0) {
								System.out.println("LAST DAY DIFFERECE FROM COMPOUND METHOD:::  "+addDays(BeginYearDate, difference.intValue()).toString());
								
								System.out.println("DAY DIFFERECE GREATER LESS THAN END YEAR  ");
						lastInterestDate = getRate(BeginYearDate, addDays(BeginYearDate, difference.intValue()),
								accountBalance);
						System.out.println("days from : "+lastInterestDate+"  To ::  "+ addDays(BeginYearDate, difference.intValue()));
						interest += UpdateInterest(accountBalance, Rate,
								DifferenceInDays(lastInterestDate, addDays(BeginYearDate, difference.intValue())));
							
							
						
						
						counterEndYearDate=addDays(BeginYearDate, difference.intValue());
						interestCompound = interest;
						saveInterestValues(counterEndYearDate);
						
							
							}else{
								System.out.println("LAST DAY DIFFERECE FROM COMPOUND METHOD:::  "+addDays(BeginYearDate, difference.intValue()).toString());
								System.out.println("DAY DIFFERECE GREATER GREATER THAN END YEAR  "+difference);
								difference-=3;
								endYearCheckDate=addDays(BeginYearDate, difference.intValue());
								lastInterestDate = getRate(BeginYearDate, endYearCheckDate,
										accountBalance);
								
								System.out.println("END YEAR  DATE :: "+endYearCheckDate);
								System.out.println("LAST INTEREST DATE :: "+lastInterestDate);
							if(checkCompoundingYear(endYearCheckDate)&&checkIfEndYear(endYearCheckDate)){
									
									interestCompound = interest;
									saveCompoundedValues(endYearCheckDate);
									accountBalance += interest;
									
									interest = 0.00;
									}
								
							System.out.println("days from : "+lastInterestDate+"  To ::  "+ addDays(BeginYearDate, difference.intValue()));
							interestCompound = UpdateInterest(accountBalance, Rate,
										DifferenceInDays(lastInterestDate, addDays(BeginYearDate, difference.intValue())));
								counterEndYearDate=addDays(BeginYearDate, difference.intValue());
								
								interestCompound+=interestGetRate;
								interest=interest+interestCompound;
								System.out.println("END trans  DATE :: "+counterEndYearDate);
								System.out.println("LAST INTEREST DATE :: "+lastInterestDate);
								saveInterestValues(counterEndYearDate);
							
							}
						}
				
					}

				}

			}

			
			UpdateInterestAccount(memberNumber, interest, accountBalance);
			check = true;
		} 
		return check;

	
	}*/
	
	public java.sql.Date  changeInterestDate(java.sql.Date CurrentTransDate){
		java.sql.Date BeginYearDate=null;
		if(checkIfEndYear(CurrentTransDate)){
			Calendar c1 = Calendar.getInstance();
			c1.setTime(CurrentTransDate);
			int month = c1.get(Calendar.MONTH);
			int day = c1.get(Calendar.DAY_OF_MONTH);
			System.out.println("day of the mothn:" + day + " month of the year: " + month);
			int yearDiff = c1.get(Calendar.YEAR);
			BeginYearDate = createSqlDate(yearDiff+1 , 01, 01);
			System.out.println("INTEREST DATE CHANGED TO 1st JAN "+BeginYearDate.toString());
			
		} else{
			BeginYearDate = CurrentTransDate;
			System.out.println("NO CHANGE TO IN INTEREST DATE "+BeginYearDate.toString());
			
		}
		
		return BeginYearDate;
	}
	
	public boolean CompoundInterest(java.sql.Date CurrentTransDate, java.sql.Date NextTransDate, String transType,
			double depositAmount) throws SQLException {
		
		countYear=0;
		java.sql.Date lastInterestDate = null;
		System.out.println("Running compound interest Method");
		boolean check = false;
		Calendar c1 = Calendar.getInstance();
		Calendar c2 = Calendar.getInstance();
		c1.setTime(CurrentTransDate);
		c2.setTime(NextTransDate);
		int monthDiff = c1.get(Calendar.MONTH) - c2.get(Calendar.MONTH);
		int dayDiff = c1.get(Calendar.DAY_OF_MONTH) - c2.get(Calendar.DAY_OF_MONTH);
		int yearDiff = c1.get(Calendar.YEAR) - c2.get(Calendar.YEAR);
		Integer CurrentTransDateyear = c1.get(Calendar.YEAR);
		Integer NextTransDateYear = c2.get(Calendar.YEAR);

		if (Objects.equals(CurrentTransDateyear, NextTransDateYear)) {
			check = false;
			System.out.println("Compound interest Method returns false");
		} else if (CurrentTransDateyear < NextTransDateYear) {
			
			if(!checkInterestBalance){
				interest+=interestBalance;
				checkInterestBalance=true;
				}
			System.out.println("Compound interest method returns true");
			Double days1 = DifferenceInDays(CurrentTransDate, NextTransDate);
			System.out.println("Total number Of days difference: " + days1);

			if (transType.equals("PURCHASE")) {
				accountBalance += depositAmount;
			} else if (transType.equals("WITHDRAWAL")) {
				accountBalance -= depositAmount;

			}
			
			
			if (days1 <= 365) {
				System.out.println("Compound Interest Method No of days <= 365: " + days1);
				java.sql.Date endYearDate = createSqlDate(CurrentTransDateyear, 12, 31);

				if (addDays(CurrentTransDate, days1.intValue()).compareTo(endYearDate) > 0) {
					System.out.println("Compounding where number of days is less than 365");
					lastInterestDate = getRate(CurrentTransDate, endYearDate, accountBalance);
					Double days2 = DifferenceInDays(lastInterestDate, endYearDate);
					/*System.out.println("number of days till end of year : "+days2);*/
					System.out.println("days from : "+lastInterestDate+"  To ::  "+endYearDate);
					interestCompound= UpdateInterest(accountBalance, Rate, days2);
					interestCompound+=interestGetRate;
					interest=interest+interestCompound;

			/*		System.out.println("AccountBalance before compounding Interest: " + accountBalance);
			*/		
					if(checkCompoundingYear(endYearDate)){
					
					saveCompoundedValues(endYearDate);
					accountBalance += interest;
					interest = 0.00;
					
					}else{
						
						saveInterestValues(endYearDate);
						
					}
					/*System.out.println("AccountBalance after compounding Interest: " + accountBalance);
					*/
					java.sql.Date BeginYearDate = createSqlDate(CurrentTransDateyear + 1, 01, 01);
					/*System.out.println("compound interest new date created 1 " + BeginYearDate.toString());
					*/ 
					lastInterestDate = getRate(endYearDate, NextTransDate, accountBalance);
					double days3 = DifferenceInDays(lastInterestDate, NextTransDate);
					/*System.out.println("number of days after begining of year: " + days3);*/
					System.out.println("days from : "+lastInterestDate+"  To ::  "+NextTransDate);
					interestCompound= UpdateInterest(accountBalance, Rate, days3);
					interestCompound+=interestGetRate;
					interest=interest+interestCompound;
					
						
						saveInterestValues(NextTransDate);
					
					
					
				} else {
					lastInterestDate = getRate(CurrentTransDate, addDays(CurrentTransDate, days1.intValue()),
							accountBalance);
					Double days2 = DifferenceInDays(lastInterestDate, addDays(CurrentTransDate, days1.intValue()));
					System.out.println("days from : "+lastInterestDate+"  To ::  "+addDays(CurrentTransDate, days1.intValue()));
					interestCompound= UpdateInterest(accountBalance, Rate, days2);
					interestCompound+=interestGetRate;
					interest=interest+interestCompound;
					
					
						saveInterestValues(addDays(CurrentTransDate, days1.intValue()));
						
					

				}

			} else if (days1 > 365) {
				
				System.out.println("Compound Interest Method No of days > 365: " + days1);
				java.sql.Date endYearDate = createSqlDate(CurrentTransDateyear, 12, 31);
         if (addDays(CurrentTransDate, days1.intValue()).compareTo(endYearDate) > 0) {
				lastInterestDate = getRate(CurrentTransDate, endYearDate, accountBalance);
				double days2 = DifferenceInDays(lastInterestDate, endYearDate);
				System.out.println("days from : "+lastInterestDate+"  To ::  "+endYearDate);
				interestCompound = UpdateInterest(accountBalance, Rate, days2);
				interestCompound+=interestGetRate;
				interest=interest+interestCompound;
				difference = days1 - days2;
         }else{
        	 
        	 
         }
				if (difference <= 365 ) {
					System.out.println("Compound Interest Method No of days difference <= 365: " + difference);
					if(checkCompoundingYear(endYearDate)){
						
						saveCompoundedValues(endYearDate);
						accountBalance += interest;
						
						interest = 0.00;
						}else{
							
							saveInterestValues(endYearDate);
						}
					if(difference != 0){
					java.sql.Date BeginYearDate = createSqlDate(CurrentTransDateyear + 1, 01, 01);
					/*System.out.println("compound interest new date created 1 " + BeginYearDate.toString());*/
					lastInterestDate = getRate(BeginYearDate, addDays(BeginYearDate, difference.intValue()),
							accountBalance);
					System.out.println("days from : "+lastInterestDate+"  To ::  "+addDays(BeginYearDate, difference.intValue()));
					interestCompound =  UpdateInterest(accountBalance, Rate,
							DifferenceInDays(lastInterestDate, addDays(BeginYearDate, difference.intValue())));
					interestCompound+=interestGetRate;
					interest=interest+interestCompound;
					saveInterestValues(addDays(BeginYearDate, difference.intValue()));
					
					}
				} else if (difference > 365 ) {
					java.sql.Date counterEndYearDate=endYearDate;
					if(checkCompoundingYear(endYearDate)){
						
						saveCompoundedValues(endYearDate);
						accountBalance += interest;
						
						interest = 0.00;
						}else{
							
							saveInterestValues(counterEndYearDate);
						}
					while (difference > 365) {
						countYear++;
						/*System.out.println("Compound Interest Method No of days difference > 365: " + difference);*/
					
						java.sql.Date BeginYearDate = createSqlDate(CurrentTransDateyear + countYear, 01, 01);
						
						
						if(checkLeapYear(addDays(BeginYearDate, 364))){
							
							lastInterestDate = getRate(BeginYearDate, addDays(BeginYearDate, 366), accountBalance);
							System.out.println("days from : "+lastInterestDate+"  To ::  "+ addDays(BeginYearDate, 366));
							interestCompound = UpdateInterest(accountBalance, Rate, DifferenceInDays(lastInterestDate, addDays(BeginYearDate, 365)));
							interestCompound+=interestGetRate;
							interest=interest+interestCompound;
							counterEndYearDate=addDays(BeginYearDate, 365);
						}else{
							
							lastInterestDate = getRate(BeginYearDate, addDays(BeginYearDate, 365), accountBalance);
							System.out.println("days from : "+lastInterestDate+"  To ::  "+ addDays(BeginYearDate, 365));
							interestCompound = UpdateInterest(accountBalance, Rate, DifferenceInDays(lastInterestDate, addDays(BeginYearDate, 365)));
							interestCompound+=interestGetRate;
							interest=interest+interestCompound;
							counterEndYearDate=addDays(BeginYearDate, 364);
							
						}
						difference = difference - 365;
						/*System.out.println("Compound Interest Method No of days difference 2 > 365: " + difference);*/
						if(checkCompoundingYear(counterEndYearDate)&&checkIfEndYear(counterEndYearDate)){
							
							saveCompoundedValues(counterEndYearDate);
							accountBalance += interest;
							
							interest = 0.00;
							}else{
								
								saveInterestValues(counterEndYearDate);
							}
						if (difference < 365) {
							counterEndYearDate=addDays(BeginYearDate, 365);
							countYear++;
							break;
						}
					}
					if (difference <= 365 ) {
						/*System.out.println("DAY DIFFERECE FROM COMPOUND INTEREST:::  "+difference);*/
					java.sql.Date BeginYearDate = createSqlDate(CurrentTransDateyear + countYear, 01, 01);
					java.sql.Date endYearCheckDate = createSqlDate(CurrentTransDateyear + countYear, 12, 31);
						if( difference != 0){
							
							if (addDays(BeginYearDate, difference.intValue()).compareTo(endYearCheckDate) > 0) {
								/*System.out.println("LAST DAY DIFFERECE FROM COMPOUND METHOD:::  "+addDays(BeginYearDate, difference.intValue()).toString());
								*/
								System.out.println("DAY DIFFERECE GREATER LESS THAN END YEAR  ");
						lastInterestDate = getRate(BeginYearDate, addDays(BeginYearDate, difference.intValue()),
								accountBalance);
						System.out.println("days from : "+lastInterestDate+"  To ::  "+ addDays(BeginYearDate, difference.intValue()));
						interestCompound= UpdateInterest(accountBalance, Rate,
								DifferenceInDays(lastInterestDate, addDays(BeginYearDate, difference.intValue())));
							
						interestCompound+=interestGetRate;
						interest=interest+interestCompound;
						
						
						counterEndYearDate=addDays(BeginYearDate, difference.intValue());
						
						saveInterestValues(counterEndYearDate);
						
							
							}else{
								/*System.out.println("LAST DAY DIFFERECE FROM COMPOUND METHOD:::  "+addDays(BeginYearDate, difference.intValue()).toString());*/
								/*System.out.println("DAY DIFFERECE GREATER GREATER THAN END YEAR  "+difference);*/
								difference-=1;
								endYearCheckDate=addDays(BeginYearDate, difference.intValue());
								lastInterestDate = getRate(BeginYearDate, endYearCheckDate,
										accountBalance);
								
								/*System.out.println("END YEAR  DATE :: "+endYearCheckDate);
								System.out.println("LAST INTEREST DATE :: "+lastInterestDate);*/
							if(checkCompoundingYear(endYearCheckDate)&&checkIfEndYear(endYearCheckDate)){
									
									
									saveCompoundedValues(endYearCheckDate);
									accountBalance += interest;
									
									interest = 0.00;
									}
								
							System.out.println("days from : "+lastInterestDate+"  To ::  "+ addDays(BeginYearDate, difference.intValue()));
							interestCompound = UpdateInterest(accountBalance, Rate,
										DifferenceInDays(lastInterestDate, addDays(BeginYearDate, difference.intValue())));
								counterEndYearDate=addDays(BeginYearDate, difference.intValue());
								
								interestCompound+=interestGetRate;
								interest=interest+interestCompound;
								System.out.println("END trans  DATE :: "+counterEndYearDate);
								System.out.println("LAST INTEREST DATE :: "+lastInterestDate);
								saveInterestValues(counterEndYearDate);
							
							}
						}
				
					}

				}

			}

			
			UpdateInterestAccount(memberNumber, interest, accountBalance);
			check = true;
		} 
		return check;

	
	}
	
	
	
	
	public void saveCompoundedValues(java.sql.Date TransDate){
	
		Random rand = new Random();
		Integer value = rand.nextInt(1000000000);
		LocalDatePersistenceConverter date12 = new LocalDatePersistenceConverter();
		connect = javaconnect.connectDb();
		String PostInterest = "INSERT INTO `money_market_transaction_new` (`TRANS_NO`, `TRANS_ID`, `TRANS_TYPE`, `TRANS_DATE`, `TRANS_DATE1`, `MEMBER_NO`, `FULL_NAME`, `ACCOUNT_NO`, `PORTFOLIO`, `MOP`, `AMOUNT`, `INTEREST_AMOUNT`, `U_NAME`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";

		PreparedStatement preparedStatement;
		try {
			preparedStatement = connect.prepareStatement(PostInterest);
			preparedStatement.setString(1, value.toString());
			preparedStatement.setInt(2, value);
			preparedStatement.setString(3, "INTEREST");
			preparedStatement.setString(4, TransDate.toString());
			preparedStatement.setDate(5,TransDate);
			preparedStatement.setString(6, memberNumber);
			preparedStatement.setString(7, FullName);
			preparedStatement.setString(8, memberNumber);
			preparedStatement.setString(9, "Money Market");
			preparedStatement.setString(10, "INTERES_POST");
			preparedStatement.setDouble(11, 0.00);
			preparedStatement.setDouble(12, interestCompound);
			preparedStatement.setString(13, "SYSTEM");

			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Random rand1 = new Random();
		Integer value1 = rand1.nextInt(1000000000);
		LocalDatePersistenceConverter date121 = new LocalDatePersistenceConverter();
		connect = javaconnect.connectDb();
		String PostInterest1 = "INSERT	 INTO moneymarketdeposit(ID,DateOfDeposit,DepositAmount,FullName,MemberNumber,SetByUser,modeOfPayment,transactionNumber) VALUE(0,?,?,?,?,?,?,?);";

		PreparedStatement preparedStatement1;
		try {
			preparedStatement1 = connect.prepareStatement(PostInterest1);
			preparedStatement1.setDate(1, TransDate);
			preparedStatement1.setDouble(2, interest);
			preparedStatement1.setString(3, FullName);
			preparedStatement1.setString(4, memberNumber);
			preparedStatement1.setString(5, "SYSTEM");
			preparedStatement1.setString(6, "RE-INVESTING");
			preparedStatement1.setString(7, value1.toString());

			preparedStatement1.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Random rand2 = new Random();
		Integer value2 = rand2.nextInt(1000000000);
		LocalDatePersistenceConverter date122 = new LocalDatePersistenceConverter();
		connect = javaconnect.connectDb();
		String PostInterest2 = "INSERT	 INTO moneymarketwithdrawal(ID,DateOfWithdrawal,WithdrawalFromInterest,FullName,MemberNumber,SavedByUser,modeOfPayment,transactionNumber) VALUE(0,?,?,?,?,?,?,?);";

		PreparedStatement preparedStatement2;
		try {
			preparedStatement2 = connect.prepareStatement(PostInterest2);
			preparedStatement2.setDate(1, TransDate);
			preparedStatement2.setDouble(2, interest - (interest * 2));
			preparedStatement2.setString(3, FullName);
			preparedStatement2.setString(4, memberNumber);
			preparedStatement2.setString(5, "SYSTEM");
			preparedStatement2.setString(6, "COMPOUNDED_INTEREST");
			preparedStatement2.setString(7, value2.toString());

			preparedStatement2.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}


public void saveInterestValues(java.sql.Date TransDate){
	
		Random rand = new Random();
		Integer value = rand.nextInt(1000000000);
		LocalDatePersistenceConverter date12 = new LocalDatePersistenceConverter();
		connect = javaconnect.connectDb();
		String PostInterest = "INSERT INTO `money_market_transaction_new` (`TRANS_NO`, `TRANS_ID`, `TRANS_TYPE`, `TRANS_DATE`, `TRANS_DATE1`, `MEMBER_NO`, `FULL_NAME`, `ACCOUNT_NO`, `PORTFOLIO`, `MOP`, `AMOUNT`, `INTEREST_AMOUNT`, `U_NAME`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";

		PreparedStatement preparedStatement;
		try {
			preparedStatement = connect.prepareStatement(PostInterest);
			preparedStatement.setString(1, value.toString());
			preparedStatement.setInt(2, value);
			preparedStatement.setString(3, "INTEREST");
			preparedStatement.setString(4, TransDate.toString());
			preparedStatement.setDate(5,TransDate);
			preparedStatement.setString(6, memberNumber);
			preparedStatement.setString(7, FullName);
			preparedStatement.setString(8, memberNumber);
			preparedStatement.setString(9, "Money Market");
			preparedStatement.setString(10, "INTERES_POST");
			preparedStatement.setDouble(11, 0.00);
			preparedStatement.setDouble(12, interestCompound);
			preparedStatement.setString(13, "SYSTEM");

			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}


	private java.sql.Date createSqlDate(int year, int month, int day) {

		// Create a date string with leading zeros for month and day.
		String dateString = String.format("%d-%02d-%02d", year, month, day);

		return java.sql.Date.valueOf(dateString);
	}

	public void UpdateInterestAccount(String memberNumber, double interest, double accountBalance) throws SQLException {
		LocalDatePersistenceConverter date12 = new LocalDatePersistenceConverter();
		connect = javaconnect.connectDb();
		String sql = "SELECT * FROM `moneymarketaccounts` WHERE `MemberNumber`='";
		sql = sql.concat(memberNumber);
		sql = sql.concat("'");
		statement = connect.prepareStatement(sql, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
		ResultSet rs = statement.executeQuery();
		while (rs.next()) {
			double balance = rs.getDouble("AccountBalance");
			double interestbalance = rs.getDouble("Interest");
			rs.updateDouble("Interest", (interest + interestbalance));
			System.out.println("Interest Committed to the DB from local variable : " + interest);
			System.out.println("Interest Committed to the DB from static variable : " + this.interest);
			rs.updateDouble("AccountBalance", accountBalance);
			System.out.println("Account Balance Committed to DB from local: " + accountBalance);
			System.out.println("Account Balance Committed to DB from static variable: " + this.accountBalance);

			rs.updateDate("Date & Time", date12.convertToDatabaseColumn(LocalDate.now()));
			rs.updateRow();
		}

	}

	public double UpdateInterest(double accountBalance, double rate, double time) {
		double inter=0.00;
		if(accountBalance<0.00){
			System.out.println("Account balance lessthan 0.00");
			accountBalance=0.00;
		}
		System.out.println("Principal from UpdateInterest method: " + accountBalance);
		System.out.println("Rate from UpdateInterest method: " + rate);
		System.out.println("Time from UpdateInterest method: " + time);
		if (time == 0) {
			inter = accountBalance * rate / 36400 * 1;
			System.out.println("interest from UpdateInterest method: " + inter);
		} else {
			inter = accountBalance * rate / 36400 * time;
			System.out.println("interest from UpdateInterest method: " + inter);
		}
		return inter;
	}

	public final static long MILLISECONDS_IN_DAY = 24 * 60 * 60 * 1000;

	public static double DifferenceInDays(Date from, Date to) {
		return (double) ((to.getTime() - from.getTime()) / MILLISECONDS_IN_DAY);
	}

	public boolean checkIfEndYear(Date date) {
		boolean check = false;
		Calendar c1 = Calendar.getInstance();
		c1.setTime(date);
		int month = c1.get(Calendar.MONTH);
		int day = c1.get(Calendar.DAY_OF_MONTH);
		System.out.println("day of the mothn:" + day + " month of the year: " + month);
		int yearDiff = c1.get(Calendar.YEAR);
		if (month + 1 == 12 && day == 31) {
			check = true;
			System.out.println("End of year is true");
		} else {
			System.out.println("End of year is false");
		}
		return check;
	}
	
	
	
	
	public boolean checkCompoundingYear(Date date) {
		boolean check = false;
		Calendar c1 = Calendar.getInstance();
		c1.setTime(date);
		
		
		int yearDiff = c1.get(Calendar.YEAR);
		if (yearDiff>=2014) {
			check = true;
			System.out.println("Compounding year is true");
		} else {
			System.out.println("Compounding year is false");
		}
		return check;
	}
	
	
	public boolean checkLeapYear(Date date){
		boolean check = false;
		Calendar c1 = Calendar.getInstance();
		c1.setTime(date);
		
		
		int yearDiff = c1.get(Calendar.YEAR);
		boolean isLeapYear=((yearDiff % 4 ==0)&&(yearDiff % 100!=0)||(yearDiff % 400 ==0));
		
		if(isLeapYear){
			check=true;
			
		}else{
			check=false;
			
		}
		
		
		return check;
	}
	
	public java.sql.Date returnEndYear(Date date) {
		
		Calendar c1 = Calendar.getInstance();
		c1.setTime(date);
		int month = c1.get(Calendar.MONTH);
		int day = c1.get(Calendar.DAY_OF_MONTH);
		
		int yearDiff = c1.get(Calendar.YEAR);
		date=createSqlDate(yearDiff, 01, 01);
		return date;
	}
	
	public double interestBalance(java.sql.Date dbSqlCurrentDate22,String MemberNumber){
		interestBalance=0.00;
		System.out.println("LastInterestCompound  :  "+dbSqlCurrentDate22.toString());
		String sql = "SELECT * FROM money_market_transaction_new WHERE MEMBER_NO='";
		sql = sql.concat(MemberNumber);
		sql = sql.concat("'  AND (TRANS_TYPE='INTEREST' OR (`money_market_transaction_new`.`TRANS_DATE1`>='");
		sql = sql.concat(dbSqlCurrentDate22.toString());
		sql = sql.concat("' AND TRANS_TYPE='INTERES_POST'))  ORDER BY `money_market_transaction_new`.`TRANS_DATE1` ASC;");
		try {
			statement = connect.prepareStatement(sql);
			ResultSet rs = statement.executeQuery();
			
			while(rs.next()){
			
			double depositAmount=rs.getDouble("AMOUNT");
			 interestBalance+=depositAmount;
				
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		checkInterestBalance=false;
		Double interestB=interestBalance;
		System.out.println(interestB.intValue());
		
		System.out.println("Accrude db interest Balance"+interestBalance +" System Start Interest Balance :  "+ interest);
		return interestBalance;
		
		
	}
	



}
/*SELECT * FROM money_market_transaction_new WHERE MEMBER_NO='000010181' AND `money_market_transaction_new`.`TRANS_DATE1`>='2017-01-01'  AND (TRANS_TYPE='INTERES_POST' OR TRANS_TYPE='INTEREST')  ORDER BY `money_market_transaction_new`.`TRANS_DATE1` ASC;
*/


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Zimele_main;

import DataBaseConnector.javaconnect;
import Zimele_Admin.JaspytPasswordEncryptor;
import Zimele_Admin.Zimele_AdminController;
import Zimele_Back_Office.Back_Office_ModuleController;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import static javafx.application.Application.STYLESHEET_CASPIAN;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import zimele_information_management_system.FXMLDocumentController;


/**
 * FXML Controller class
 *
 * @author james kamau
 */
public class Zimele_LogInController implements Initializable {
    @FXML
    private Button Log_In_Btn;
    @FXML
    private ChoiceBox<String> userTypeBtn = new ChoiceBox<>();
    @FXML
    private TextField UserNamefield= new TextField();
    @FXML
    private PasswordField password= new PasswordField();
    Connection connect;
    PreparedStatement statement;
    ResultSet result;
   
    
    

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       userTypeBtn.getItems().addAll("Admin","BackOffice","FrontOffice"); 
       userTypeBtn.setValue("Admin");
    }    

    private static String pass;
    @FXML
    private void log_In(ActionEvent event) {
        String selectedValue=userTypeBtn.getValue();
        String firstName=UserNamefield.getText();
       String pass=password.getText();
        if(selectedValue=="FrontOffice"){
            try {
                if(Authenticate(firstName,pass,selectedValue)){
                    try {
                        Alert alert2= new Alert(Alert.AlertType.INFORMATION);
                        alert2.setContentText("Log In Successful");
                        alert2.showAndWait();
                        FXMLDocumentController.setUserName(firstName);
                        FXMLDocumentController.setUserType("FrontOffice");
                        FXMLDocumentController.setPassword(Zimele_LogInController.pass);
                        Parent  root;
                        root = FXMLLoader.load(getClass().getResource("/zimele_information_management_system/Zimele_Front_Office.fxml"));
                        Scene scene = new Scene(root);
                        scene.getStylesheets().add(STYLESHEET_CASPIAN);
                        Stage stage =  (Stage)((Node)event.getSource()).getScene().getWindow();
                        stage.setScene(scene);
                        stage.show();
                        
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(Zimele_LogInController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                }else{
                Alert alert2= new Alert(Alert.AlertType.INFORMATION);
                alert2.setContentText("Wrong UserName Or Password");
                alert2.showAndWait();
                }
            } catch (SQLException ex) {
                Logger.getLogger(Zimele_LogInController.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        }else if(selectedValue=="BackOffice"){
            try {
                if(Authenticate(firstName,pass,selectedValue)){
                    
                    try {
                        
                        Alert alert2= new Alert(Alert.AlertType.INFORMATION);
                        alert2.setContentText("Log In Successful");
                        alert2.showAndWait();
                        Back_Office_ModuleController.setUserName(firstName);
                        Back_Office_ModuleController.setUserType("BackOffice");
                        Back_Office_ModuleController.setPass(Zimele_LogInController.pass);
                        Parent  root = FXMLLoader.load(getClass().getResource("/Zimele_Back_Office/Back_Office_Module.fxml"));
                        Scene scene = new Scene(root);
                        scene.getStylesheets().add(STYLESHEET_CASPIAN);
                        Stage stage =  (Stage)((Node)event.getSource()).getScene().getWindow();
                        stage.setScene(scene);
                        stage.show();
                        
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(Zimele_LogInController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }else{
                Alert alert2= new Alert(Alert.AlertType.INFORMATION);
                alert2.setContentText("Wrong UserName Or Password");
                alert2.showAndWait();
                }     } catch (SQLException ex) {
                Logger.getLogger(Zimele_LogInController.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        }else if(selectedValue=="Admin"){
            
            try {
                if(Authenticate(firstName,pass,selectedValue)){
                    try {
                 Alert alert2= new Alert(Alert.AlertType.INFORMATION);
                 alert2.setContentText("Log In Successful");
                 alert2.showAndWait();
                 		Zimele_AdminController.setUserName(firstName);
                 		Zimele_AdminController.setUserType("Admin");
                 		Zimele_AdminController.setPass(Zimele_LogInController.pass);
                        Parent  root;
                        root = FXMLLoader.load(getClass().getResource("/Zimele_Admin/Zimele_Admin.fxml"));
                        Scene scene = new Scene(root);
                        scene.getStylesheets().add(STYLESHEET_CASPIAN);
                        Stage stage =  (Stage)((Node)event.getSource()).getScene().getWindow();
                        stage.setScene(scene);
                        stage.show();
                        
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(Zimele_LogInController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                    
                }else{
                Alert alert2= new Alert(Alert.AlertType.INFORMATION);
                alert2.setContentText("Wrong UserName Or Password");
                alert2.showAndWait();
                }   } catch (SQLException ex) {
                Logger.getLogger(Zimele_LogInController.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        }
    }
    static int count=1;
    public boolean Authenticate(String userName,String password,String userType) throws SQLException{
        JaspytPasswordEncryptor encryptor= new JaspytPasswordEncryptor();
      
        connect=javaconnect.connectDb1();
        String sql1="select * FROM  `userdatatable` where `UserName`='";
        sql1=sql1.concat(userName);
        sql1=sql1.concat("'");
        
        statement = connect.prepareStatement(sql1);
         ResultSet rs=statement.executeQuery();
        count=1;
        while(rs.next()){
         
            String userName1=rs.getString("UserName");
            if(userName.equals(userName1)){
               
              break;
            }
        count++;
        }
        Zimele_LogInController.pass=rs.getString("password");
        rs.absolute(count);
        String pass=encryptor.getDecryptedString(rs.getString("password"));
        System.out.println("Password is::: "+pass);
        String usertype=rs.getString("userType");
          
        return pass.equals(password)&usertype.equals(userType);
       
    
     
    }
    
}
        
        
        
        
       

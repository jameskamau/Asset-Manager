

package HomeOwnership;

import DateConverter.LocalDatePersistenceConverter;
import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author james kamau
 */
@Entity
public class HomeOwnershipDeposit implements Serializable {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="ID")
    private int id;
    
    private String MemberNumber;
    private String fullName;
    private String DepositAmount;
    private String ModeOfPayment;
    @Convert(converter = LocalDatePersistenceConverter.class)
    private LocalDate DateOfDeposit ;
    private String SavedByUser;
    private String transactionNumber;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the MemberNumber
     */
    public String getMemberNumber() {
        return MemberNumber;
    }

    /**
     * @param MemberNumber the MemberNumber to set
     */
    public void setMemberNumber(String MemberNumber) {
        this.MemberNumber = MemberNumber;
    }

    /**
     * @return the fullName
     */
    public String getFullName() {
        return fullName;
    }

    /**
     * @param fullName the fullName to set
     */
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    /**
     * @return the DepositAmount
     */
    public String getDepositAmount() {
        return DepositAmount;
    }

    /**
     * @param DepositAmount the DepositAmount to set
     */
    public void setDepositAmount(String DepositAmount) {
        this.DepositAmount = DepositAmount;
    }

    /**
     * @return the ModeOfPayment
     */
    public String getModeOfPayment() {
        return ModeOfPayment;
    }

    /**
     * @param ModeOfPayment the ModeOfPayment to set
     */
    public void setModeOfPayment(String ModeOfPayment) {
        this.ModeOfPayment = ModeOfPayment;
    }

    /**
     * @return the DateOfDeposit
     */
    public LocalDate getDateOfDeposit() {
        return DateOfDeposit;
    }

    /**
     * @param DateOfDeposit the DateOfDeposit to set
     */
    public void setDateOfDeposit(LocalDate DateOfDeposit) {
        this.DateOfDeposit = DateOfDeposit;
    }

    /**
     * @return the SavedByUser
     */
    public String getSetByUser() {
        return SavedByUser;
    }

    /**
     * @param SetByUser the SavedByUser to set
     */
    public void setSetByUser(String SetByUser) {
        this.SavedByUser = SetByUser;
    }

    /**
     * @return the transactionNumber
     */
    public String getTransactionNumber() {
        return transactionNumber;
    }

    /**
     * @param transactionNumber the transactionNumber to set
     */
    public void setTransactionNumber(String transactionNumber) {
        this.transactionNumber = transactionNumber;
    }
    
    
}

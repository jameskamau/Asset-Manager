
package HomeOwnership;

import DateConverter.LocalDatePersistenceConverter;
import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author james kamau
 */

@Entity
public class HomeOwnershipWithdrawal implements Serializable {
    
     @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="ID")
    private int id;
    
    private String MemberNumber;
    private String fullName;
    private String withdrawFromPrincipal;
    private String withdrawFromInterest;
    @Convert(converter = LocalDatePersistenceConverter.class)
    private LocalDate DateOfWithdrawal ;
    private String SavedByUser;
    private String transactionNumber;
    
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the MemberNumber
     */
    public String getMemberNumber() {
        return MemberNumber;
    }

    /**
     * @param MemberNumber the MemberNumber to set
     */
    public void setMemberNumber(String MemberNumber) {
        this.MemberNumber = MemberNumber;
    }

    /**
     * @return the fullName
     */
    public String getFullName() {
        return fullName;
    }

    /**
     * @param fullName the fullName to set
     */
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    /**
     * @return the withdrawFromPrincipal
     */
    public String getWithdrawFromPrincipal() {
        return withdrawFromPrincipal;
    }

    /**
     * @param withdrawFromPrincipal the withdrawFromPrincipal to set
     */
    public void setWithdrawFromPrincipal(String withdrawFromPrincipal) {
        this.withdrawFromPrincipal = withdrawFromPrincipal;
    }

    /**
     * @return the withdrawFromInterest
     */
    public String getWithdrawFromInterest() {
        return withdrawFromInterest;
    }

    /**
     * @param withdrawFromInterest the withdrawFromInterest to set
     */
    public void setWithdrawFromInterest(String withdrawFromInterest) {
        this.withdrawFromInterest = withdrawFromInterest;
    }

    /**
     * @return the DateOfWithdrawal
     */
    public LocalDate getDateOfWithdrawal() {
        return DateOfWithdrawal;
    }

    /**
     * @param DateOfWithdrawal the DateOfWithdrawal to set
     */
    public void setDateOfWithdrawal(LocalDate DateOfWithdrawal) {
        this.DateOfWithdrawal = DateOfWithdrawal;
    }

    /**
     * @return the SavedByUser
     */
    public String getSetByUser() {
        return SavedByUser;
    }

    /**
     * @param SetByUser the SavedByUser to set
     */
    public void setSetByUser(String SetByUser) {
        this.SavedByUser = SetByUser;
    }

    /**
     * @return the transactionNumber
     */
    public String getTransactionNumber() {
        return transactionNumber;
    }

    /**
     * @param transactionNumber the transactionNumber to set
     */
    public void setTransactionNumber(String transactionNumber) {
        this.transactionNumber = transactionNumber;
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SMSNotify;

import DataBaseConnector.javaconnect;
import EmailNotify.SendMail;
import EmailReports.SendStatementMail;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.ProtocolException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import zimele_information_management_system.FXMLDocumentController;


/**
 *
 * @author james kamau
 */
public class SendMonthlySmS {
     PreparedStatement statement;
    ResultSet result;
    Connection connect;

   
    
     public void sendSMSBalance() {
 
        try {
            Integer MM;
            Integer BF;
            Integer HO;
            Integer PP;
            Integer GP;
           
            
            connect=javaconnect.connectDb1();
            String sqlGP="SELECT DISTINCT(MemberNumber), MarketValue FROM `garanteedpensionaccounts WHERE MarketValue >10";
            String sqlMM="SELECT DISTINCT (MemberNumber), MarketValue FROM `moneymarketaccounts` WHERE MarketValue >10";
            String sqlBF="SELECT DISTINCT (MemberNumber), CurrentValue FROM `balacefundaccounts` WHERE CurrentValue >10";
            String sqlPP="SELECT DISTINCT (MemberNumber),CurrentValue FROM `personalpensionpurchase` WHERE CurrentValue >10";
            String sqlHO="SELECT DISTINCT (MemberNumber) FROM `homeownershipaccounts`";
            
            statement = connect.prepareStatement(sqlGP);
            ResultSet rs = statement.executeQuery();
            
            while(rs.next()){
                try{
                GP=rs.getInt("MemberNumber");
                String name=rs.getString("FullName");
               String phoneNumber="SELECT * FROM `personalinformation` WHERE `memberNumber`='";
                 phoneNumber=phoneNumber.concat(GP.toString()); phoneNumber=phoneNumber.concat("' AND FullName='");phoneNumber=phoneNumber.concat(name);
                phoneNumber=phoneNumber.concat("'AND phoneNumber LIKE '07%' OR phoneNumber LIKE '+254%'");
                statement=connect.prepareStatement(phoneNumber);
                ResultSet rs5 = statement.executeQuery();
                 String phoneNumber1= rs5.getString("phoneNumber");
                 int marketValue=rs5.getInt("MarketValue");
                 sendSmS(phoneNumber1,marketValue);
                }catch(Exception e){}
                
               }
            statement = connect.prepareStatement(sqlMM);
            ResultSet rs1 = statement.executeQuery();
            
            while(rs1.next()){
                try{
                MM=rs1.getInt("MemberNumber");
                String name=rs1.getString("FullName");
                String phoneNumber="SELECT * FROM `personalinformation` WHERE `memberNumber`='";
                 phoneNumber=phoneNumber.concat(MM.toString());   phoneNumber=phoneNumber.concat("' AND  FullName='");  phoneNumber=phoneNumber.concat(name);
                phoneNumber=phoneNumber.concat("' AND phoneNumber LIKE '07%' OR phoneNumber LIKE '+254%'");
                statement=connect.prepareStatement(phoneNumber);
                ResultSet rs5 = statement.executeQuery();
                 String phoneNumber1= rs5.getString("phoneNumber");
                  int marketValue=rs5.getInt("MarketValue");
                  sendSmS(phoneNumber1,marketValue);
                }catch(Exception e){}
               
            }
            
            statement = connect.prepareStatement(sqlBF);
            ResultSet rs2 = statement.executeQuery();
            
            while(rs2.next()){
                try{
               BF=rs2.getInt("MemberNumber");
               String name=rs2.getString("FullName");
                String phoneNumber="SELECT * FROM `personalinformation` WHERE `memberNumber`='";
                 phoneNumber=phoneNumber.concat(BF.toString());  phoneNumber=phoneNumber.concat("' AND FullName='"); phoneNumber=phoneNumber.concat(name);
                phoneNumber=phoneNumber.concat("' AND phoneNumber LIKE '07%' OR phoneNumber LIKE '+254%'");
                statement=connect.prepareStatement(phoneNumber);
                ResultSet rs5 = statement.executeQuery();
                 String phoneNumber1= rs5.getString("phoneNumber");         
                double CurrentValue=rs5.getDouble("CurrentValue");
                 sendSmS(phoneNumber1,CurrentValue);
                }catch(Exception e){}
                
               
            }
            
            statement = connect.prepareStatement(sqlPP);
            ResultSet rs3 = statement.executeQuery();
            
            while(rs3.next()){
                try{
                 PP=rs3.getInt("MemberNumber");
                String name=rs3.getString("FullName");
                 String phoneNumber="SELECT * FROM `personalinformation` WHERE `memberNumber`=";
                phoneNumber=phoneNumber.concat(PP.toString()); phoneNumber=phoneNumber.concat("' AND FullName='"); phoneNumber=phoneNumber.concat(name);
                phoneNumber=phoneNumber.concat("' AND phoneNumber LIKE '07%' OR phoneNumber LIKE '+254%'");
                statement=connect.prepareStatement(phoneNumber);
                ResultSet rs5 = statement.executeQuery();
                String phoneNumber1= rs5.getString("phoneNumber");
                double CurrentValue=rs5.getDouble("CurrentValue");
                 sendSmS(phoneNumber1,CurrentValue);
                }catch(Exception e){}
               
                
            }
            
            
             statement = connect.prepareStatement(sqlHO);
        ResultSet rs4 = statement.executeQuery();
            
//          while(rs4.next()){
//              
//               HO=rs4.getInt("MemberNumber");
//           String HOsql ="SELECT * from `homeownershipaccounts` WHERE `MemberNumber`=";
//            HOsql=HOsql.concat("'"); HOsql=HOsql.concat(HO.toString());
//            HOsql=HOsql.concat("'");HOsql=HOsql.concat(";");
//          
//          String phoneNumber="SELECT * FROM `personalinformation` WHERE `memberNumber`=";
//                phoneNumber=phoneNumber.concat("'"); phoneNumber=phoneNumber.concat(HO.toString());
//                phoneNumber=phoneNumber.concat("'");phoneNumber=phoneNumber.concat(";");
//                statement=connect.prepareStatement(phoneNumber);
//                ResultSet rs5 = statement.executeQuery();
//                String phoneNumber1= rs5.getString("phoneNumber");
//       
//          }
        } catch (SQLException ex) {
            Logger.getLogger(SendStatementMail.class.getName()).log(Level.SEVERE, null, ex);
        }
      }
     
   public void sendSmS(String Number,Integer amount){
    
     SendSms sms=new SendSms();
     sms.setAmount(amount.toString());
     sms.getPhoneNumber1(Number);
        try {
            sms.sendSMS();
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ProtocolException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    
    
    }
   public void sendSmS(String Number,Double amount){
    
     SendSms sms=new SendSms();
     
     sms.setAmount(amount.toString());
     sms.getPhoneNumber1(Number);
        try {
            sms.sendSMS();
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ProtocolException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    
    
    }
    
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package SMSNotify;

import java.io.*;
import java.net.*;
import java.util.LinkedHashMap;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author James kamau
 */
public class SmsApi {
    
    private static String username, password, account;
    
   /* public SmsApi(String username, String password, String account) {
        this.username = username;
        this.password = password;
        this.account = account;
    }*/
    
    public static String SendText(String phone, String msg) throws MalformedURLException, UnsupportedEncodingException, ProtocolException, IOException {
        URL url = new URL("http://quadrantsoftwares.com/one_api/sms.php?u="+SmsApi.username+"&p="+SmsApi.password+"&a="+SmsApi.account);
        Map<String,Object> params = new LinkedHashMap<>();
        params.put("phone", phone);
        params.put("message",msg);

        StringBuilder postData = new StringBuilder();
        for (Map.Entry<String,Object> param : params.entrySet()) {
            if (postData.length() != 0) postData.append('&');
            postData.append(URLEncoder.encode(param.getKey(), "UTF-8"));
            postData.append('=');
            postData.append(URLEncoder.encode(String.valueOf(param.getValue()), "UTF-8"));
        }
        byte[] postDataBytes = postData.toString().getBytes("UTF-8");

        HttpURLConnection conn = (HttpURLConnection)url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        conn.setRequestProperty("Content-Length", String.valueOf(postDataBytes.length));
        conn.setDoOutput(true);
        conn.getOutputStream().write(postDataBytes);

        Reader in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
        
        String ret = "";

        for (int c; (c = in.read()) >= 0;)
            ret += (char)c;
        
        return ret;
    }
    
    public static void sendText(String recipients,String message){
        // Specify your login credentials
        String username = "zimele";
        String apiKey   = "8837b09fc27c826cce9f1b6779a1e078d654da088711d2649d30fea3b171f429";
        // Specify the numbers that you want to send to in a comma-separated list
        // Please ensure you include the country code (+254 for Kenya in this case)
        /*String recipients = "+254715576211";*/
        // And of course we want our recipients to know what we really do
       /* String message = " Zimele Asset Management,Investing in your future. SMS Promotion";*/
        // Create a new instance of our awesome gateway class
        
        String from ="Zimele";
        AfricasTalkingGateway gateway  = new AfricasTalkingGateway(username, apiKey);
        /*************************************************************************************
            NOTE: If connecting to the sandbox:
            1. Use "sandbox" as the username
            2. Use the apiKey generated from your sandbox application
                https://account.africastalking.com/apps/sandbox/settings/key
            3. Add the "sandbox" flag to the constructor
            AfricasTalkingGateway gateway = new AfricasTalkingGateway(username, apiKey, "sandbox");
        **************************************************************************************/
        // Thats it, hit send and we'll take care of the rest. Any errors will
        // be captured in the Exception class below
        try {
            JSONArray results = gateway.sendMessage(recipients, message, from);
            for( int i = 0; i < results.length(); ++i ) {
                JSONObject result = results.getJSONObject(i);
                System.out.print(result.getString("status") + ","); // status is either "Success" or "error message"
                System.out.print(result.getString("number") + ",");
                System.out.print(result.getString("messageId") + ",");
                System.out.println(result.getString("cost"));
            }
        } catch (Exception e) {
            System.out.println("Encountered an error while sending " + e.getMessage());
        }
    }
    
}

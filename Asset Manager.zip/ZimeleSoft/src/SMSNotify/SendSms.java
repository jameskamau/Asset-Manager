/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package SMSNotify;


import DataBaseConnector.JavaFirebirdconnect;
import DataBaseConnector.javaconnect;
import java.io.*;
import java.net.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author james kamau
 */
public class SendSms {

    /**
     * @return the fullName
     */
    public String getFullName() {
        return fullName;
    }

    /**
     * @param fullName the fullName to set
     */
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
    
    PreparedStatement statement;
    ResultSet result;
    Connection connect;
    
    
    private String phoneNumber;
    private String Amount;
    private String memberNumber;
    private String fullName;
    String fullName1;
    

    static int count=1;
      public void getPhoneNumber1(String number){
       phoneNumber=number;
     }
   
   public void getPhoneNumber(String fundType) throws SQLException{
	   String sql="";
	   
	   if(fundType.equals("UNIT_TRUST")){
		   connect = JavaFirebirdconnect.connectDb();
		   
		   sql= "select * from MEMBERS where MEMBER_NO='";
           sql=sql.concat(memberNumber+"'");
		   
       	  }else if(fundType.equals("PENSION")){
       	
       		connect = JavaFirebirdconnect.connectDb1();
       	 sql= "select * from MEMBERS where MEMBER_NO='";
         sql=sql.concat(memberNumber+"'");
 
       }
   
    
             statement = connect.prepareStatement(sql);
            ResultSet rs1 = statement.executeQuery();
            
           
            while(rs1.next()){
                 phoneNumber=rs1.getString("GSM_NO");
            fullName1=rs1.getString("ALLNAMES");
             System.out.println("phone Number :"+phoneNumber);
            System.out.println("full Name :"+fullName1);
           
            }
            
            
            
        
        	
    
        
       
   
   
   }
   
    
    
    public void sendSMS() throws MalformedURLException, UnsupportedEncodingException, ProtocolException, IOException {
    
   /*    String username = "Zimele"; //initialize username here
      String password = "5VoexD0d"; //initialize password here
      String acct = "zimele"; //initialize sender name here
      String number1="0715576211";
       String number2="0715576211";*/
      SmsApi smsApi = new SmsApi();
      String  SMSContent="Dear Customer ";
      SMSContent= SMSContent.concat(fullName1);
      SMSContent= SMSContent.concat(" Member Number : ");
      SMSContent= SMSContent.concat(memberNumber);
      SMSContent= SMSContent.concat(" , ZIMELE wishes to notify you that KSH: ");
      SMSContent= SMSContent.concat(Amount);
      SMSContent= SMSContent.concat(" has been deposited in your Account");
      
      SmsApi.sendText(phoneNumber, SMSContent);

    
    
    
    }
    
    public void sendSMSWithdrawal() throws MalformedURLException, UnsupportedEncodingException, ProtocolException, IOException {
        
   /*    String username = "Zimele"; //initialize username here
      String password = "5VoexD0d"; //initialize password here
      String acct = "zimele"; //initialize sender name here
      String number1="0715576211";
       String number2="0715576211";*/
      SmsApi smsApi = new SmsApi();
      String  SMSContent="Dear Customer ";
      SMSContent= SMSContent.concat(fullName1);
      SMSContent= SMSContent.concat(" Member Number : ");
      SMSContent= SMSContent.concat(memberNumber);
      SMSContent= SMSContent.concat(" , ZIMELE wishes to notify you that KSH: ");
      SMSContent= SMSContent.concat(Amount);
      SMSContent= SMSContent.concat(" has been withdrawn  from your account");
      
      SmsApi.sendText(phoneNumber, SMSContent);

    
    
    
    }

    /**
     * @return the memberNumber
     */
    public String getMemberNumber() {
        return memberNumber;
    }

    /**
     * @param memberNumber the memberNumber to set
     */
    public void setMemberNumber(String memberNumber) {
        this.memberNumber = memberNumber;
    }

    /**
     * @return the Amount
     */
    public String getAmount() {
        return Amount;
    }

    /**
     * @param Amount the Amount to set
     */
    public void setAmount(String Amount) {
        this.Amount = Amount;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package FundTransfer;

import DataBaseConnector.javaconnect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author james kamau
 */
public class UnitTrustTransfer {
    
    Connection connect;
    PreparedStatement statement;
    ResultSet result;
    
    private String memberNumber;
    private String transferAmount;
    
    static int count;
    static int count1;
    public void MoneyMarketToBalanceFundTransfer() throws SQLException{
    connect=javaconnect.connectDb();
    
    
    String sql="select * from moneymarketaccounts WHERE `MemberNumber`='";
    sql=sql.concat(memberNumber);
    sql=sql.concat("'");
    statement = connect.prepareStatement(sql,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
        ResultSet rs1 = statement.executeQuery();
        System.out.println("this is the memberNumber from the input field"+memberNumber);
       count=1;
//        while(rs1.next()){
//         
//            String membernumber=rs1.getString("MemberNumber");
//            System.out.println("MemberNumbers from db"+membernumber);
//            int number=Integer.parseInt(membernumber);
//            if(number==Integer.parseInt(memberNumber)){
//               System.out.println("selected MemberNumber"+memberNumber);
//              break;
//            }
//        count++;
//        }
      
       
       rs1.next();
       double accountBalance= rs1.getDouble("AccountBalance");
      double transferamount=Double.parseDouble(transferAmount);
      double newAccountBalance=accountBalance-transferamount;
      rs1.updateDouble("AccountBalance", newAccountBalance);
      rs1.updateRow();
      
       
       
       
       
    
    }
    
    public void BalanceFundToMoneyMarket() throws SQLException{
        
        connect=javaconnect.connectDb();
    
    String sql="select * from moneymarketaccounts WHERE `MemberNumber`='";
    sql=sql.concat(memberNumber);
    sql=sql.concat("'");
    statement = connect.prepareStatement(sql,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
        ResultSet rs1 = statement.executeQuery();
        
//       count1=1;
//        while(rs1.next()){
//         
//            String membernumber=rs1.getString("MemberNumber");
//            if(Integer.parseInt(membernumber)==Integer.parseInt(memberNumber)){
//               
//              break;
//            }
//        count1++;
//        }
      
       
       rs1.next();
      double accountBalance= rs1.getDouble("AccountBalance");
      double transferamount=Double.parseDouble(transferAmount);
      double newAccountBalance=accountBalance+transferamount;
      rs1.updateDouble("AccountBalance", newAccountBalance);
      rs1.updateRow();
    
    
    }
    /**
     * @return the memberNumber
     */
    public String getMemberNumber() {
        return memberNumber;
    }

    /**
     * @param memberNumber the memberNumber to set
     */
    public void setMemberNumber(String memberNumber) {
        this.memberNumber = memberNumber;
    }

    /**
     * @return the transferAmount
     */
    public String getTransferAmount() {
        return transferAmount;
    }

    /**
     * @param transferAmount the transferAmount to set
     */
    public void setTransferAmount(String transferAmount) {
        this.transferAmount = transferAmount;
    }
    
}

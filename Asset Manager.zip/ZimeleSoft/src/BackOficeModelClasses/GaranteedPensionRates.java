/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package BackOficeModelClasses;

import DateConverter.LocalDatePersistenceConverter;
import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author james kamau
 */
@Entity
public class GaranteedPensionRates implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="ID")
    private int id;
    @Convert(converter = LocalDatePersistenceConverter.class)
    private LocalDate SetOnDate;
    private double generalRate;
    private String setByUserName;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    

    /**
     * @return the generalRate
     */
    public double getGeneralRate() {
        return generalRate;
    }

    /**
     * @param generalRate the generalRate to set
     */
    public void setGeneralRate(double generalRate) {
        this.generalRate = generalRate;
    }

    /**
     * @return the setByUserName
     */
    public String getSetByUserName() {
        return setByUserName;
    }

    /**
     * @param setByUserName the setByUserName to set
     */
    public void setSetByUserName(String setByUserName) {
        this.setByUserName = setByUserName;
    }

    /**
     * @return the SetOnDate
     */
    public LocalDate getSetOnDate() {
        return SetOnDate;
    }

    /**
     * @param SetOnDate the SetOnDate to set
     */
    public void setSetOnDate(LocalDate SetOnDate) {
        this.SetOnDate = SetOnDate;
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package BackOficeModelClasses;

import DateConverter.LocalDatePersistenceConverter;
import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author james kamau
 */
@Entity
public class PersonalPensionSetRates implements Serializable {
     @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="ID")
    private int id;
    @Convert(converter = LocalDatePersistenceConverter.class)
    private LocalDate setOnDate;
    private double buyPrice;
    private double sellPrice;
    private String setByUserName;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    
    

    /**
     * @return the setByUserName
     */
    public String getSetByUserName() {
        return setByUserName;
    }

    /**
     * @param setByUserName the setByUserName to set
     */
    public void setSetByUserName(String setByUserName) {
        this.setByUserName = setByUserName;
    }

    /**
     * @return the setOnDate
     */
    public LocalDate getSetOnDate() {
        return setOnDate;
    }

    /**
     * @param setOnDate the setOnDate to set
     */
    public void setSetOnDate(LocalDate setOnDate) {
        this.setOnDate = setOnDate;
    }

    /**
     * @return the buyPrice
     */
    public double getBuyPrice() {
        return buyPrice;
    }

    /**
     * @param buyPrice the buyPrice to set
     */
    public void setBuyPrice(double buyPrice) {
        this.buyPrice = buyPrice;
    }

    /**
     * @return the sellPrice
     */
    public double getSellPrice() {
        return sellPrice;
    }

    /**
     * @param sellPrice the sellPrice to set
     */
    public void setSellPrice(double sellPrice) {
        this.sellPrice = sellPrice;
    }
    
}


package Registration;

import DateConverter.LocalDatePersistenceConverter;
import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author james kamau
 */
@Entity
public class InvestmentApplication implements Serializable {
    
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="ID")
    private int id;
    
    private String MemberNumber;
    
    private String FullName;
    
    private String AccountType;
    
    private String InvestmentType;
    
   @Convert(converter = LocalDatePersistenceConverter.class)
    private LocalDate DateOfApplication;
   
   private String BankAccountName;
   private String BankName;
   private String AccountNumber;
   private String BranchLocation;
   private String KRAPin;
   
   private String SavedByUser;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the MemberNumber
     */
    public String getMemberNumber() {
        return MemberNumber;
    }

    /**
     * @param MemberNumber the MemberNumber to set
     */
    public void setMemberNumber(String MemberNumber) {
        this.MemberNumber = MemberNumber;
    }

    /**
     * @return the FullName
     */
    public String getFullName() {
        return FullName;
    }

    /**
     * @param FullName the FullName to set
     */
    public void setFullName(String FullName) {
        this.FullName = FullName;
    }

    /**
     * @return the AccountType
     */
    public String getAccountType() {
        return AccountType;
    }

    /**
     * @param AccountType the AccountType to set
     */
    public void setAccountType(String AccountType) {
        this.AccountType = AccountType;
    }

    /**
     * @return the InvestmentType
     */
    public String getInvestmentType() {
        return InvestmentType;
    }

    /**
     * @param InvestmentType the InvestmentType to set
     */
    public void setInvestmentType(String InvestmentType) {
        this.InvestmentType = InvestmentType;
    }

    /**
     * @return the DateOfApplication
     */
    public LocalDate getDateOfApplication() {
        return DateOfApplication;
    }

    /**
     * @param DateOfApplication the DateOfApplication to set
     */
    public void setDateOfApplication(LocalDate DateOfApplication) {
        this.DateOfApplication = DateOfApplication;
    }

    /**
     * @return the BankAccountName
     */
    public String getBankAccountName() {
        return BankAccountName;
    }

    /**
     * @param BankAccountName the BankAccountName to set
     */
    public void setBankAccountName(String BankAccountName) {
        this.BankAccountName = BankAccountName;
    }

    /**
     * @return the BankName
     */
    public String getBankName() {
        return BankName;
    }

    /**
     * @param BankName the BankName to set
     */
    public void setBankName(String BankName) {
        this.BankName = BankName;
    }

    /**
     * @return the AccountNumber
     */
    public String getAccountNumber() {
        return AccountNumber;
    }

    /**
     * @param AccountNumber the AccountNumber to set
     */
    public void setAccountNumber(String AccountNumber) {
        this.AccountNumber = AccountNumber;
    }

    /**
     * @return the BranchLocation
     */
    public String getBranchLocation() {
        return BranchLocation;
    }

    /**
     * @param BranchName the BranchLocation to set
     */
    public void setBranchLocation(String BranchName) {
        this.BranchLocation = BranchName;
    }

    /**
     * @return the KRAPin
     */
    public String getKRAPin() {
        return KRAPin;
    }

    /**
     * @param KRAPin the KRAPin to set
     */
    public void setKRAPin(String KRAPin) {
        this.KRAPin = KRAPin;
    }

    /**
     * @return the SavedByUser
     */
    public String getSavedByUser() {
        return SavedByUser;
    }

    /**
     * @param SavedByUser the SavedByUser to set
     */
    public void setSavedByUser(String SavedByUser) {
        this.SavedByUser = SavedByUser;
    }
}

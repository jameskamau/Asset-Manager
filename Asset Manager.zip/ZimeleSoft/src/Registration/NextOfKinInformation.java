/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Registration;

import DateConverter.LocalDatePersistenceConverter;
import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author james kamau
 */
@Entity
public class NextOfKinInformation implements Serializable {
    
    
     @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="ID")
    private int id;
     private String memberNumber;
    private String  identificationNumber;
    private String firstName;
    private String lastname;
    private String surName;
    private String fullName;
    private String EmailAddress;
    @Convert(converter = LocalDatePersistenceConverter.class)
    private LocalDate DateOfRegistration;
    private String phoneNumber;
    private String pyhsicalAddress;
    private String postalCode;
    private String ResidentTown;
    private String Relationship;
    private String percentage;
    private String SavedByUser;

    /**
     * @return the memberNumber
     */
    public String getMemberNumber() {
        return memberNumber;
    }

    /**
     * @param memberNumber the memberNumber to set
     */
    public void setMemberNumber(String memberNumber) {
        this.memberNumber = memberNumber;
    }

    /**
     * @return the identificationNumber
     */
    public String getIdentificationNumber() {
        return identificationNumber;
    }

    /**
     * @param identificationNumber the identificationNumber to set
     */
    public void setIdentificationNumber(String identificationNumber) {
        this.identificationNumber = identificationNumber;
    }

    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * @return the lastname
     */
    public String getLastname() {
        return lastname;
    }

    /**
     * @param lastname the lastname to set
     */
    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    /**
     * @return the surName
     */
    public String getSurName() {
        return surName;
    }

    /**
     * @param surName the surName to set
     */
    public void setSurName(String surName) {
        this.surName = surName;
    }

    /**
     * @return the fullName
     */
    public String getFullName() {
        return fullName;
    }

    /**
     * @param fullName the fullName to set
     */
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    /**
     * @return the EmailAddress
     */
    public String getEmailAddress() {
        return EmailAddress;
    }

    /**
     * @param EmailAddress the EmailAddress to set
     */
    public void setEmailAddress(String EmailAddress) {
        this.EmailAddress = EmailAddress;
    }

    /**
     * @return the DateOfRegistration
     */
    public LocalDate getDateOfRegistration() {
        return DateOfRegistration;
    }

    /**
     * @param DateOfRegistration the DateOfRegistration to set
     */
    public void setDateOfRegistration(LocalDate DateOfRegistration) {
        this.DateOfRegistration = DateOfRegistration;
    }

    /**
     * @return the phoneNumber
     */
    public String getPhoneNumber() {
        return phoneNumber;
    }

    /**
     * @param phoneNumber the phoneNumber to set
     */
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    /**
     * @return the pyhsicalAddress
     */
    public String getPyhsicalAddress() {
        return pyhsicalAddress;
    }

    /**
     * @param pyhsicalAddress the pyhsicalAddress to set
     */
    public void setPyhsicalAddress(String pyhsicalAddress) {
        this.pyhsicalAddress = pyhsicalAddress;
    }

    /**
     * @return the postalCode
     */
    public String getPostalCode() {
        return postalCode;
    }

    /**
     * @param postalCode the postalCode to set
     */
    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    /**
     * @return the ResidentTown
     */
    public String getResidentTown() {
        return ResidentTown;
    }

    /**
     * @param ResidentTown the ResidentTown to set
     */
    public void setResidentTown(String ResidentTown) {
        this.ResidentTown = ResidentTown;
    }

    /**
     * @return the Relationship
     */
    public String getRelationship() {
        return Relationship;
    }

    /**
     * @param Relationship the Relationship to set
     */
    public void setRelationship(String Relationship) {
        this.Relationship = Relationship;
    }

    /**
     * @return the percentage
     */
    public String getPercentage() {
        return percentage;
    }

    /**
     * @param percentage the percentage to set
     */
    public void setPercentage(String percentage) {
        this.percentage = percentage;
    }

    /**
     * @return the SavedByUser
     */
    public String getSavedByUser() {
        return SavedByUser;
    }

    /**
     * @param SavedByUser the SavedByUser to set
     */
    public void setSavedByUser(String SavedByUser) {
        this.SavedByUser = SavedByUser;
    }
    
}

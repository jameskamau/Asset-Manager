

package Registration;

import DateConverter.LocalDatePersistenceConverter;
import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author james kamau
 */
@Entity
public class FundTransfer implements Serializable {
    
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="ID")
    private int id;
    
    private String MemberNumber;
    
    private String FullName;
    
    private String AccountType;
    
    private String FromInvestmentType;
    
    private String ToInvestmentType;
      
    private String TransferAmount;
    
   @Convert(converter = LocalDatePersistenceConverter.class)
    private LocalDate DateOfTransfer;
   
   private String SavedByUser;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the MemberNumber
     */
    public String getMemberNumber() {
        return MemberNumber;
    }

    /**
     * @param MemberNumber the MemberNumber to set
     */
    public void setMemberNumber(String MemberNumber) {
        this.MemberNumber = MemberNumber;
    }

    /**
     * @return the FullName
     */
    public String getFullName() {
        return FullName;
    }

    /**
     * @param FullName the FullName to set
     */
    public void setFullName(String FullName) {
        this.FullName = FullName;
    }

    /**
     * @return the AccountType
     */
    public String getAccountType() {
        return AccountType;
    }

    /**
     * @param AccountType the AccountType to set
     */
    public void setAccountType(String AccountType) {
        this.AccountType = AccountType;
    }

    /**
     * @return the FromInvestmentType
     */
    public String getFromInvestmentType() {
        return FromInvestmentType;
    }

    /**
     * @param FromInvestmentType the FromInvestmentType to set
     */
    public void setFromInvestmentType(String FromInvestmentType) {
        this.FromInvestmentType = FromInvestmentType;
    }

    /**
     * @return the ToInvestmentType
     */
    public String getToInvestmentType() {
        return ToInvestmentType;
    }

    /**
     * @param ToInvestmentType the ToInvestmentType to set
     */
    public void setToInvestmentType(String ToInvestmentType) {
        this.ToInvestmentType = ToInvestmentType;
    }

    /**
     * @return the TransferAmount
     */
    public String getTransferAmount() {
        return TransferAmount;
    }

    /**
     * @param TransferAmount the TransferAmount to set
     */
    public void setTransferAmount(String TransferAmount) {
        this.TransferAmount = TransferAmount;
    }

    /**
     * @return the DateOfApplication
     */
    public LocalDate getDateOfTranfer() {
        return DateOfTransfer;
    }

    /**
     * @param DateOfApplication the DateOfApplication to set
     */
    public void setDateOfTransfer(LocalDate DateOfTransfer) {
        this.DateOfTransfer = DateOfTransfer;
    }

    /**
     * @return the SavedByUser
     */
    public String getSavedByUser() {
        return SavedByUser;
    }

    /**
     * @param SavedByUser the SavedByUser to set
     */
    public void setSavedByUser(String SavedByUser) {
        this.SavedByUser = SavedByUser;
    }
   
    
}

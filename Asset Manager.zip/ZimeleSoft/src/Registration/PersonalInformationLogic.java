/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Registration;

import DataBaseConnector.JavaFirebirdconnect;
import DataBaseConnector.javaconnect;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author james kamau
 */
public class PersonalInformationLogic {
    
    Connection connect;
    PreparedStatement statement;
    ResultSet result;
    
    private int memberNumber;
    private FileInputStream image;
    private String MemberNumber_Photo;
    private String FullName;
    private File file;
    
    public void savePassportPhoto() throws SQLException{
    connect=javaconnect.connectDb();
    String sql="insert into PersonalInfo_Photo (MemberNumber,FullName,Passport_Photo) VALUES(?,?,?)";
    statement= connect.prepareStatement(sql);
    statement.setString(1, MemberNumber_Photo);
    statement.setString(2, FullName);
    statement.setBinaryStream(3, (InputStream)image,(int)file.length());
    statement.execute();
    
    
    
    
    }
  
    public void updatePassportPhoto(String memberNumber,String fullName) throws SQLException{
        connect=javaconnect.connectDb();
        String sql="update  PersonalInfo_Photo set Passport_Photo=? where MemberNumber='";
       sql=sql.concat(memberNumber);sql=sql.concat("' and FullName='"); sql=sql.concat(fullName+"'");
        statement= connect.prepareStatement(sql);
        statement.setBinaryStream(1, (InputStream)image,(int)file.length());
        statement.executeUpdate();
        
        
        
        
        }
    public void getMemberNumberFromDB(String fundType) throws SQLException{
      
       
       if(fundType.equals("UNIT_TRUST")){
    	   connect=JavaFirebirdconnect.connectDb();
                	
         }else if(fundType.equals("PENSION")){
         	
        	 connect=JavaFirebirdconnect.connectDb1();
         }
        String sql1="SELECT MAX(MEMBER_NO) FROM MEMBERS ";
        
        statement = connect.prepareStatement(sql1);
        ResultSet rs1 = statement.executeQuery();
        
      
      rs1.next();
      String membernumber=rs1.getString(1);
        setMemberNumber(Integer.parseInt(membernumber));
    
    
    
    }

    /**
     * @return the memberNumber
     */
    public int getMemberNumber() {
        return memberNumber;
    }

    /**
     * @param memberNumber the memberNumber to set
     */
    public void setMemberNumber(int memberNumber) {
        this.memberNumber = memberNumber;
    }
    

    /**
     * @return the MemberNumber_Photo
     */
    public String getMemberNumber_Photo() {
        return MemberNumber_Photo;
    }

    /**
     * @param MemberNumber_Photo the MemberNumber_Photo to set
     */
    public void setMemberNumber_Photo(String MemberNumber_Photo) {
        this.MemberNumber_Photo = MemberNumber_Photo;
    }

    /**
     * @return the FullName
     */
    public String getFullName() {
        return FullName;
    }

    /**
     * @param FullName the FullName to set
     */
    public void setFullName(String FullName) {
        this.FullName = FullName;
    }

    /**
     * @return the image
     */
    public FileInputStream getImage() {
        return image;
    }

    /**
     * @param image the image to set
     */
    public void setImage(FileInputStream image) {
        this.image = image;
    }

    /**
     * @return the file
     */
    public File getFile() {
        return file;
    }

    /**
     * @param file the file to set
     */
    public void setFile(File file) {
        this.file = file;
    }
    
 
    
}
